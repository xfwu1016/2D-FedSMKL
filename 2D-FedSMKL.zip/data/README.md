# Raw data

The raw UCI MHEALTH and Human Activity Recognition Using Smartphones archives are not redistributed here. Download them from the UCI Machine Learning Repository using the DOIs in `../PUBLIC_DATASETS.md`, then place the archives anywhere and pass their paths to:

```bash
python code/run_revision_validation.py --mhealth-zip PATH_TO_MHEALTH_ZIP --har-zip PATH_TO_HAR_ZIP
```

The processed feature caches used by the component scripts are already in `results_revision/`.
