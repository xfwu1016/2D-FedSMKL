# Reproducibility guide

## Scope and caveats

This package contains the source code and derived records supporting the manuscript tables and figures. Raw MHEALTH and UCI HAR archives are not redistributed; obtain them as described in `PUBLIC_DATASETS.md`. Public-data experiments begin with complete-source representations and then impose controlled MAR modality masks. They do not establish representation learning from naturally incomplete modalities or robustness to MNAR missingness. The package also includes a conditional-imputation comparison, a ten-mask rho validation, reversed and size-balanced simulation designs, and a numerical evaluation of the propensity-perturbation constant.

The primary public-data analysis uses source-only preprocessing and validation, with selected robust temperatures of 0.12 for MHEALTH and 0.20 for HAR. It uses ten matched masks and a 1,400-round cap. The separate factorial component study uses 20 matched masks, common rho 0.05, and a 350-round cap; all 620 fits reach that cap, so these comparisons are finite-budget results rather than certified optima. The message-interface study is a single-process emulation and reports application payload, not physical-network speedup or privacy guarantees.

## Environment

The public-data and message experiments were run with Python 3.12.14, NumPy 2.3.5, SciPy 1.18.1, scikit-learn 1.9.1, joblib 1.6.0 and threadpoolctl 3.7.0, using one BLAS thread. The pinned packages are listed in `requirements.txt`. The simulation archive records its environment in `results/run_metadata.json`.

## Reproduce primary public-data results

Download the raw MHEALTH and HAR archives first. Then run:

```bash
python code/run_revision_validation.py --help
python code/run_revision_validation.py --mhealth-zip PATH_TO_MHEALTH_ZIP --har-zip PATH_TO_HAR_ZIP --prepare-only
python code/run_revision_validation.py --mhealth-zip PATH_TO_MHEALTH_ZIP --har-zip PATH_TO_HAR_ZIP
python code/run_revision_validation.py --mhealth-zip PATH_TO_MHEALTH_ZIP --har-zip PATH_TO_HAR_ZIP --audit-only
```

The default output is `results_revision`. For an independent reconstruction, use a fresh working copy and an empty output directory, and preserve the supplied reference outputs. Preprocessing is fitted inside each inner-training fold and refitted on the full source-training partition after selection. Test labels are not used for model selection.

## Reproduce the factorial component study

```bash
python code/run_revision_components.py
python code/prepare_revision_component_tables.py
```

The study crosses mean/robust aggregation with zero-fill/IPW correction at 10%, 35% and 65% absence using 20 matched masks. No-MKL comparisons are included at 35% and 65%; propensity clipping and a site-only misspecified propensity are checked at 65%. Full paired contrasts, weight summaries, propensity diagnostics and terminal optimization diagnostics are stored in `results_revision/` and `generated/`. The row-level `results_revision/component_propensity_diagnostics.csv` records propensity RMSE (`propensity_rmse`), modality-specific effective sample size (`ess`), and ESS divided by the number of observed records (`ess_over_observed`). Aggregated means and standard deviations are in `results_revision/component_propensity_summary.csv`.

## Reproduce Figure 5

```bash
python code/plot_factorial_contrasts.py
```

The plot is generated from `generated/table_revision_factorial_paired.tex`. It displays paired mean differences and unadjusted 95% paired t intervals for the robust-versus-mean and IPW-versus-zero contrasts. No model is refitted and no numerical values are altered.

## Reproduce the two-dimensional message-interface study

```bash
python code/run_revision_hybrid.py --datasets mhealth har --rounds 350
```

This study uses the fixed rho 0.05 and 350-round budget. The coordinator, row-worker and feature-worker messages are counted as float64 application payload. The numerical reference is the best observed L-BFGS-B value with recorded gradients, not a known exact optimum.

## Additional component experiments

The component experiments are in `code/revision_extra/`; see its `README.md`. They cover the conditional-imputation comparison, the ten-mask rho validation, the reversed and size-balanced simulation designs, and the numerical propensity deviation. They run on the distributed processed caches and need only NumPy (a scikit-learn shim is bundled for environments without it):

```bash
python code/revision_extra/validate_repro.py
python code/revision_extra/exp_reselect10.py
python code/revision_extra/exp_impute_primary.py
python code/revision_extra/exp_rho_and_impute.py --experiment impute
python code/revision_extra/exp_sim_variants.py
python code/revision_extra/exp_ep.py
python code/revision_extra/make_tables.py
```

`make_tables.py` rebuilds `generated/table_impute_primary.tex` and the four supplementary tables from the CSVs in `code/revision_extra/out/`. The same folder retains the CSVs recorded during the run. These experiments do not use raw UCI archives; they start from the packaged representation caches.

## Simulation records

The controlled simulation records are in `results/simulation_raw.csv` (786 successful fits; 14 complete-case fits failed at the highest missingness setting). Summary results and run metadata are in `results/simulation_summary.csv` and `results/run_metadata.json`.

## Statistical interpretation

Intervals across repeated masks quantify variability conditional on the fixed benchmark samples, split and representations. They do not quantify population, new-subject or new-site uncertainty and have no multiplicity adjustment. Standard deviations in the mean/SD plots are descriptive and should not be interpreted as confidence intervals. The main manuscript reports key intervals; complete paired contrasts and diagnostics are retained in Supplementary Material S2.
