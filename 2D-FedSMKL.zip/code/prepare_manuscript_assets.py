#!/usr/bin/env python3
"""Convert simulation CSV files into LaTeX tables and pgfplots data."""

from __future__ import annotations

import argparse
import csv
import json
import math
from collections import defaultdict
from pathlib import Path

import numpy as np


ORDER = [
    "Complete-case SMKL",
    "Zero-fill SMKL",
    "IPW mean SMKL",
    "2D-FedSMKL",
    "Oracle full SMKL",
]

LABEL = {
    "Complete-case SMKL": "Complete-case SMKL",
    "Zero-fill SMKL": "Zero-fill SMKL",
    "IPW mean SMKL": "IPW mean SMKL",
    "2D-FedSMKL": r"\textbf{2D-FedSMKL}",
    "Oracle full SMKL": "Oracle full SMKL",
}


def read_csv(path: Path):
    with path.open(encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def fnum(x, digits=3):
    return f"{float(x):.{digits}f}"


def write_primary_table(summary, outdir: Path):
    rows = [r for r in summary if float(r["missing_rate"]) == 0.35
            and float(r["heterogeneity"]) == 0.8]
    lookup = {r["method"]: r for r in rows}
    lines = [
        r"\begin{table*}[t]",
        r"\centering",
        r"\caption{Predictive performance in the primary simulation setting "
        r"(35\% target optional-modality absence and heterogeneity $h=0.8$). "
        r"Entries are mean (standard deviation) over 20 replicates. The oracle "
        r"uses fully observed modalities and is not feasible in practice.}",
        r"\label{tab:primary}",
        r"\scriptsize",
        r"\begin{tabular}{lcccc}",
        r"\toprule",
        r"Method & Mean AUC & Worst-site AUC & Mean BA & Worst-site BA \\",
        r"\midrule",
    ]
    for method in ORDER:
        r = lookup[method]
        vals = []
        for metric in ["mean_auc", "worst_auc", "mean_bacc", "worst_bacc"]:
            vals.append(f"{fnum(r[metric + '_mean'])} ({fnum(r[metric + '_sd'])})")
        lines.append(f"{LABEL[method]} & " + " & ".join(vals) + r" \\")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table*}"]
    (outdir / "table_primary.tex").write_text("\n".join(lines) + "\n", encoding="utf-8")


def write_partition_table(rows, outdir: Path):
    lines = [
        r"\begin{table}[H]",
        r"\centering",
        r"\caption{Numerical equivalence and estimated synchronous communication "
        r"for two-dimensional partitions.}",
        r"\label{tab:partition}",
        r"\scriptsize",
        r"\begin{tabular}{rrrr}",
        r"\toprule",
        r"Rows & Columns & Max. gradient error & KiB/round \\",
        r"\midrule",
    ]
    for r in rows:
        lines.append(
            f"{r['row_blocks']} & {r['column_blocks']} & "
            f"{float(r['gradient_max_abs_error']):.2e} & "
            f"{float(r['communication_kib_per_round']):.2f}" + r" \\")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    (outdir / "table_partition.tex").write_text("\n".join(lines) + "\n", encoding="utf-8")


def write_pairwise(raw, outdir: Path):
    scenarios = [(0.35, 0.8), (0.35, 1.2)]
    comparisons = []
    for missing, hetero in scenarios:
        by_method_seed = defaultdict(dict)
        for r in raw:
            if float(r["missing_rate"]) == missing and float(r["heterogeneity"]) == hetero:
                by_method_seed[r["method"]][int(r["seed"])] = float(r["worst_auc"])
        proposed = by_method_seed["2D-FedSMKL"]
        for baseline in ["Complete-case SMKL", "Zero-fill SMKL", "IPW mean SMKL"]:
            seeds = sorted(set(proposed) & set(by_method_seed[baseline]))
            diff = np.array([proposed[s] - by_method_seed[baseline][s] for s in seeds])
            mean = float(diff.mean())
            se = float(diff.std(ddof=1) / math.sqrt(len(diff)))
            comparisons.append({
                "missing": missing,
                "heterogeneity": hetero,
                "baseline": baseline,
                "difference": mean,
                "ci_low": mean - 1.96 * se,
                "ci_high": mean + 1.96 * se,
                "win_fraction": float((diff > 0).mean()),
            })
    with (outdir / "paired_differences.json").open("w", encoding="utf-8") as handle:
        json.dump(comparisons, handle, indent=2)

    lines = [
        r"\begin{table}[H]",
        r"\centering",
        r"\caption{Paired improvement in worst-site AUC of 2D-FedSMKL over "
        r"non-oracle baselines. Intervals are normal-approximation 95\% confidence "
        r"intervals over 20 matched replicates.}",
        r"\label{tab:paired}",
        r"\small",
        r"\begin{tabular}{cclcc}",
        r"\toprule",
        r"Missing & $h$ & Comparator & AUC difference (95\% CI) & Win rate \\",
        r"\midrule",
    ]
    for r in comparisons:
        lines.append(
            f"{r['missing']:.2f} & {r['heterogeneity']:.1f} & {r['baseline']} & "
            f"{r['difference']:.3f} [{r['ci_low']:.3f}, {r['ci_high']:.3f}] & "
            f"{100*r['win_fraction']:.0f}\\%" + r" \\")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    (outdir / "table_paired.tex").write_text("\n".join(lines) + "\n", encoding="utf-8")


def write_plot_data(summary, outdir: Path):
    hetero_rows = [r for r in summary if float(r["missing_rate"]) == 0.35]
    missing_rows = [r for r in summary if float(r["heterogeneity"]) == 0.8]
    for filename, rows, xkey in [
        ("plot_heterogeneity.csv", hetero_rows, "heterogeneity"),
        ("plot_missingness.csv", missing_rows, "missing_rate"),
    ]:
        lookup = defaultdict(dict)
        for r in rows:
            lookup[float(r[xkey])][r["method"]] = r
        fields = [xkey]
        for method in ORDER:
            fields += [method + "_mean", method + "_sd"]
        with (outdir / filename).open("w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=fields)
            writer.writeheader()
            for xval in sorted(lookup):
                row = {xkey: xval}
                for method in ORDER:
                    r = lookup[xval][method]
                    if int(r["replicates"]) < 20:
                        row[method + "_mean"] = "nan"
                        row[method + "_sd"] = "nan"
                    else:
                        row[method + "_mean"] = r["worst_auc_mean"]
                        row[method + "_sd"] = r["worst_auc_sd"]
                writer.writerow(row)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--results", required=True)
    parser.add_argument("--outdir", required=True)
    args = parser.parse_args()
    results = Path(args.results)
    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    summary = read_csv(results / "simulation_summary.csv")
    raw = read_csv(results / "simulation_raw.csv")
    partition = read_csv(results / "partition_equivalence.csv")
    write_primary_table(summary, outdir)
    write_partition_table(partition, outdir)
    write_pairwise(raw, outdir)
    write_plot_data(summary, outdir)


if __name__ == "__main__":
    main()
