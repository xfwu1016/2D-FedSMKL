"""Regenerate v20 plot data/source, selection and numerical-diagnostic tables.
Run after the final validation and component scripts. No model fitting.
Compile generated/public_missingness_stress_v20.tex twice from the package root.
"""
from pathlib import Path
import csv,json,numpy as np
ROOT=Path(__file__).resolve().parents[1]
def put(p,s): (ROOT/p).write_text(s.strip()+'\n',encoding='utf-8')
def read(p): return list(csv.DictReader((ROOT/p).open(encoding='utf-8')))
summary=read('results_revision/component_summary.csv')
for ds,key in [('MHEALTH','mhealth'),('UCI-HAR','har')]:
    rows=[]
    for rate in [.1,.35,.65]:
        q={'missing_rate':rate}
        for name,col in [('Mean zero','mean_zero'),('Robust zero','robust_zero'),('Mean IPW','mean_ipw'),('Robust IPW','proposed')]:
            r=next(x for x in summary if x['dataset']==ds and float(x['missing_rate'])==rate and x['method']==name)
            assert int(r['n'])==20
            q[col]=r['worst_macro_f1_mean'];q[col+'_sd']=r['worst_macro_f1_sd']
        rows.append(q)
    path=ROOT/f'generated/revision_stress_{key}.csv'
    with path.open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
plot=r'''\documentclass[border=6pt]{standalone}
\usepackage{pgfplots}
\usepgfplotslibrary{groupplots}
\pgfplotsset{compat=1.18}
\begin{document}
\begin{tikzpicture}
\begin{groupplot}[group style={group size=1 by 2,vertical sep=1.65cm},width=12.3cm,height=5.5cm,xmin=.07,xmax=.68,xtick={.1,.35,.65},xticklabels={10,35,65},xlabel={Target block absence (\%)},ylabel={Worst-site macro-F1},grid=major,tick label style={font=\small},label style={font=\small},legend columns=4,legend style={draw=none,font=\small,/tikz/every even column/.append style={column sep=7pt}}]
'''
for ds,key in [('MHEALTH','mhealth'),('UCI HAR','har')]:
    plot+=f'\\nextgroupplot[title={{{ds}}},'+('legend to name=revstress' if key=='mhealth' else 'ylabel={Worst-site macro-F1}')+']\n'
    for col,style,label in [('mean_zero','black,dashed,mark=square*','Mean zero'),('robust_zero','orange!85!black,dashdotted,mark=triangle*','Robust zero'),('mean_ipw','blue!65!black,densely dotted,mark=diamond*','Mean IPW'),('proposed','teal!80!black,thick,mark=*','2D-Fed')]:
        plot+=f'\\addplot+[{style},error bars/.cd,y dir=both,y explicit] table[x=missing_rate,y={col},y error={col}_sd,col sep=comma] {{generated/revision_stress_{key}.csv}};\n'
        if key=='mhealth':plot+=f'\\addlegendentry{{{label}}}\n'
plot+=r'''\end{groupplot}
\node[anchor=north] at ([yshift=-1.25cm]group c1r2.south) {\pgfplotslegendfromname{revstress}};
\end{tikzpicture}
\end{document}'''
put('generated/public_missingness_stress_v20.tex',plot)

meta=json.loads((ROOT/'results_revision/validation_metadata.json').read_text())
assert meta['fixed_parameters']['max_iter']==1400
ss=read('results_revision/primary_v20_summary.csv')
def q(ds,m):return next(x for x in ss if x['dataset']==ds and x['method']==m)
lines=[r'\begin{table}[H]',r'\centering\small',r'\caption{Frozen primary settings after source-only validation. Smooth hyperparameters not listed as selected are fixed as specified in S2.}',r'\label{tab:revision_selection}',r'\begin{tabular}{lrrrr}',r'\toprule',r'Dataset & $\rho$ & SVM $C$ & Fed learning rate & Fed rounds\\\midrule']
for ds in ['MHEALTH','UCI-HAR']:
    p=meta['selected'][ds]
    lines.append(f"{ds} & {p['rho']:.2f} & {p['svm_c']:g} & {p['FedAvg']['lr']:.2f} & {p['FedAvg']['rounds']}"+r'\\')
lines += [r'\bottomrule\end{tabular}',r'\end{table}']
put('generated/table_revision_selection.tex','\n'.join(lines))

lines=[r'\begin{table}[H]',r'\centering\scriptsize',r'\caption{Final primary smooth-model diagnostics over ten masks. The no-MKL fit is an additional primary ablation. Norms and certificates concern the empirical training objective; reaching a budget or a relative-step rule is not a claim of exact minimization. 2D-Fed denotes 2D-FedSMKL.}',r'\label{tab:revision_numerics}',r'\begin{tabular}{llrrr}',r'\toprule',r'Dataset & Method & Worst F1 (SD) & Gradient-norm range & Max gap bound\\\midrule']
for ds in ['MHEALTH','UCI-HAR']:
    raw=read(f'results_revision/primary_v20_raw_{ds}.csv')
    for m,label in [('Zero-fill SMKL','Zero-fill'),('IPW mean SMKL','IPW mean'),('2D-FedSMKL','2D-Fed'),('2D-FedSMKL no MKL','No-MKL')]:
        rr=[x for x in raw if x['method']==m];g=np.array([float(x['gradient_norm']) for x in rr]);assert len(g)==10
        s=q(ds,m)
        lines.append(f"{ds} & {label} & {float(s['worst_macro_f1_mean']):.3f} ({float(s['worst_macro_f1_sd']):.3f}) & [{g.min():.2e}, {g.max():.2e}] & {np.max(g*g/.0012):.2e}"+r'\\')
lines += [r'\bottomrule\end{tabular}',r'\end{table}']
put('generated/table_revision_numerics.tex','\n'.join(lines))

for name in ['table_revision_components.tex']:
    p=ROOT/'generated'/name
    s=p.read_text(encoding='utf-8')
    if r'\setlength{\tabcolsep}{3.5pt}' not in s:s=s.replace(r'\centering\small',r'\centering\small\setlength{\tabcolsep}{3.5pt}')
    p.write_text(s,encoding='utf-8')
p=ROOT/'generated/table_revision_hybrid.tex'
p.write_text(p.read_text(encoding='utf-8').replace(r'\nabla F',r'\nabla J'),encoding='utf-8')
print('Generated current v20 assets; compile stress plot twice before manuscript build.')
