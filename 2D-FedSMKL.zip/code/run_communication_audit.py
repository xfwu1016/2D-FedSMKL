#!/usr/bin/env python3
"""Re-run proposed public-data fits and count backtracking objective passes."""
from pathlib import Path
import argparse, csv, json, sys
import numpy as np
sys.path.insert(0, str(Path(__file__).resolve().parent))
from run_public_benchmarks import make_missingness, fit_smooth


def load_cache(path):
    z=np.load(path); gs=z['group_starts']; groups=[np.arange(int(gs[i]),int(gs[i+1])) for i in range(len(gs)-1)]
    return z['Xtr'],z['Xte'],z['ytr'],z['yte'],z['site_tr'],z['site_te'],groups


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--outdir',type=Path,default=Path('results_public')); args=ap.parse_args()
    meta=json.loads((args.outdir/'public_benchmark_metadata.json').read_text())
    rows=[]
    for ds,cache,B,A in [('MHEALTH','mhealth_processed.npz',4,10),('UCI-HAR','har_processed.npz',2,5)]:
        Xtr,Xte,ytr,yte,strn,stst,groups=load_cache(args.outdir/cache); C=int(max(ytr.max(),yte.max())+1)
        for rep,seed in enumerate(meta['seeds']):
            miss=make_missingness(Xtr,Xte,strn,stst,groups,.35,seed)
            _,info=fit_smooth(miss['ipw_tr'],ytr,strn,groups,C,robust=True,rho=.05,tau=4,lam0=.012,lam1=.0035,eps=1e-4,max_iter=350)
            rows.append(dict(dataset=ds,replicate=rep,seed=seed,iterations=info['iterations'],line_search_trials=info['line_search_trials'],time_sec=info['time_sec'],n=len(ytr),d=Xtr.shape[1],C=C,A=A,B=B))
    out=args.outdir/'communication_audit.csv'
    with open(out,'w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=rows[0].keys()); w.writeheader(); w.writerows(rows)
    print(out)

if __name__=='__main__': main()
