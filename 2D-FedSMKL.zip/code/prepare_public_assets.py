#!/usr/bin/env python3
from pathlib import Path
import math
import numpy as np
import pandas as pd
import matplotlib as mpl
mpl.rcParams['pdf.fonttype'] = 42
mpl.rcParams['ps.fonttype'] = 42
import matplotlib.pyplot as plt
from scipy.stats import t

ROOT=Path(__file__).resolve().parents[1]
R=ROOT/'results_public'; G=ROOT/'generated'; G.mkdir(exist_ok=True)
raw=pd.read_csv(R/'public_benchmark_raw.csv')
sumdf=pd.read_csv(R/'public_benchmark_summary.csv')
stress=pd.read_csv(R/'missingness_stress.csv')
sens=pd.read_csv(R/'hyperparameter_sensitivity.csv')
baseline_val=pd.read_csv(R/'baseline_source_validation.csv')
cap_audit=pd.read_csv(R/'convergence_cap_audit.csv')

# Main table: selected methods, primary 35% missingness.
methods=['Pooled linear SVM','Complete-case CS','FedAvg-CS','FedProx-CS','Zero-fill SMKL','IPW mean SMKL','2D-FedSMKL','Oracle full SMKL']
labels={'Pooled linear SVM':'Pooled linear SVM','Complete-case CS':'Complete-case CS','FedAvg-CS':'FedAvg-CS','FedProx-CS':'FedProx-CS','Zero-fill SMKL':'Zero-fill SMKL','IPW mean SMKL':'IPW mean SMKL','2D-FedSMKL':'2D-FedSMKL','Oracle full SMKL':'Oracle full SMKL'}
with open(G/'table_public_results.tex','w') as f:
    f.write('\\begin{table*}[t]\n\\centering\n\\caption{Public-data multiclass results under 35\\% controlled blockwise MAR modality absence. Entries are mean (standard deviation) over 10 independent missingness masks. The oracle is evaluated without artificial modality removal and is not a feasible comparator.}\\label{tab:public_main}\n')
    f.write('\\scriptsize\n\\setlength{\\tabcolsep}{4pt}\n\\begin{tabular}{lcccc}\n\\toprule\nMethod & Mean macro-F1 & Worst-site macro-F1 & Mean BA & Worst-site BA \\\\\n\\midrule\n')
    for ds in ['MHEALTH','UCI-HAR']:
        dd=sumdf[sumdf.dataset==ds]
        f.write('\\multicolumn{5}{l}{\\textbf{'+ds+'}} \\\\\n')
        for m in methods:
            r=dd[dd.method==m].iloc[0]
            vals=[]
            for k in ['mean_macro_f1','worst_macro_f1','mean_bal_acc','worst_bal_acc']:
                vals.append(f"{r[k+'_mean']:.3f} ({r[k+'_sd']:.3f})")
            nm=labels[m]
            if m=='2D-FedSMKL': nm='\\textbf{2D-FedSMKL}'
            f.write(nm+' & '+' & '.join(vals)+' \\\\\n')
        if ds=='MHEALTH': f.write('\\midrule\n')
    f.write('\\bottomrule\n\\end{tabular}\n\\end{table*}\n')

# Paired differences vs key baselines.
with open(G/'table_public_paired.tex','w') as f:
    f.write('\\begin{table}[H]\n\\centering\n\\caption{Paired differences in worst-site macro-F1: 2D-FedSMKL minus comparator, using the same 10 missingness masks. Intervals are two-sided 95\\% paired $t$ intervals.}\\label{tab:public_paired}\n\\small\n\\begin{tabular}{llc}\n\\toprule\nDataset & Comparator & Difference (95\\% CI) \\\\\n\\midrule\n')
    for ds in ['MHEALTH','UCI-HAR']:
        p=raw[(raw.dataset==ds)&(raw.method=='2D-FedSMKL')].sort_values('replicate')
        for comp in ['Complete-case CS','FedAvg-CS','Pooled linear SVM','Zero-fill SMKL','IPW mean SMKL']:
            q=raw[(raw.dataset==ds)&(raw.method==comp)].sort_values('replicate')
            d=p.worst_macro_f1.to_numpy()-q.worst_macro_f1.to_numpy(); mu=d.mean(); hw=t.ppf(.975,len(d)-1)*d.std(ddof=1)/math.sqrt(len(d))
            f.write(f"{ds} & {comp} & {mu:+.3f} [{mu-hw:+.3f}, {mu+hw:+.3f}] \\\\\n")
    f.write('\\bottomrule\n\\end{tabular}\n\\end{table}\n')

# Runtime/communication table with explicit line-search overhead.
# One full gradient round uses the manuscript's multiclass payload formula.
# Each backtracking trial additionally requires a score-only column aggregation;
# this audit counts those accepted/rejected objective passes explicitly.
audit=pd.read_csv(R/'communication_audit.csv')
meta={'MHEALTH':dict(n=2335,d=55,C=12,A=10,B=4),'UCI-HAR':dict(n=7352,d=50,C=6,A=5,B=2)}
with open(G/'table_public_compute.tex','w') as f:
    f.write('\\begin{table}[H]\n\\centering\n\\caption{Communication audit for public-data 2D-FedSMKL fits. \\emph{Gradient payload} is the nominal per-round score/derivative, gradient-reduction, and parameter-update payload. \\emph{Line-search payload} counts the additional score-only evaluations used by backtracking. Entries are means over 10 masks.}\\label{tab:public_compute}\n')
    f.write('\\small\n\\begin{tabular}{lrrrr}\n\\toprule\nDataset & Rounds & Gradient MiB/round & LS trials & Total MiB \\\\\n\\midrule\n')
    for ds in ['MHEALTH','UCI-HAR']:
        z=meta[ds]; a=audit[audit.dataset==ds]
        grad_bytes=16*z['C']*(z['d']*z['A']+z['n']*(z['B']-1))
        score_trial_bytes=8*z['C']*z['n']*(z['B']-1)
        total=(a.iterations*grad_bytes+a.line_search_trials*score_trial_bytes)/2**20
        f.write(f"{ds} & {a.iterations.mean():.1f} & {grad_bytes/2**20:.2f} & {a.line_search_trials.mean():.1f} & {total.mean():.1f} \\\\\n")
    f.write('\\bottomrule\n\\end{tabular}\n\\end{table}\n')

# Compact ablation table for the supplementary material.
with open(G/'table_public_ablation.tex','w') as f:
    f.write('\\begin{table}[H]\n\\centering\n\\caption{No-MKL ablation under 35\\% controlled absence. Entries are mean (standard deviation) worst-site macro-F1 over 10 masks.}\\label{tab:public_ablation}\n\\small\n\\begin{tabular}{lcc}\n\\toprule\nDataset & 2D-FedSMKL & No-MKL \\\\\n\\midrule\n')
    for ds in ['MHEALTH','UCI-HAR']:
        d=sumdf[sumdf.dataset==ds].set_index('method')
        a=d.loc['2D-FedSMKL']; b=d.loc['2D-FedSMKL no MKL']
        f.write(f"{ds} & {a.worst_macro_f1_mean:.3f} ({a.worst_macro_f1_sd:.3f}) & {b.worst_macro_f1_mean:.3f} ({b.worst_macro_f1_sd:.3f}) \\\\\n")
    f.write('\\bottomrule\n\\end{tabular}\n\\end{table}\n')

# Compact stress table for the supplementary material.
with open(G/'table_public_stress.tex','w') as f:
    f.write('\\begin{table}[H]\n\\centering\n\\caption{Worst-site macro-F1 under controlled block absence. Entries are means over three matched masks; the robust temperature is fixed at the source-selected $\\rho=0.05$.}\\label{tab:public_stress}\n\\small\n\\begin{tabular}{llccc}\n\\toprule\nDataset & Method & 10\\% & 35\\% & 65\\% \\\\\n\\midrule\n')
    for ds in ['MHEALTH','UCI-HAR']:
        for m in ['Zero-fill SMKL','IPW mean SMKL','2D-FedSMKL']:
            vals=[]
            for rate in [.10,.35,.65]:
                vals.append(stress[(stress.dataset==ds)&(stress.method==m)&(stress.missing_rate==rate)].worst_macro_f1.mean())
            f.write(f"{ds} & {m} & {vals[0]:.3f} & {vals[1]:.3f} & {vals[2]:.3f} \\\\\n")
        if ds=='MHEALTH': f.write('\\midrule\n')
    f.write('\\bottomrule\n\\end{tabular}\n\\end{table}\n')


# Source-only baseline validation table.
with open(G/'table_baseline_validation.tex','w') as f:
    f.write('\\begin{table}[H]\n\\centering\n\\caption{Source-only baseline tuning. FedAvg/FedProx include a second-stage round-count check; public-test labels are not used.}\\label{tab:baseline_validation}\n\\scriptsize\n\\begin{tabular}{llll}\n\\toprule\nDataset & Baseline & Selected setting & Val. worst F1 \\\\\n\\midrule\n')
    for ds in ['MHEALTH','UCI-HAR']:
        for meth in ['LinearSVC','FedAvg','FedProx']:
            d=baseline_val[(baseline_val.dataset==ds)&(baseline_val.method==meth)].sort_values(['worst_macro_f1','mean_macro_f1'],ascending=False).iloc[0]
            if meth=='LinearSVC': setting=f"$C_{{\\rm svm}}={d.C_svm:g}$"
            elif meth=='FedAvg': setting=f"lr={d.lr:g}, steps={int(d.local_steps)}, rounds={int(d.rounds)}"
            else: setting=f"lr={d.lr:g}, steps={int(d.local_steps)}, rounds={int(d.rounds)}, $\\mu={d.mu:g}$"
            f.write(f"{ds} & {meth} & {setting} & {d.worst_macro_f1:.3f} \\\\\n")
    f.write('\\bottomrule\n\\end{tabular}\n\\end{table}\n')

# Iteration-cap audit table.
with open(G/'table_convergence_cap.tex','w') as f:
    f.write('\\begin{table}[H]\n\\centering\n\\caption{Iteration-cap audit for a representative public-data mask (seed 20260820).}\\label{tab:cap_audit}\n\\small\n\\begin{tabular}{lrrrr}\n\\toprule\nDataset & Cap & Iterations & Objective & Worst-site F1 \\\\\n\\midrule\n')
    for _,d in cap_audit.iterrows():
        f.write(f"{d.dataset} & {int(d.cap)} & {int(d.iterations)} & {d.objective:.6f} & {d.worst_macro_f1:.3f} \\\\\n")
    f.write('\\bottomrule\n\\end{tabular}\n\\end{table}\n')

# Figure: primary worst-site results.
sel=['Pooled linear SVM','Complete-case CS','FedAvg-CS','Zero-fill SMKL','IPW mean SMKL','2D-FedSMKL']
fig,axs=plt.subplots(1,2,figsize=(8.2,3.0),sharey=False)
for ax,ds in zip(axs,['MHEALTH','UCI-HAR']):
    d=sumdf[(sumdf.dataset==ds)&sumdf.method.isin(sel)].set_index('method').loc[sel]
    x=np.arange(len(sel)); ax.bar(x,d.worst_macro_f1_mean,yerr=d.worst_macro_f1_sd,capsize=2)
    ax.set_xticks(x); ax.set_xticklabels(['Linear SVM','Complete','FedAvg','Zero-fill','IPW mean','2D-Fed'],rotation=35,ha='right',fontsize=7)
    ax.set_ylabel('Worst-site macro-F1'); ax.set_title(ds); ax.grid(axis='y',alpha=.25)
    lo=max(0,float(d.worst_macro_f1_mean.min()-0.12)); ax.set_ylim(lo,1.0)
fig.tight_layout(); fig.savefig(G/'public_primary_results.pdf',bbox_inches='tight'); fig.savefig(G/'public_primary_results.png',dpi=240,bbox_inches='tight'); plt.close(fig)

# Figure: missingness stress (mean over 3 masks).
fig,axs=plt.subplots(1,2,figsize=(7.7,2.8),sharey=False)
for ax,ds in zip(axs,['MHEALTH','UCI-HAR']):
    d=stress[stress.dataset==ds]
    for method in ['Zero-fill SMKL','IPW mean SMKL','2D-FedSMKL']:
        g=d[d.method==method].groupby('missing_rate').worst_macro_f1.agg(['mean','std']).reset_index()
        ax.errorbar(g.missing_rate,g['mean'],yerr=g['std'],marker='o',capsize=2,label=('2D-Fed' if method=='2D-FedSMKL' else method))
    ax.set_xlabel('Target modality absence'); ax.set_ylabel('Worst-site macro-F1'); ax.set_title(ds); ax.grid(alpha=.25)
axs[1].legend(fontsize=7,loc='best'); fig.tight_layout(); fig.savefig(G/'public_missingness_stress.pdf',bbox_inches='tight'); fig.savefig(G/'public_missingness_stress.png',dpi=240,bbox_inches='tight'); plt.close(fig)

# Figure: hyperparameter sensitivity MHEALTH.
fig,axs=plt.subplots(1,3,figsize=(8.2,2.5))
for ax,(par,label) in zip(axs,[('rho',r'$\rho$'),('tau',r'$\tau$'),('lambda1',r'$\lambda_1$')]):
    d=sens[sens.parameter==par]
    ax.plot(d.value,d.worst_macro_f1,marker='o',label='worst-site')
    ax.plot(d.value,d.mean_macro_f1,marker='s',label='mean-site')
    ax.set_xlabel(label); ax.set_ylabel('Macro-F1'); ax.grid(alpha=.25)
axs[-1].legend(fontsize=7); fig.tight_layout(); fig.savefig(G/'public_sensitivity.pdf',bbox_inches='tight'); plt.close(fig)
print('generated public assets')
