"""Validate the NumPy-only reproduction against a published primary cell.

Target: MHEALTH, seed 20260820, 35% absence, rho=0.12, 1400-round cap.
Expected worst-site macro-F1:
  Zero-fill SMKL 0.8444261834581864
  IPW mean SMKL  0.8040079681527050
  2D-FedSMKL     0.8624424250425395
"""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
PKG = ROOT
sys.path.insert(0, str(Path(__file__).resolve().parent / "shim"))
sys.path.insert(0, str(PKG / "code"))

import numpy as np
import run_public_benchmarks as rpb
from sklearn.metrics import f1_score, balanced_accuracy_score, accuracy_score


def metrics(y, p, site):
    S = site.max() + 1
    f = [f1_score(y[site == s], p[site == s]) for s in range(S)]
    b = [balanced_accuracy_score(y[site == s], p[site == s]) for s in range(S)]
    return dict(worst=float(np.min(f)), mean=float(np.mean(f)), worst_ba=float(np.min(b)))


def main():
    data = rpb.load_processed(PKG / "results_revision" / "primary_v20_mhealth_processed.npz")
    Xtr, Xte, ytr, yte, strn, stst, groups = data
    C = int(max(ytr.max(), yte.max()) + 1)
    miss = rpb.make_missingness(Xtr, Xte, strn, stst, groups, .35, 20260820)
    common = dict(groups=groups, C=C, tau=4, lam0=.012, lam1=.0035, eps=1e-4, max_iter=1400)
    th, info = rpb.fit_smooth(miss["zero_tr"], ytr, strn, robust=False, rho=.08, **common)
    m = metrics(yte, rpb.predict(th, miss["zero_te"], C), stst)
    print("zero-fill ", m, "expected 0.8444261834581864 ->", abs(m["worst"] - 0.8444261834581864) < 5e-6)
    th, info = rpb.fit_smooth(miss["ipw_tr"], ytr, strn, robust=False, rho=.08, **common)
    m = metrics(yte, rpb.predict(th, miss["ipw_te"], C), stst)
    print("ipw mean  ", m, "expected 0.8040079681527050 ->", abs(m["worst"] - 0.804007968152705) < 5e-6)
    th, info = rpb.fit_smooth(miss["ipw_tr"], ytr, strn, robust=True, rho=.12, **common)
    m = metrics(yte, rpb.predict(th, miss["ipw_te"], C), stst)
    print("2d-fedsmkl", m, "expected 0.8624424250425395 ->", abs(m["worst"] - 0.8624424250425395) < 5e-6)


if __name__ == "__main__":
    main()
