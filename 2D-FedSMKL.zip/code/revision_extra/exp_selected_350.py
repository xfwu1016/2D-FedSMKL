"""Selected model at the 350-round budget on the ten primary masks.

Used only to compare with the late-fusion comparator on identical masks.
"""
import csv
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
PKG = ROOT
sys.path.insert(0, str(Path(__file__).resolve().parent / "shim"))
sys.path.insert(0, str(PKG / "code"))

import numpy as np
import run_public_benchmarks as rpb
from sklearn.metrics import f1_score, balanced_accuracy_score

DATA = {
    "MHEALTH": PKG / "results_revision" / "primary_v20_mhealth_processed.npz",
    "UCI-HAR": PKG / "results_revision" / "primary_v20_har_processed.npz",
}
RHO = {"MHEALTH": 0.12, "UCI-HAR": 0.20}
PAR = dict(tau=4., lam0=.012, lam1=.0035, eps=1e-4)


def site_metrics(y, p, site):
    S = int(site.max() + 1)
    f = [f1_score(y[site == s], p[site == s]) for s in range(S)]
    b = [balanced_accuracy_score(y[site == s], p[site == s]) for s in range(S)]
    return float(np.mean(f)), float(np.min(f)), float(np.mean(b)), float(np.min(b))


def impute_conditional(Xtr, Xte, mask_tr, mask_te, groups, ridge=1e-2):
    Ztr = np.c_[np.ones(len(Xtr)), Xtr[:, groups[0]]]
    Zte = np.c_[np.ones(len(Xte)), Xte[:, groups[0]]]
    Atr = Xtr.copy(); Ate = Xte.copy()
    for m in range(1, len(groups)):
        g = groups[m]; obs = mask_tr[:, m] > .5
        Z = Ztr[obs]; Y = Xtr[np.ix_(obs, g)]
        G = Z.T @ Z + ridge * np.eye(Z.shape[1]); G[0, 0] -= ridge
        B = np.linalg.solve(G, Z.T @ Y)
        Atr[np.ix_(~obs, g)] = Ztr[~obs] @ B
        mte = mask_te[:, m] < .5
        Ate[np.ix_(mte, g)] = Zte[mte] @ B
    return Atr, Ate


def main():
    rows = []
    for ds in DATA:
        Xtr, Xte, ytr, yte, strn, stst, groups = rpb.load_processed(DATA[ds])
        C = int(max(ytr.max(), yte.max()) + 1)
        for i in range(10):
            seed = 20260820 + i
            miss = rpb.make_missingness(Xtr, Xte, strn, stst, groups, .35, seed)
            A, B = impute_conditional(Xtr, Xte, miss["mask_tr"], miss["mask_te"], groups)
            th, info = rpb.fit_smooth(A, ytr, strn, groups, C, robust=True, rho=RHO[ds],
                                      max_iter=350, **PAR)
            m = site_metrics(yte, rpb.predict(th, B, C), stst)
            rows.append(dict(dataset=ds, seed=seed, method="Selected (350 rounds)",
                             worst_f1=m[1], mean_f1=m[0]))
            print(ds, seed, round(m[1], 4), flush=True)
    out = ROOT / "rerun" / "out" / "selected_350.csv"
    with open(out, "w", newline="", encoding="utf8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
    print("wrote", out)


if __name__ == "__main__":
    main()
