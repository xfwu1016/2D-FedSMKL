"""Late-fusion comparator: one smooth CS classifier per block, scores averaged.

Each block-specific classifier is trained on the full training rows with only
its own coordinates (absent coordinates mean-filled). Test scores are averaged
over the blocks observed for that row. Budget: 350 rounds, ten primary masks.
"""
import csv
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
PKG = ROOT
sys.path.insert(0, str(Path(__file__).resolve().parent / "shim"))
sys.path.insert(0, str(PKG / "code"))

import numpy as np
import run_public_benchmarks as rpb
from sklearn.metrics import f1_score, balanced_accuracy_score

DATA = {
    "MHEALTH": PKG / "results_revision" / "primary_v20_mhealth_processed.npz",
    "UCI-HAR": PKG / "results_revision" / "primary_v20_har_processed.npz",
}
SEEDS = [20260820 + i for i in range(10)]
PAR = dict(tau=4., lam0=.012, lam1=0., eps=1e-4)


def site_metrics(y, p, site):
    S = int(site.max() + 1)
    f = [f1_score(y[site == s], p[site == s]) for s in range(S)]
    b = [balanced_accuracy_score(y[site == s], p[site == s]) for s in range(S)]
    return float(np.mean(f)), float(np.min(f)), float(np.mean(b)), float(np.min(b))


def scores(theta, X, C):
    d = X.shape[1]
    W = theta[:d * C].reshape(d, C)
    b = theta[d * C:]
    return X @ W + b


def main():
    rows = []
    for ds in DATA:
        Xtr, Xte, ytr, yte, strn, stst, groups = rpb.load_processed(DATA[ds])
        C = int(max(ytr.max(), yte.max()) + 1)
        for seed in SEEDS:
            miss = rpb.make_missingness(Xtr, Xte, strn, stst, groups, .35, seed)
            S = np.zeros((len(Xte), C))
            W = np.zeros((len(Xte), 1))
            for m, g in enumerate(groups):
                A = np.zeros_like(miss["zero_tr"]); A[:, g] = miss["zero_tr"][:, g]
                B = np.zeros_like(miss["zero_te"]); B[:, g] = miss["zero_te"][:, g]
                th, info = rpb.fit_smooth(A, ytr, strn, [g], C, robust=False, rho=.05,
                                          max_iter=350, **PAR)
                S += scores(th, B, C) * miss["mask_te"][:, [m]]
                W += miss["mask_te"][:, [m]]
            S = S / np.maximum(W, 1)
            pred = np.argmax(S, 1)
            m = site_metrics(yte, pred, stst)
            rows.append(dict(dataset=ds, seed=seed, method="Late fusion (per-block)",
                             mean_f1=m[0], worst_f1=m[1], mean_ba=m[2], worst_ba=m[3]))
            print(ds, seed, round(m[1], 4), flush=True)
    out = ROOT / "rerun" / "out" / "late_fusion.csv"
    out.parent.mkdir(parents=True, exist_ok=True)
    with open(out, "w", newline="", encoding="utf8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
    for ds in DATA:
        a = [r["worst_f1"] for r in rows if r["dataset"] == ds]
        print(ds, round(float(np.mean(a)), 4))
    print("wrote", out)


if __name__ == "__main__":
    main()
