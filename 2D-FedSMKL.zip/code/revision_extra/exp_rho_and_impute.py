"""New experiments for the referee response.

E1  rho sweep: robust vs mean aggregation under IPW, at 35% and 65% absence,
    350-round budget, 20 matched masks per dataset.
E2  conditional (learned) imputation baseline: per optional block, ridge
    regression from the always-observed baseline block, then the same smooth
    decision layer. Compared with zero-fill (mean imputation), IPW mean, and
    the proposed robust+IPW model.

Outputs CSV files under rerun/out.
"""
import argparse
import csv
import itertools
import math
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
PKG = ROOT
sys.path.insert(0, str(Path(__file__).resolve().parent / "shim"))
sys.path.insert(0, str(PKG / "code"))

import numpy as np
import run_public_benchmarks as rpb
from sklearn.metrics import f1_score, balanced_accuracy_score

T975 = {9: 2.2621571628540993, 19: 2.093024054408263, 20: 2.0859634472658364}
DATA = {
    "MHEALTH": PKG / "results_revision" / "primary_v20_mhealth_processed.npz",
    "UCI-HAR": PKG / "results_revision" / "primary_v20_har_processed.npz",
}
RHO_SEL = {"MHEALTH": 0.12, "UCI-HAR": 0.20}
PAR = dict(tau=4., lam0=.012, lam1=.0035, eps=1e-4)


def site_metrics(y, p, site):
    S = int(site.max() + 1)
    f = [f1_score(y[site == s], p[site == s]) for s in range(S)]
    b = [balanced_accuracy_score(y[site == s], p[site == s]) for s in range(S)]
    return float(np.mean(f)), float(np.min(f)), float(np.mean(b)), float(np.min(b))


def fit_predict(Xtr, ytr, strn, Xte, yte, stst, groups, C, robust, rho, rounds):
    th, _ = rpb.fit_smooth(Xtr, ytr, strn, groups, C, robust=robust, rho=rho,
                           max_iter=rounds, **PAR)
    return site_metrics(yte, rpb.predict(th, Xte, C), stst)


def impute_conditional(Xtr, Xte, mask_tr, mask_te, groups, ridge=1e-2):
    """Per optional block: ridge from all baseline-block coordinates."""
    Ztr = np.c_[np.ones(len(Xtr)), Xtr[:, groups[0]]]
    Zte = np.c_[np.ones(len(Xte)), Xte[:, groups[0]]]
    Atr = Xtr.copy()
    Ate = Xte.copy()
    for m in range(1, len(groups)):
        g = groups[m]
        obs = mask_tr[:, m] > 0.5
        Z = Ztr[obs]
        Y = Xtr[np.ix_(obs, g)]
        G = Z.T @ Z + ridge * np.eye(Z.shape[1])
        G[0, 0] -= ridge  # unpenalized intercept
        B = np.linalg.solve(G, Z.T @ Y)
        miss_tr = ~obs
        if miss_tr.any():
            Atr[np.ix_(miss_tr, g)] = Ztr[miss_tr] @ B
        miss_te = mask_te[:, m] < 0.5
        if miss_te.any():
            Ate[np.ix_(miss_te, g)] = Zte[miss_te] @ B
    return Atr, Ate


def paired(d, n):
    d = np.asarray(d, float)
    mu = float(d.mean())
    hw = T975[n - 1] * float(d.std(ddof=1)) / math.sqrt(n)
    return mu, mu - hw, mu + hw


def run_rho(ds, rounds, outdir, seeds):
    Xtr, Xte, ytr, yte, strn, stst, groups = rpb.load_processed(DATA[ds])
    C = int(max(ytr.max(), yte.max()) + 1)
    rows = []
    for miss_rate in (0.35, 0.65):
        for seed in seeds:
            miss = rpb.make_missingness(Xtr, Xte, strn, stst, groups, miss_rate, seed)
            base = fit_predict(miss["ipw_tr"], ytr, strn, miss["ipw_te"], yte, stst,
                               groups, C, False, .05, rounds)
            rows.append(dict(experiment="rho", dataset=ds, missing_rate=miss_rate, seed=seed,
                             method="IPW mean", rho="", mean_f1=base[0], worst_f1=base[1],
                             mean_ba=base[2], worst_ba=base[3]))
            for rho in (0.03, 0.05, 0.08, 0.12, 0.20):
                r = fit_predict(miss["ipw_tr"], ytr, strn, miss["ipw_te"], yte, stst,
                                groups, C, True, rho, rounds)
                rows.append(dict(experiment="rho", dataset=ds, missing_rate=miss_rate, seed=seed,
                                 method="IPW robust", rho=rho, mean_f1=r[0], worst_f1=r[1],
                                 mean_ba=r[2], worst_ba=r[3]))
    return rows


def run_impute(ds, rounds, outdir, seeds):
    Xtr, Xte, ytr, yte, strn, stst, groups = rpb.load_processed(DATA[ds])
    C = int(max(ytr.max(), yte.max()) + 1)
    rsel = RHO_SEL[ds]
    rows = []
    for miss_rate in (0.35, 0.65):
        for seed in seeds:
            miss = rpb.make_missingness(Xtr, Xte, strn, stst, groups, miss_rate, seed)
            im_tr, im_te = impute_conditional(Xtr, Xte, miss["mask_tr"], miss["mask_te"], groups)
            variants = [
                ("Zero-fill (mean imputation)", miss["zero_tr"], miss["zero_te"], False, .05),
                ("Conditional imputation", im_tr, im_te, False, .05),
                ("IPW mean", miss["ipw_tr"], miss["ipw_te"], False, .05),
                ("IPW robust (selected rho)", miss["ipw_tr"], miss["ipw_te"], True, rsel),
                ("Conditional imputation + robust", im_tr, im_te, True, rsel),
            ]
            for name, A, B, robust, rho in variants:
                m = fit_predict(A, ytr, strn, B, yte, stst, groups, C, robust, rho, rounds)
                rows.append(dict(experiment="impute", dataset=ds, missing_rate=miss_rate,
                                 seed=seed, method=name, rho=rho if robust else "",
                                 mean_f1=m[0], worst_f1=m[1], mean_ba=m[2], worst_ba=m[3]))
    return rows


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--experiment", choices=["rho", "impute", "both"], default="both")
    ap.add_argument("--datasets", nargs="+", default=["MHEALTH", "UCI-HAR"])
    ap.add_argument("--rounds", type=int, default=350)
    ap.add_argument("--replicates", type=int, default=20)
    ap.add_argument("--outdir", type=Path, default=Path(__file__).resolve().parent / "out")
    args = ap.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    seeds = [20260820 + i for i in range(args.replicates)]
    for ds in args.datasets:
        if args.experiment in ("rho", "both"):
            rows = run_rho(ds, args.rounds, args.outdir, seeds)
            p = args.outdir / f"rho_{ds}.csv"
            with open(p, "w", newline="", encoding="utf8") as f:
                w = csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
            print("wrote", p, len(rows), flush=True)
        if args.experiment in ("impute", "both"):
            rows = run_impute(ds, args.rounds, args.outdir, seeds)
            p = args.outdir / f"impute_{ds}.csv"
            with open(p, "w", newline="", encoding="utf8") as f:
                w = csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
            print("wrote", p, len(rows), flush=True)


if __name__ == "__main__":
    main()
