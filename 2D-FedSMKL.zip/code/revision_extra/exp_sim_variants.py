"""Run the reversed-shift and size-balanced simulation variants.

For each variant, 20 replicates at h in {0.8, 1.2} and 35% absence. Reports
mean and worst-site AUC for the proposed model, IPW mean, and zero filling.
"""
import csv
import importlib
import math
import sys
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(Path(__file__).resolve().parent))

import numpy as np

T975_19 = 2.093024054408263


def paired(a, b):
    d = np.asarray([x - y for x, y in zip(a, b)], float)
    mu = float(d.mean())
    hw = T975_19 * float(d.std(ddof=1)) / math.sqrt(len(d))
    return mu, mu - hw, mu + hw


def main():
    out = Path(__file__).resolve().parent / "out"
    out.mkdir(parents=True, exist_ok=True)
    rows = []
    for variant in ("rev", "bal"):
        mod = importlib.import_module(f"sim_{variant}")
        for h in (0.8, 1.2):
            for i in range(20):
                seed = (16000 if h == 0.8 else 17000) + i
                for r in mod.run_one(seed, 0.35, h):
                    row = dict(r); row["variant"] = variant; rows.append(row)
            print(variant, h, "done", flush=True)
    p = out / "sim_variants.csv"
    with open(p, "w", newline="", encoding="utf8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
    for variant in ("rev", "bal"):
        for h in (0.8, 1.2):
            sub = [r for r in rows if r["variant"] == variant and r["heterogeneity"] == h]
            by = defaultdict(dict)
            for r in sub:
                by[r["method"]][r["seed"]] = r
            seeds = sorted(by["2D-FedSMKL"])
            print(f"\n{variant} h={h} n={len(seeds)}")
            for m in ("2D-FedSMKL", "IPW mean SMKL", "Zero-fill SMKL", "Complete-case SMKL", "Oracle full SMKL"):
                w = [by[m][s]["worst_auc"] for s in seeds if s in by[m]]
                print(f"  {m:22s} worst {np.mean(w):.4f} mean {np.mean([by[m][s]['mean_auc'] for s in seeds if s in by[m]]):.4f}")
            for m in ("IPW mean SMKL", "Zero-fill SMKL", "Complete-case SMKL"):
                a = [by["2D-FedSMKL"][s]["worst_auc"] for s in seeds]
                b = [by[m][s]["worst_auc"] for s in seeds]
                mu, lo, hi = paired(a, b)
                print(f"  diff vs {m:18s} {mu:+.4f} [{lo:+.4f},{hi:+.4f}]")
    print("wrote", p)


if __name__ == "__main__":
    main()
