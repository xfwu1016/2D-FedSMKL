"""Compute the maximum propensity deviation e_p and the perturbation bound Delta_p.

Replicates the package's mask-generation code exactly (validated by comparing
the generated masks with run_public_benchmarks.make_missingness), then records
max |phat - p| on training rows for the primary masks.
"""
import csv
import math
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
PKG = ROOT
sys.path.insert(0, str(Path(__file__).resolve().parent / "shim"))
sys.path.insert(0, str(PKG / "code"))

import numpy as np
import run_public_benchmarks as rpb

DATA = {
    "MHEALTH": PKG / "results_revision" / "primary_v20_mhealth_processed.npz",
    "UCI-HAR": PKG / "results_revision" / "primary_v20_har_processed.npz",
}


def make_missingness_truth(Xtr, Xte, site_tr, site_te, groups, missing_rate, seed, pmin=.10):
    rng = np.random.default_rng(seed)
    M = len(groups)
    baseline = groups[0]
    k = min(3, len(baseline))
    Ztr, Zte = Xtr[:, baseline[:k]], Xte[:, baseline[:k]]
    mu = Ztr.mean(0); sd = Ztr.std(0); sd = np.where(sd < 1e-8, 1, sd)
    Ztr = (Ztr - mu) / sd; Zte = (Zte - mu) / sd
    coef = np.array([.35, -.25, .15])[:k]
    S = int(max(site_tr.max(), site_te.max()) + 1)
    base_offsets = np.linspace(-.35, .35, S)
    mask_tr = np.ones((len(Xtr), M)); mask_te = np.ones((len(Xte), M))
    ptrue_tr = np.ones_like(mask_tr); ptrue_te = np.ones_like(mask_te)
    phat_tr = np.ones_like(mask_tr); phat_te = np.ones_like(mask_te)
    one_tr = np.eye(S)[site_tr]; one_te = np.eye(S)[site_te]
    Dtr = np.c_[np.ones(len(Xtr)), Ztr, one_tr[:, 1:]]
    Dte = np.c_[np.ones(len(Xte)), Zte, one_te[:, 1:]]
    for m in range(1, M):
        offsets = base_offsets * (1 + .15 * m)
        a = rpb.calibrate_intercept(Ztr, site_tr, 1 - missing_rate, coef, offsets)
        pt = rpb.expit(a + Ztr @ coef + offsets[site_tr])
        pe = rpb.expit(a + Zte @ coef + offsets[site_te])
        rt = (rng.random(len(Xtr)) < pt).astype(float)
        re = (rng.random(len(Xte)) < pe).astype(float)
        beta = rpb.fit_logistic_irls(Dtr, rt)
        qt = np.clip(rpb.expit(Dtr @ beta), pmin, .98)
        qe = np.clip(rpb.expit(Dte @ beta), pmin, .98)
        mask_tr[:, m] = rt; mask_te[:, m] = re
        ptrue_tr[:, m] = pt; ptrue_te[:, m] = pe
        phat_tr[:, m] = qt; phat_te[:, m] = qe
    return mask_tr, mask_te, ptrue_tr, ptrue_te, phat_tr, phat_te


def main():
    rows = []
    for ds, path in DATA.items():
        Xtr, Xte, ytr, yte, strn, stst, groups = rpb.load_processed(path)
        M = len(groups)
        lam0, lam1, eps, tau = .012, .0035, 1e-4, 4.0
        J0 = math.log(1 + math.exp(tau)) / tau + .5 * lam1 * M * M * eps * eps
        Bw = math.sqrt(2 * M * J0 / lam0)
        kappa = math.sqrt(sum(float(np.linalg.norm(Xtr[:, g], axis=1).max()) ** 2 for g in groups))
        for i in range(20):
            seed = 20260820 + i
            mt, me, pt, pe, qt, qe = make_missingness_truth(Xtr, Xte, strn, stst, groups, .35, seed)
            ref = rpb.make_missingness(Xtr, Xte, strn, stst, groups, .35, seed)
            assert np.array_equal(mt, ref["mask_tr"]) and np.array_equal(me, ref["mask_te"]), "mask mismatch"
            ep_tr = float(np.abs(qt[:, 1:] - pt[:, 1:]).max())
            ep_te = float(np.abs(qe[:, 1:] - pe[:, 1:]).max())
            rmse = float(np.sqrt(np.mean((qt[:, 1:] - pt[:, 1:]) ** 2)))
            gap = float(np.abs(qt[:, 1:].min() - pt[:, 1:].min()))
            dp = Bw * kappa * ep_tr / (.08 ** 2)
            rows.append(dict(dataset=ds, seed=seed, e_p_train=ep_tr, e_p_test=ep_te,
                             rmse=rmse, min_gap=gap, B_w=Bw, kappa=kappa, Delta_p=dp))
        print(ds, "done", flush=True)
    out = Path(__file__).resolve().parent / "out" / "propensity_deviation.csv"
    out.parent.mkdir(parents=True, exist_ok=True)
    with open(out, "w", newline="", encoding="utf8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
    for ds in DATA:
        a = [r for r in rows if r["dataset"] == ds]
        print(ds, "e_p min/max", round(min(r["e_p_train"] for r in a), 4), round(max(r["e_p_train"] for r in a), 4),
              "Delta_p min/max", round(min(r["Delta_p"] for r in a), 2), round(max(r["Delta_p"] for r in a), 2))
    print("wrote", out)


if __name__ == "__main__":
    main()
