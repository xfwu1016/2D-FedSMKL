# Additional component experiments

These scripts reproduce the additional component experiments in the manuscript. They use
the processed feature caches distributed with this package
(`results_revision/primary_v20_*_processed.npz`,
`results_revision/validation_inner_*.npz`) and the training code in
`code/run_public_benchmarks.py`.

## Environment

The scripts need NumPy. They import scikit-learn for macro-F1 and balanced
accuracy; when scikit-learn is unavailable, the bundled `shim/` package supplies
equivalent implementations (macro-F1 over the union of labels, per-class recall
for balanced accuracy). The shim is inserted on `sys.path` automatically.

## Scripts

| Script | Purpose | Output |
|---|---|---|
| `validate_repro.py` | Reproduces one published primary cell (MHEALTH, seed 20260820, 35% absence, rho=0.12, 1400 rounds) | prints the three values |
| `exp_reselect10.py` | Re-runs the rho grid on ten validation masks at 1400 rounds | `out/rho_validation10_1400.csv` |
| `exp_correction_validation.py` | Selects the availability correction (IPW vs conditional imputation) on ten inner-validation masks at 1400 rounds | `out/correction_validation.csv` |
| `exp_impute_primary.py` | Conditional-imputation variant at the primary budget (10 test masks, 1400 rounds) | `out/impute_primary.csv` |
| `exp_modality_dropout.py` | Modality-dropout training baseline (350 rounds, 20 masks) | `out/modality_dropout.csv` |
| `exp_late_fusion.py` | Late-fusion comparator: one smooth classifier per block, scores averaged (350 rounds, ten primary masks) | `out/late_fusion.csv` |
| `exp_selected_350.py` | Selected model at the 350-round budget on the same masks, for the late-fusion comparison | `out/selected_350.csv` |
| `exp_rho_and_impute.py` | rho sweep and conditional-imputation comparison at the secondary budget (20 masks, 350 rounds) | `out/rho_*.csv`, `out/impute_*.csv` |
| `exp_ep.py` | Observed propensity deviation and the perturbation constant | `out/propensity_deviation.csv` |
| `exp_sim_variants.py` | Reversed-shift and size-balanced simulation designs | `out/sim_variants.csv` |
| `make_tables.py` | Builds `generated/table_impute_primary.tex` and the four supplementary tables from the CSVs above | `generated/` |
| `sim_rev.py`, `sim_bal.py` | Copies of `simulate_experiments.py` used by `exp_sim_variants.py`. `sim_rev` exchanges the decision-boundary offsets of the first and third sites; `sim_bal` sets the training sizes to `(187, 187, 186)`. | imported |

Run order: `validate_repro.py`, then the experiment scripts, then
`make_tables.py`. Outputs are written to `code/revision_extra/out/`.

The correction-selection experiment (`exp_correction_validation.py`) uses the
inner-training/inner-validation caches; the selection rule prefers the higher
mean validation worst-site macro-F1 and breaks ties in favour of IPW. The
conditional-imputation runs use the same temperature that was validated for the
IPW instantiation.

## Fixed settings

- Primary protocol: 35% target optional-block absence, ten masks (seeds
  20260820–20260829), 1400 rounds, `tau=4`, `lam0=0.012`, `lam1=0.0035`,
  `eps=1e-4`, selected `rho=0.12` (MHEALTH) and `0.20` (UCI-HAR).
- Secondary protocol: 350 rounds, 20 masks (seeds 20261101–20261120),
  `rho=0.05`.
- Validation protocol: inner training/validation partitions from
  `validation_inner_*.npz`, ten masks (seeds 20261131–20261140), 1400 rounds,
  same selection rule as the manuscript.
- Simulation designs: seeds 16000–16019 (`h=0.8`) and 17000–17019 (`h=1.2`),
  35% absence, 20 replicates.
- Conditional imputation: per optional block, a ridge regression
  (`lambda=1e-2`, unpenalized intercept) from the always-observed block, fitted
  on training rows where the block is observed.

## Notes

The scripts write only to `code/revision_extra/out/` and `generated/`; they do
not modify the distributed result files. `make_tables.py` overwrites the five
generated table files named above, so run it only when regenerating the tables.
