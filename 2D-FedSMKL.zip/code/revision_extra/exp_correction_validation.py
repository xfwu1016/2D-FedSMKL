"""Select the availability correction on validation data only.

For each dataset, compare IPW and conditional imputation (both with the robust
layer at the already-validated rho) on ten inner-validation masks at the full
1400-round budget. Selection rule: higher mean validation worst-site macro-F1;
ties are broken in favour of IPW (the variant covered by the risk analysis),
then by the higher mean-site F1.
"""
import csv
import sys
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
PKG = ROOT
sys.path.insert(0, str(Path(__file__).resolve().parent / "shim"))
sys.path.insert(0, str(PKG / "code"))

import numpy as np
import run_public_benchmarks as rpb
from sklearn.metrics import f1_score, balanced_accuracy_score

DATA = {
    "MHEALTH": PKG / "results_revision" / "validation_inner_mhealth.npz",
    "UCI-HAR": PKG / "results_revision" / "validation_inner_har.npz",
}
PAR = dict(tau=4., lam0=.012, lam1=.0035, eps=1e-4)
RHO = {"MHEALTH": 0.12, "UCI-HAR": 0.20}
SEEDS = [20261131 + i for i in range(10)]


def site_metrics(y, p, site):
    S = int(site.max() + 1)
    f = [f1_score(y[site == s], p[site == s]) for s in range(S)]
    b = [balanced_accuracy_score(y[site == s], p[site == s]) for s in range(S)]
    return float(np.mean(f)), float(np.min(f)), float(np.mean(b)), float(np.min(b))


def impute_conditional(Xtr, Xte, mask_tr, mask_te, groups, ridge=1e-2):
    Ztr = np.c_[np.ones(len(Xtr)), Xtr[:, groups[0]]]
    Zte = np.c_[np.ones(len(Xte)), Xte[:, groups[0]]]
    Atr = Xtr.copy(); Ate = Xte.copy()
    for m in range(1, len(groups)):
        g = groups[m]; obs = mask_tr[:, m] > 0.5
        Z = Ztr[obs]; Y = Xtr[np.ix_(obs, g)]
        G = Z.T @ Z + ridge * np.eye(Z.shape[1]); G[0, 0] -= ridge
        B = np.linalg.solve(G, Z.T @ Y)
        Atr[np.ix_(~obs, g)] = Ztr[~obs] @ B
        mte = mask_te[:, m] < 0.5
        Ate[np.ix_(mte, g)] = Zte[mte] @ B
    return Atr, Ate


def main():
    rows = []
    for ds in DATA:
        Xtr, Xte, ytr, yte, strn, stst, groups = rpb.load_processed(DATA[ds])
        C = int(max(ytr.max(), yte.max()) + 1)
        rho = RHO[ds]
        for seed in SEEDS:
            miss = rpb.make_missingness(Xtr, Xte, strn, stst, groups, .35, seed)
            im_tr, im_te = impute_conditional(Xtr, Xte, miss["mask_tr"], miss["mask_te"], groups)
            for corr, A, B in (("IPW", miss["ipw_tr"], miss["ipw_te"]),
                               ("Conditional imputation", im_tr, im_te)):
                th, info = rpb.fit_smooth(A, ytr, strn, groups, C, robust=True, rho=rho,
                                          max_iter=1400, **PAR)
                m = site_metrics(yte, rpb.predict(th, B, C), stst)
                rows.append(dict(dataset=ds, seed=seed, correction=corr, rho=rho,
                                 mean_f1=m[0], worst_f1=m[1], mean_ba=m[2], worst_ba=m[3]))
                print(ds, seed, corr, round(m[1], 4), flush=True)
    out = ROOT / "rerun" / "out" / "correction_validation.csv"
    out.parent.mkdir(parents=True, exist_ok=True)
    with open(out, "w", newline="", encoding="utf8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
    print("\nselection:")
    for ds in DATA:
        cand = []
        for corr in ("IPW", "Conditional imputation"):
            a = [r for r in rows if r["dataset"] == ds and r["correction"] == corr]
            cand.append((corr, float(np.mean([r["worst_f1"] for r in a])),
                         float(np.mean([r["mean_f1"] for r in a]))))
        cand.sort(key=lambda t: (-t[1], 0 if t[0] == "IPW" else 1, -t[2]))
        print(ds, "selected", cand[0][0], "worst", round(cand[0][1], 4),
              "| IPW", round(cand[0][1], 4) if cand[0][0] == "IPW" else round(cand[1][1], 4),
              "| CI", round(cand[0][1], 4) if cand[0][0] != "IPW" else round(cand[1][1], 4))
    print("wrote", out)


if __name__ == "__main__":
    main()
