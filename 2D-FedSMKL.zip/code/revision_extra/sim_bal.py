#!/usr/bin/env python3
"""Reproducible simulations for 2D-FedSMKL.

The implementation intentionally depends only on NumPy and the Python standard
library so that the complete experiment can be rerun in a minimal environment.
It simulates three heterogeneous clinical sites, four modalities, MAR blockwise
modality absence, and a two-dimensional row/column data partition.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import time
from dataclasses import dataclass
from pathlib import Path

import numpy as np


@dataclass
class Dataset:
    x_train_full: np.ndarray
    x_test_full: np.ndarray
    x_train_zero: np.ndarray
    x_test_zero: np.ndarray
    x_train_ipw: np.ndarray
    x_test_ipw: np.ndarray
    y_train: np.ndarray
    y_test: np.ndarray
    site_train: np.ndarray
    site_test: np.ndarray
    mask_train: np.ndarray
    mask_test: np.ndarray
    groups: list[np.ndarray]


def expit(x: np.ndarray) -> np.ndarray:
    out = np.empty_like(x, dtype=float)
    pos = x >= 0
    out[pos] = 1.0 / (1.0 + np.exp(-x[pos]))
    ex = np.exp(x[~pos])
    out[~pos] = ex / (1.0 + ex)
    return out


def softplus(x: np.ndarray) -> np.ndarray:
    return np.maximum(x, 0.0) + np.log1p(np.exp(-np.abs(x)))


def logit(p: float) -> float:
    p = min(max(p, 1e-6), 1.0 - 1e-6)
    return math.log(p / (1.0 - p))


def fit_logistic_irls(x: np.ndarray, y: np.ndarray, ridge: float = 1e-3,
                      max_iter: int = 50) -> np.ndarray:
    """Small ridge-logistic fit used only for observation propensities."""
    beta = np.zeros(x.shape[1])
    eye = np.eye(x.shape[1])
    eye[0, 0] = 0.0
    for _ in range(max_iter):
        eta = x @ beta
        p = expit(eta)
        w = np.clip(p * (1.0 - p), 1e-5, None)
        z = eta + (y - p) / w
        h = x.T @ (w[:, None] * x) + ridge * eye
        rhs = x.T @ (w * z)
        beta_new = np.linalg.solve(h, rhs)
        if np.linalg.norm(beta_new - beta) < 1e-8 * (1.0 + np.linalg.norm(beta)):
            beta = beta_new
            break
        beta = beta_new
    return beta


def _make_site(seed: int, n: int, site: int, heterogeneity: float,
               maps: list[np.ndarray], dims: list[int], train: bool):
    rng = np.random.default_rng(seed)
    latent_dim = maps[0].shape[0]
    site_means = np.array([
        [0.00, 0.00, 0.00, 0.00, 0.00],
        [0.35, -0.20, 0.15, 0.00, 0.10],
        [-0.30, 0.30, -0.10, 0.20, -0.15],
    ])
    z = rng.normal(size=(n, latent_dim)) + heterogeneity * site_means[site]

    theta0 = np.array([1.00, -0.85, 0.70, 0.50, -0.40])
    deltas = np.array([
        [0.00, 0.00, 0.00, 0.00, 0.00],
        [-0.35, 0.45, 0.10, -0.20, 0.15],
        [-1.00, 1.10, -0.90, 0.40, 0.10],
    ])
    theta = theta0 + heterogeneity * deltas[site]
    noise_scale = 1.25 if train else 1.20
    score = z @ theta + rng.normal(scale=noise_scale, size=n)
    thresholds = np.array([0.05, -0.10, 0.15])
    y = np.where(score > thresholds[site], 1.0, -1.0)

    modalities = []
    for m, (a, d) in enumerate(zip(maps, dims)):
        shift_rng = np.random.default_rng(9100 + 100 * site + m)
        shift = shift_rng.normal(scale=0.22, size=d)
        scale = 1.0 + heterogeneity * (0.08 * (site - 1))
        measurement = scale * (z @ a)
        measurement += heterogeneity * shift
        measurement += rng.normal(scale=0.70 + 0.10 * m, size=(n, d))
        modalities.append(measurement)
    return modalities, y, z


def generate_dataset(seed: int, missing_rate: float, heterogeneity: float) -> Dataset:
    dims = [8, 12, 16, 12]
    latent_dim = 5
    map_rng = np.random.default_rng(20260808)
    maps = [map_rng.normal(size=(latent_dim, d)) / math.sqrt(latent_dim) for d in dims]
    # Deliberately imbalanced sites create unequal site prevalence and This makes average-risk training under-represent the
    # smallest, most shifted site and exposes the purpose of robust aggregation.
    train_sizes = [187, 187, 186]
    test_sizes = [300, 300, 300]

    train_mods = [[] for _ in dims]
    test_mods = [[] for _ in dims]
    y_train_parts, y_test_parts = [], []
    z_train_parts, z_test_parts = [], []
    site_train, site_test = [], []

    for s in range(3):
        mods, y, z = _make_site(seed + 37 * s, train_sizes[s], s,
                                heterogeneity, maps, dims, True)
        mods_te, y_te, z_te = _make_site(seed + 10000 + 53 * s, test_sizes[s], s,
                                         heterogeneity, maps, dims, False)
        for m in range(len(dims)):
            train_mods[m].append(mods[m])
            test_mods[m].append(mods_te[m])
        y_train_parts.append(y)
        y_test_parts.append(y_te)
        z_train_parts.append(z)
        z_test_parts.append(z_te)
        site_train.extend([s] * train_sizes[s])
        site_test.extend([s] * test_sizes[s])

    train_mods = [np.vstack(parts) for parts in train_mods]
    test_mods = [np.vstack(parts) for parts in test_mods]
    y_train = np.concatenate(y_train_parts)
    y_test = np.concatenate(y_test_parts)
    site_train = np.asarray(site_train, dtype=int)
    site_test = np.asarray(site_test, dtype=int)

    # The baseline modality is always observed. Optional modality availability
    # follows a correctly specified MAR logistic model using baseline features
    # and site indicators, but propensities are estimated rather than supplied.
    base_train = train_mods[0]
    base_test = test_mods[0]
    base_mu = base_train.mean(axis=0)
    base_sd = base_train.std(axis=0) + 1e-8
    base_train_std = (base_train - base_mu) / base_sd
    base_test_std = (base_test - base_mu) / base_sd

    def design(base: np.ndarray, sites: np.ndarray) -> np.ndarray:
        return np.column_stack([
            np.ones(base.shape[0]),
            base[:, :3],
            (sites == 1).astype(float),
            (sites == 2).astype(float),
        ])

    d_train = design(base_train_std, site_train)
    d_test = design(base_test_std, site_test)
    rng = np.random.default_rng(seed + 8888)
    mask_train = np.ones((len(y_train), len(dims)), dtype=float)
    mask_test = np.ones((len(y_test), len(dims)), dtype=float)
    p_train_hat = np.ones_like(mask_train)
    p_test_hat = np.ones_like(mask_test)
    modality_offsets = [0.0, 0.35, 0.00, -0.35]
    site_offsets = np.array([[0.0, 0.0, 0.0], [0.20, -0.15, -0.25],
                             [-0.25, 0.25, -0.10]])
    for m in range(1, len(dims)):
        coef = np.array([
            logit(1.0 - missing_rate) + modality_offsets[m],
            0.35,
            -0.25,
            0.15,
            site_offsets[m - 1, 1],
            site_offsets[m - 1, 2],
        ])
        p_train = np.clip(expit(d_train @ coef), 0.08, 0.98)
        p_test = np.clip(expit(d_test @ coef), 0.08, 0.98)
        mask_train[:, m] = rng.binomial(1, p_train)
        mask_test[:, m] = rng.binomial(1, p_test)
        beta_hat = fit_logistic_irls(d_train, mask_train[:, m])
        p_train_hat[:, m] = np.clip(expit(d_train @ beta_hat), 0.10, 0.98)
        p_test_hat[:, m] = np.clip(expit(d_test @ beta_hat), 0.10, 0.98)

    # Standardize each modality using only observed training rows.
    train_standard, test_standard = [], []
    for m in range(len(dims)):
        obs = mask_train[:, m] > 0
        mu = train_mods[m][obs].mean(axis=0)
        sd = train_mods[m][obs].std(axis=0) + 1e-8
        train_standard.append((train_mods[m] - mu) / sd)
        test_standard.append((test_mods[m] - mu) / sd)

    groups = []
    start = 0
    for d in dims:
        groups.append(np.arange(start, start + d))
        start += d

    x_train_full = np.hstack(train_standard)
    x_test_full = np.hstack(test_standard)
    zero_train_parts, zero_test_parts = [], []
    ipw_train_parts, ipw_test_parts = [], []
    for m in range(len(dims)):
        zero_train_parts.append(train_standard[m] * mask_train[:, [m]])
        zero_test_parts.append(test_standard[m] * mask_test[:, [m]])
        ipw_train_parts.append(train_standard[m] * mask_train[:, [m]] / p_train_hat[:, [m]])
        ipw_test_parts.append(test_standard[m] * mask_test[:, [m]] / p_test_hat[:, [m]])

    return Dataset(
        x_train_full=x_train_full,
        x_test_full=x_test_full,
        x_train_zero=np.hstack(zero_train_parts),
        x_test_zero=np.hstack(zero_test_parts),
        x_train_ipw=np.hstack(ipw_train_parts),
        x_test_ipw=np.hstack(ipw_test_parts),
        y_train=y_train,
        y_test=y_test,
        site_train=site_train,
        site_test=site_test,
        mask_train=mask_train,
        mask_test=mask_test,
        groups=groups,
    )


def objective_gradient(theta: np.ndarray, x: np.ndarray, y: np.ndarray,
                       sites: np.ndarray, groups: list[np.ndarray], robust: bool,
                       tau: float, rho: float, lam_l2: float, lam_group: float):
    w, b = theta[:-1], theta[-1]
    f = x @ w + b
    margin_arg = tau * (1.0 - y * f)
    losses = softplus(margin_arg) / tau
    d_f = -y * expit(margin_arg)
    unique = np.unique(sites)
    risks = np.array([losses[sites == s].mean() for s in unique])
    if robust:
        pi = np.array([(sites == s).mean() for s in unique])
        logits = np.log(pi + 1e-15) + risks / rho
        logits -= logits.max()
        q = np.exp(logits)
        q /= q.sum()
        risk_value = rho * (np.log(np.sum(pi * np.exp((risks - risks.max()) / rho)))
                            + risks.max() / rho)
    else:
        q = np.array([(sites == s).mean() for s in unique])
        risk_value = float(np.dot(q, risks))

    grad_w = np.zeros_like(w)
    grad_b = 0.0
    for qs, s in zip(q, unique):
        idx = sites == s
        grad_w += qs * (x[idx].T @ d_f[idx]) / idx.sum()
        grad_b += qs * d_f[idx].mean()

    group_scales = np.array([math.sqrt(float(np.dot(w[g], w[g])) + 1e-8)
                             for g in groups])
    group_sum = group_scales.sum()
    group_pen = 0.5 * lam_group * group_sum * group_sum
    for scale, g in zip(group_scales, groups):
        grad_w[g] += lam_group * group_sum * w[g] / scale
    l2_pen = 0.5 * lam_l2 * (np.dot(w, w) + 0.05 * b * b)
    grad_w += lam_l2 * w
    grad_b += 0.05 * lam_l2 * b
    value = risk_value + group_pen + l2_pen
    grad = np.concatenate([grad_w, np.array([grad_b])])
    return float(value), grad, risks, q


def train_accelerated(x: np.ndarray, y: np.ndarray, sites: np.ndarray,
                      groups: list[np.ndarray], robust: bool,
                      tau: float = 4.0, rho: float = 0.06,
                      lam_l2: float = 0.015, lam_group: float = 0.004,
                      max_iter: int = 350, tol: float = 1e-7,
                      trace: bool = False):
    theta = np.zeros(x.shape[1] + 1)
    yk = theta.copy()
    tk = 1.0
    lipschitz = 4.0
    history = []
    for iteration in range(max_iter):
        value_y, grad_y, _, _ = objective_gradient(
            yk, x, y, sites, groups, robust, tau, rho, lam_l2, lam_group)
        accepted = False
        for _ in range(30):
            candidate = yk - grad_y / lipschitz
            value_c, _, risks_c, q_c = objective_gradient(
                candidate, x, y, sites, groups, robust, tau, rho, lam_l2, lam_group)
            delta = candidate - yk
            upper = value_y + np.dot(grad_y, delta) + 0.5 * lipschitz * np.dot(delta, delta)
            if value_c <= upper + 1e-12:
                accepted = True
                break
            lipschitz *= 2.0
        if not accepted:
            raise RuntimeError("Backtracking failed to find a valid quadratic majorant")
        t_new = 0.5 * (1.0 + math.sqrt(1.0 + 4.0 * tk * tk))
        y_new = candidate + ((tk - 1.0) / t_new) * (candidate - theta)
        rel = np.linalg.norm(candidate - theta) / (1.0 + np.linalg.norm(theta))
        theta, yk, tk = candidate, y_new, t_new
        # Retain the accepted Lipschitz estimate; the sequence is nondecreasing.
        if trace and (iteration < 20 or iteration % 5 == 0 or iteration == max_iter - 1):
            history.append((iteration + 1, value_c, *risks_c, *q_c))
        if rel < tol and iteration > 30:
            break
    norms = np.array([math.sqrt(float(np.dot(theta[g], theta[g])) + 1e-8)
                      for g in groups])
    beta = norms / norms.sum()
    return theta, beta, history


def auc_score(y: np.ndarray, score: np.ndarray) -> float:
    pos = y > 0
    n_pos = int(pos.sum())
    n_neg = len(y) - n_pos
    if n_pos == 0 or n_neg == 0:
        return float("nan")
    order = np.argsort(score, kind="mergesort")
    sorted_score = score[order]
    ranks = np.empty(len(score), dtype=float)
    start = 0
    while start < len(score):
        end = start + 1
        while end < len(score) and sorted_score[end] == sorted_score[start]:
            end += 1
        avg_rank = 0.5 * ((start + 1) + end)
        ranks[order[start:end]] = avg_rank
        start = end
    return float((ranks[pos].sum() - n_pos * (n_pos + 1) / 2.0) / (n_pos * n_neg))


def balanced_accuracy(y: np.ndarray, score: np.ndarray) -> float:
    pred = np.where(score >= 0.0, 1.0, -1.0)
    pos = y > 0
    neg = ~pos
    tpr = (pred[pos] > 0).mean() if pos.any() else float("nan")
    tnr = (pred[neg] < 0).mean() if neg.any() else float("nan")
    return float(0.5 * (tpr + tnr))


def evaluate(theta: np.ndarray, x: np.ndarray, y: np.ndarray,
             sites: np.ndarray) -> dict[str, float]:
    scores = x @ theta[:-1] + theta[-1]
    aucs, baccs = [], []
    for s in np.unique(sites):
        idx = sites == s
        aucs.append(auc_score(y[idx], scores[idx]))
        baccs.append(balanced_accuracy(y[idx], scores[idx]))
    return {
        "mean_auc": float(np.mean(aucs)),
        "worst_auc": float(np.min(aucs)),
        "mean_bacc": float(np.mean(baccs)),
        "worst_bacc": float(np.min(baccs)),
    }


def run_one(seed: int, missing_rate: float, heterogeneity: float):
    data = generate_dataset(seed, missing_rate, heterogeneity)
    complete = np.all(data.mask_train > 0, axis=1)
    methods = [
        ("Complete-case SMKL", data.x_train_full[complete], data.y_train[complete],
         data.site_train[complete], data.x_test_zero, False),
        ("Zero-fill SMKL", data.x_train_zero, data.y_train, data.site_train,
         data.x_test_zero, False),
        ("IPW mean SMKL", data.x_train_ipw, data.y_train, data.site_train,
         data.x_test_ipw, False),
        ("2D-FedSMKL", data.x_train_ipw, data.y_train, data.site_train,
         data.x_test_ipw, True),
        ("Oracle full SMKL", data.x_train_full, data.y_train, data.site_train,
         data.x_test_full, False),
    ]
    rows = []
    for name, xtr, ytr, str_, xte, robust in methods:
        if len(ytr) < 30 or len(np.unique(ytr)) < 2:
            continue
        theta, beta, _ = train_accelerated(xtr, ytr, str_, data.groups, robust)
        metrics = evaluate(theta, xte, data.y_test, data.site_test)
        row = {
            "seed": seed,
            "missing_rate": missing_rate,
            "heterogeneity": heterogeneity,
            "method": name,
            "complete_train_n": int(complete.sum()),
            **metrics,
        }
        for m, value in enumerate(beta, 1):
            row[f"beta_{m}"] = float(value)
        rows.append(row)
    return rows


def summarize(rows: list[dict]) -> list[dict]:
    keys = sorted({(r["missing_rate"], r["heterogeneity"], r["method"]) for r in rows})
    metrics = ["mean_auc", "worst_auc", "mean_bacc", "worst_bacc", "complete_train_n"]
    output = []
    for missing, hetero, method in keys:
        subset = [r for r in rows if r["missing_rate"] == missing
                  and r["heterogeneity"] == hetero and r["method"] == method]
        item = {"missing_rate": missing, "heterogeneity": hetero,
                "method": method, "replicates": len(subset)}
        for metric in metrics:
            values = np.array([r[metric] for r in subset], dtype=float)
            item[f"{metric}_mean"] = float(np.mean(values))
            item[f"{metric}_sd"] = float(np.std(values, ddof=1)) if len(values) > 1 else 0.0
        output.append(item)
    return output


def write_csv(path: Path, rows: list[dict]):
    if not rows:
        return
    fields = list(rows[0].keys())
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def block_gradient(theta: np.ndarray, x: np.ndarray, y: np.ndarray,
                   sites: np.ndarray, groups: list[np.ndarray], robust: bool,
                   row_blocks: int, col_blocks: int):
    """Compute the empirical gradient by explicit 2D block reductions."""
    w, b = theta[:-1], theta[-1]
    row_ids = np.array_split(np.arange(len(y)), row_blocks)
    col_ids = np.array_split(np.arange(x.shape[1]), col_blocks)
    f = np.full(len(y), b)
    for ridx in row_ids:
        partial = np.zeros(len(ridx))
        for cidx in col_ids:
            partial += x[np.ix_(ridx, cidx)] @ w[cidx]
        f[ridx] += partial
    arg = 4.0 * (1.0 - y * f)
    losses = softplus(arg) / 4.0
    d_f = -y * expit(arg)
    unique = np.unique(sites)
    risks = np.array([losses[sites == s].mean() for s in unique])
    if robust:
        pi = np.array([(sites == s).mean() for s in unique])
        logits = np.log(pi + 1e-15) + risks / 0.06
        logits -= logits.max()
        q = np.exp(logits)
        q /= q.sum()
    else:
        q = np.array([(sites == s).mean() for s in unique])
    sample_weight = np.zeros(len(y))
    for qs, s in zip(q, unique):
        idx = sites == s
        sample_weight[idx] = qs / idx.sum()
    grad_w = np.zeros(x.shape[1])
    for ridx in row_ids:
        weighted = sample_weight[ridx] * d_f[ridx]
        for cidx in col_ids:
            grad_w[cidx] += x[np.ix_(ridx, cidx)].T @ weighted
    grad_b = float(np.dot(sample_weight, d_f))
    group_scales = np.array([math.sqrt(float(np.dot(w[g], w[g])) + 1e-8)
                             for g in groups])
    group_sum = group_scales.sum()
    for scale, g in zip(group_scales, groups):
        grad_w[g] += 0.004 * group_sum * w[g] / scale
    grad_w += 0.015 * w
    grad_b += 0.05 * 0.015 * b
    return np.concatenate([grad_w, np.array([grad_b])])


def convergence_and_partition(outdir: Path):
    data = generate_dataset(76001, 0.35, 0.8)
    theta, beta, history = train_accelerated(
        data.x_train_ipw, data.y_train, data.site_train, data.groups,
        robust=True, max_iter=700, tol=1e-10, trace=True)
    best = min(row[1] for row in history)
    conv_rows = []
    for row in history:
        conv_rows.append({
            "iteration": row[0],
            "objective": row[1],
            "objective_gap": max(row[1] - best, 1e-12),
            "site1_risk": row[2],
            "site2_risk": row[3],
            "site3_risk": row[4],
            "site1_weight": row[5],
            "site2_weight": row[6],
            "site3_weight": row[7],
        })
    write_csv(outdir / "convergence.csv", conv_rows)

    _, central_grad, _, _ = objective_gradient(
        theta, data.x_train_ipw, data.y_train, data.site_train, data.groups,
        True, 4.0, 0.06, 0.015, 0.004)
    partition_rows = []
    n, p = data.x_train_ipw.shape
    for a, b in [(1, 1), (3, 2), (3, 4), (6, 4), (9, 8)]:
        block_grad = block_gradient(theta, data.x_train_ipw, data.y_train,
                                    data.site_train, data.groups, True, a, b)
        bytes_round = 16 * p * a + 16 * n * max(b - 1, 0)
        partition_rows.append({
            "row_blocks": a,
            "column_blocks": b,
            "gradient_max_abs_error": float(np.max(np.abs(block_grad - central_grad))),
            "communication_kib_per_round": bytes_round / 1024.0,
        })
    write_csv(outdir / "partition_equivalence.csv", partition_rows)
    with (outdir / "reference_fit.json").open("w", encoding="utf-8") as handle:
        json.dump({"beta": beta.tolist(), "final_objective": best}, handle, indent=2)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--outdir", required=True)
    parser.add_argument("--replicates", type=int, default=10)
    args = parser.parse_args()
    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)

    scenarios = []
    for heterogeneity in [0.0, 0.4, 0.8, 1.2]:
        scenarios.append((0.35, heterogeneity))
    for missing_rate in [0.10, 0.25, 0.50, 0.65]:
        scenarios.append((missing_rate, 0.8))
    scenarios = sorted(set(scenarios))

    all_rows = []
    started = time.time()
    for scenario_id, (missing_rate, heterogeneity) in enumerate(scenarios):
        for rep in range(args.replicates):
            seed = 12000 + 1000 * scenario_id + rep
            all_rows.extend(run_one(seed, missing_rate, heterogeneity))
            print(f"scenario {scenario_id + 1}/{len(scenarios)} rep {rep + 1}/{args.replicates}",
                  flush=True)
    write_csv(outdir / "simulation_raw.csv", all_rows)
    summary = summarize(all_rows)
    write_csv(outdir / "simulation_summary.csv", summary)
    convergence_and_partition(outdir)
    with (outdir / "run_metadata.json").open("w", encoding="utf-8") as handle:
        json.dump({
            "replicates": args.replicates,
            "scenarios": scenarios,
            "elapsed_seconds": time.time() - started,
            "numpy_version": np.__version__,
        }, handle, indent=2)


if __name__ == "__main__":
    main()
