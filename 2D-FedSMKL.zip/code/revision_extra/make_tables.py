"""Build the LaTeX tables for the new experiments."""
import csv
import math
from collections import defaultdict
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
PKG = ROOT
OUT = PKG / "generated"
OUT.mkdir(exist_ok=True)
OUTDIR = Path(__file__).resolve().parent / "out"
T9 = 2.2621571628540993
T19 = 2.093024054408263
RAWF = {"MHEALTH": "primary_v20_raw_MHEALTH.csv", "UCI-HAR": "primary_v20_raw_UCI-HAR.csv"}


def read_primary(ds):
    out = defaultdict(dict)
    for r in csv.DictReader(open(PKG / "results_revision" / RAWF[ds], encoding="utf8")):
        out[r["method"]][int(r["seed"])] = float(r["worst_macro_f1"])
    return out


def ci(d, t=T9):
    d = np.asarray(d, float)
    mu = float(d.mean())
    hw = t * float(d.std(ddof=1)) / math.sqrt(len(d))
    return mu, mu - hw, mu + hw


def primary_table():
    prim = {ds: read_primary(ds) for ds in RAWF}
    imp = defaultdict(lambda: defaultdict(dict))
    for r in csv.DictReader(open(OUTDIR / "impute_primary.csv", encoding="utf8")):
        imp[r["dataset"]][r["method"]][int(r["seed"])] = float(r["worst_f1"])
    lines = [r"\begin{table}[t]", r"\centering",
             r"\caption{Availability correction under the primary protocol (35\% target absence, ten masks, 1400 rounds). Worst-site macro-F1 and paired difference against IPW mean, with the 95\% interval over ten masks.}",
             r"\label{tab:impute}", r"\small", r"\setlength{\tabcolsep}{3pt}",
             r"\begin{tabular}{lcc}", r"\toprule",
             r"Method & Worst-site macro-F1 & $\Delta$ vs IPW mean\\", r"\midrule"]
    seeds = sorted(prim["MHEALTH"]["IPW mean SMKL"])
    rows = [
        ("IPW mean", lambda ds: prim[ds]["IPW mean SMKL"]),
        ("2D-FedSMKL (IPW, robust)", lambda ds: prim[ds]["2D-FedSMKL"]),
        ("Conditional imputation", lambda ds: imp[ds]["Conditional imputation (mean)"]),
        ("Conditional imputation + robust", lambda ds: imp[ds]["Conditional imputation (robust)"]),
    ]
    for ds, panel in (("MHEALTH", "MHEALTH"), ("UCI-HAR", "UCI-HAR")):
        lines.append(r"\multicolumn{3}{l}{\textbf{" + panel + r"}}\\")
        for name, get in rows:
            a = get(ds)
            f1 = float(np.mean([a[s] for s in seeds]))
            if name == "IPW mean":
                diff = "--"
            else:
                mu, lo, hi = ci([a[s] - prim[ds]["IPW mean SMKL"][s] for s in seeds])
                diff = f"{mu:+.3f} [{lo:+.3f}, {hi:+.3f}]"
            lines.append(f"{name} & {f1:.3f} & {diff} \\\\")
        if ds == "MHEALTH":
            lines.append(r"\midrule")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    (OUT / "table_impute_primary.tex").write_text("\n".join(lines) + "\n", encoding="utf8")


def supp_impute_table():
    names = ["Zero-fill (mean imputation)", "Conditional imputation", "IPW mean",
             "IPW robust (selected rho)", "Conditional imputation + robust"]
    label = {"Zero-fill (mean imputation)": "Zero-fill (mean imputation)",
             "Conditional imputation": "Conditional imputation",
             "IPW mean": "IPW mean", "IPW robust (selected rho)": "2D-FedSMKL (IPW, robust)",
             "Conditional imputation + robust": "Conditional imputation + robust"}
    data = {}
    for ds in ("MHEALTH", "UCI-HAR"):
        rows = list(csv.DictReader(open(OUTDIR / f"impute_{ds}.csv", encoding="utf8")))
        for rate in ("0.35", "0.65"):
            for m in names:
                data[(ds, rate, m)] = [float(r["worst_f1"]) for r in rows if r["missing_rate"] == rate and r["method"] == m]
    lines = [r"\begin{table}[H]", r"\centering",
             r"\caption{Correction and aggregation in the secondary budget (350 rounds, 20 masks). Worst-site macro-F1, mean over masks. At 35\% absence the conditional-imputation variant is $+0.035$ $[+0.021,+0.049]$ above IPW mean on MHEALTH and $-0.000$ $[-0.005,+0.004]$ on UCI-HAR.}",
             r"\label{tab:supp_impute}", r"\scriptsize",
             r"\setlength{\tabcolsep}{6pt}",
             r"\begin{tabular}{lcc}", r"\toprule",
             r"Method & 35\% absence & 65\% absence\\", r"\midrule"]
    for ds in ("MHEALTH", "UCI-HAR"):
        lines.append(r"\multicolumn{3}{l}{\textbf{" + ds + r"}}\\")
        for m in names:
            lines.append(f"{label[m]} & {np.mean(data[(ds, '0.35', m)]):.3f} & {np.mean(data[(ds, '0.65', m)]):.3f} \\\\")
        if ds == "MHEALTH":
            lines.append(r"\midrule")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    (OUT / "table_supp_impute35.tex").write_text("\n".join(lines) + "\n", encoding="utf8")


def sim_table():
    rows = list(csv.DictReader(open(OUTDIR / "sim_variants.csv", encoding="utf8")))
    published = defaultdict(dict)
    for r in csv.DictReader(open(PKG / "results" / "simulation_raw.csv", encoding="utf8")):
        if float(r["missing_rate"]) == 0.35:
            published[(float(r["heterogeneity"]), r["method"])][int(r["seed"])] = float(r["worst_auc"])
    lines = [r"\begin{table}[H]", r"\centering",
             r"\caption{Design sensitivity of the simulation. Worst-site AUC at 35\% absence (20 replicates); the last column is the paired difference of 2D-FedSMKL against IPW mean. \emph{Original} assigns the largest decision-boundary shift to the smallest site; \emph{reversed} assigns it to the largest site; \emph{balanced} uses site sizes $(187,187,186)$.}",
             r"\label{tab:supp_simdesign}", r"\small", r"\setlength{\tabcolsep}{4pt}",
             r"\begin{tabular}{llcccc}", r"\toprule",
             r"Design & $h$ & 2D-FedSMKL & IPW mean & Zero-fill & $\Delta$ vs IPW mean\\", r"\midrule"]
    for variant, vname in (("orig", "Original"), ("rev", "Reversed"), ("bal", "Balanced")):
        for h in (0.8, 1.2):
            if variant == "orig":
                base = 16000 if h == 0.8 else 17000
                seeds = list(range(base, base + 20))
                get = lambda method: {s: published[(h, method)][s] for s in seeds}
                a = [get("2D-FedSMKL")[s] for s in seeds]
                b = [get("IPW mean SMKL")[s] for s in seeds]
                c = [get("Zero-fill SMKL")[s] for s in seeds]
            else:
                by = defaultdict(dict)
                for r in rows:
                    if r["variant"] == variant and float(r["heterogeneity"]) == h:
                        by[r["method"]][int(r["seed"])] = float(r["worst_auc"])
                seeds = sorted(by["2D-FedSMKL"])
                a = [by["2D-FedSMKL"][s] for s in seeds]
                b = [by["IPW mean SMKL"][s] for s in seeds]
                c = [by["Zero-fill SMKL"][s] for s in seeds]
            mu, lo, hi = ci([x - y for x, y in zip(a, b)], T19)
            lines.append(f"{vname} & {h} & {np.mean(a):.3f} & {np.mean(b):.3f} & {np.mean(c):.3f} & {mu:+.3f} [{lo:+.3f}, {hi:+.3f}] \\\\")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    (OUT / "table_supp_simdesign.tex").write_text("\n".join(lines) + "\n", encoding="utf8")


def rho_table():
    rows = list(csv.DictReader(open(OUTDIR / "rho_validation10_1400.csv", encoding="utf8")))
    lines = [r"\begin{table}[H]", r"\centering",
             r"\caption{Validation of $\rho$ on ten validation masks at the full 1400-round budget, 35\% absence. Entries are mean worst-site macro-F1 over the ten masks.}",
             r"\label{tab:supp_rhoval}", r"\small",
             r"\begin{tabular}{lccccc}", r"\toprule",
             r"Dataset & $\rho=0.03$ & $0.05$ & $0.08$ & $0.12$ & $0.20$\\", r"\midrule"]
    for ds in ("MHEALTH", "UCI-HAR"):
        vals = []
        for rho in ("0.03", "0.05", "0.08", "0.12", "0.20"):
            v = [float(r["worst_f1"]) for r in rows if r["dataset"] == ds and abs(float(r["rho"]) - float(rho)) < 1e-9]
            vals.append(f"{np.mean(v):.4f}")
        lines.append(ds + " & " + " & ".join(vals) + r" \\")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    (OUT / "table_supp_rhoval.tex").write_text("\n".join(lines) + "\n", encoding="utf8")


def prop_table():
    rows = list(csv.DictReader(open(OUTDIR / "propensity_deviation.csv", encoding="utf8")))
    lines = [r"\begin{table}[H]", r"\centering",
             r"\caption{Observed propensity deviation and the perturbation constant of Corollary~2. $e_p=\max|\hat p-p|$ over training rows and optional modalities; $\Delta_p=B_w\kappa e_p/p_{\min}^2$ with $B_w$ from Corollary~1 and $p_{\min}=0.08$.}",
             r"\label{tab:supp_propdev}", r"\small",
             r"\begin{tabular}{lccccc}", r"\toprule",
             r"Dataset & $e_p$ min & $e_p$ max & $\Delta_p$ min & $\Delta_p$ max & $B_w$\\", r"\midrule"]
    for ds in ("MHEALTH", "UCI-HAR"):
        a = [r for r in rows if r["dataset"] == ds]
        ep = [float(r["e_p_train"]) for r in a]
        dp = [float(r["Delta_p"]) for r in a]
        lines.append(f"{ds} & {min(ep):.4f} & {max(ep):.4f} & {min(dp):.1f} & {max(dp):.1f} & {float(a[0]['B_w']):.2f} \\\\")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    (OUT / "table_supp_propdev.tex").write_text("\n".join(lines) + "\n", encoding="utf8")


if __name__ == "__main__":
    primary_table(); supp_impute_table(); sim_table(); rho_table(); prop_table()
    print("tables written")
