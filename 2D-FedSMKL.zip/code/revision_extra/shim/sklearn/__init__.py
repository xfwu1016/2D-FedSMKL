"""Import shims for the run_public_benchmarks module in a NumPy-only runtime."""
