class PCA:
    def __init__(self, *a, **k):
        raise RuntimeError("PCA shim: not available in this runtime")
