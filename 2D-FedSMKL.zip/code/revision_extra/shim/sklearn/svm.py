class LinearSVC:
    def __init__(self, *a, **k):
        raise RuntimeError("LinearSVC shim: not available in this runtime")
