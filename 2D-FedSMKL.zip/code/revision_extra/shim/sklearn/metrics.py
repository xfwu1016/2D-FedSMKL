"""Minimal shims so run_public_benchmarks.py imports without scipy/sklearn.

Only metrics are needed for the new experiments; PCA/LinearSVC are never called.
"""
import numpy as np


def f1_score(y_true, y_pred, average="macro", zero_division=0):
    y_true = np.asarray(y_true)
    y_pred = np.asarray(y_pred)
    labels = np.union1d(np.unique(y_true), np.unique(y_pred))
    f1s = []
    for c in labels:
        tp = np.sum((y_true == c) & (y_pred == c))
        fp = np.sum((y_true != c) & (y_pred == c))
        fn = np.sum((y_true == c) & (y_pred != c))
        prec = tp / (tp + fp) if tp + fp else 0.0
        rec = tp / (tp + fn) if tp + fn else 0.0
        f1s.append(2 * prec * rec / (prec + rec) if prec + rec else 0.0)
    return float(np.mean(f1s))


def balanced_accuracy_score(y_true, y_pred):
    y_true = np.asarray(y_true)
    y_pred = np.asarray(y_pred)
    labels = np.unique(y_true)
    recalls = [np.mean(y_pred[y_true == c] == c) for c in labels]
    return float(np.mean(recalls))


def accuracy_score(y_true, y_pred):
    return float(np.mean(np.asarray(y_true) == np.asarray(y_pred)))
