"""Primary-budget check of the conditional-imputation variant.

Ten primary test masks, 1400 rounds, selected rho, both datasets.
Methods: conditional imputation + mean aggregation, conditional imputation +
robust aggregation. Compared with the published IPW-mean and zero-fill rows.
"""
import csv
import math
import sys
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
PKG = ROOT
sys.path.insert(0, str(Path(__file__).resolve().parent / "shim"))
sys.path.insert(0, str(PKG / "code"))

import numpy as np
import run_public_benchmarks as rpb
from sklearn.metrics import f1_score, balanced_accuracy_score

DATA = {
    "MHEALTH": PKG / "results_revision" / "primary_v20_mhealth_processed.npz",
    "UCI-HAR": PKG / "results_revision" / "primary_v20_har_processed.npz",
}
RAW = {"MHEALTH": "primary_v20_raw_MHEALTH.csv", "UCI-HAR": "primary_v20_raw_UCI-HAR.csv"}
PAR = dict(tau=4., lam0=.012, lam1=.0035, eps=1e-4)
RHO = {"MHEALTH": 0.12, "UCI-HAR": 0.20}
T975_9 = 2.2621571628540993


def site_metrics(y, p, site):
    S = int(site.max() + 1)
    f = [f1_score(y[site == s], p[site == s]) for s in range(S)]
    b = [balanced_accuracy_score(y[site == s], p[site == s]) for s in range(S)]
    return float(np.mean(f)), float(np.min(f)), float(np.mean(b)), float(np.min(b))


def impute_conditional(Xtr, Xte, mask_tr, mask_te, groups, ridge=1e-2):
    Ztr = np.c_[np.ones(len(Xtr)), Xtr[:, groups[0]]]
    Zte = np.c_[np.ones(len(Xte)), Xte[:, groups[0]]]
    Atr = Xtr.copy(); Ate = Xte.copy()
    for m in range(1, len(groups)):
        g = groups[m]; obs = mask_tr[:, m] > 0.5
        Z = Ztr[obs]; Y = Xtr[np.ix_(obs, g)]
        G = Z.T @ Z + ridge * np.eye(Z.shape[1]); G[0, 0] -= ridge
        B = np.linalg.solve(G, Z.T @ Y)
        Atr[np.ix_(~obs, g)] = Ztr[~obs] @ B
        mte = mask_te[:, m] < 0.5
        Ate[np.ix_(mte, g)] = Zte[mte] @ B
    return Atr, Ate


def main():
    rows = []
    for ds in DATA:
        Xtr, Xte, ytr, yte, strn, stst, groups = rpb.load_processed(DATA[ds])
        C = int(max(ytr.max(), yte.max()) + 1)
        rho = RHO[ds]
        for i in range(10):
            seed = 20260820 + i
            miss = rpb.make_missingness(Xtr, Xte, strn, stst, groups, .35, seed)
            im_tr, im_te = impute_conditional(Xtr, Xte, miss["mask_tr"], miss["mask_te"], groups)
            for name, robust in (("Conditional imputation (mean)", False),
                                 ("Conditional imputation (robust)", True)):
                th, info = rpb.fit_smooth(im_tr, ytr, strn, groups, C, robust=robust,
                                          rho=rho if robust else .05, max_iter=1400, **PAR)
                m = site_metrics(yte, rpb.predict(th, im_te, C), stst)
                rows.append(dict(dataset=ds, seed=seed, method=name, rho=rho if robust else "",
                                 mean_f1=m[0], worst_f1=m[1], mean_ba=m[2], worst_ba=m[3]))
                print(ds, seed, name, round(m[1], 4), flush=True)
    out = Path(__file__).resolve().parent / "out" / "impute_primary.csv"
    with open(out, "w", newline="", encoding="utf8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
    for ds in DATA:
        pub = defaultdict(dict)
        for r in csv.DictReader(open(PKG / "results_revision" / RAW[ds], encoding="utf8")):
            if r["method"] in ("2D-FedSMKL", "IPW mean SMKL", "Zero-fill SMKL"):
                pub[int(r["seed"])][r["method"]] = float(r["worst_macro_f1"])
        mine = defaultdict(dict)
        for r in rows:
            if r["dataset"] == ds:
                mine[r["method"]][r["seed"]] = r["worst_f1"]
        seeds = sorted(mine["Conditional imputation (robust)"])
        print(f"\n{ds}:")
        for name in ("Conditional imputation (mean)", "Conditional imputation (robust)"):
            print(f"  {name:34s} {np.mean([mine[name][s] for s in seeds]):.4f}")
            for ref in ("IPW mean SMKL", "Zero-fill SMKL", "2D-FedSMKL"):
                d = [mine[name][s] - pub[s][ref] for s in seeds]
                mu = float(np.mean(d)); hw = T975_9 * float(np.std(d, ddof=1)) / math.sqrt(len(d))
                print(f"     vs {ref:16s} {mu:+.4f} [{mu-hw:+.4f},{mu+hw:+.4f}]")
    print("wrote", out)


if __name__ == "__main__":
    main()
