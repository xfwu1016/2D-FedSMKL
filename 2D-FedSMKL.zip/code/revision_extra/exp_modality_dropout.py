"""Modality-dropout training baseline.

A common missing-modality strategy: during training, randomly remove optional
blocks (keep probability 0.7 per block and row), then train the same smooth
decision layer; at test time, absent blocks are mean-filled. Three augmented
copies are concatenated with the original training set.

Budget: 350 rounds, 20 masks (seeds 20261101-20261120), matching the secondary
correction table in Supplementary S2.
"""
import csv
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
PKG = ROOT
sys.path.insert(0, str(Path(__file__).resolve().parent / "shim"))
sys.path.insert(0, str(PKG / "code"))

import numpy as np
import run_public_benchmarks as rpb
from sklearn.metrics import f1_score, balanced_accuracy_score

DATA = {
    "MHEALTH": PKG / "results_revision" / "primary_v20_mhealth_processed.npz",
    "UCI-HAR": PKG / "results_revision" / "primary_v20_har_processed.npz",
}
PAR = dict(tau=4., lam0=.012, lam1=.0035, eps=1e-4)
SEEDS = [20261101 + i for i in range(20)]
COPIES = 3
KEEP = 0.7


def site_metrics(y, p, site):
    S = int(site.max() + 1)
    f = [f1_score(y[site == s], p[site == s]) for s in range(S)]
    b = [balanced_accuracy_score(y[site == s], p[site == s]) for s in range(S)]
    return float(np.mean(f)), float(np.min(f)), float(np.mean(b)), float(np.min(b))


def augment(X, y, site, mask, groups, rng):
    Xs, ys, ss = [X], [y], [site]
    for _ in range(COPIES):
        keep = np.ones((len(X), len(groups)))
        for m in range(1, len(groups)):
            keep[:, m] = (rng.random(len(X)) < KEEP).astype(float)
        A = X.copy()
        for m, g in enumerate(groups):
            A[:, g] *= keep[:, m, None]
        Xs.append(A); ys.append(y); ss.append(site)
    return np.vstack(Xs), np.concatenate(ys), np.concatenate(ss)


def main():
    rows = []
    for ds in DATA:
        Xtr, Xte, ytr, yte, strn, stst, groups = rpb.load_processed(DATA[ds])
        C = int(max(ytr.max(), yte.max()) + 1)
        for seed in SEEDS:
            miss = rpb.make_missingness(Xtr, Xte, strn, stst, groups, .35, seed)
            rng = np.random.default_rng(seed + 7)
            Xa, ya, sa = augment(miss["zero_tr"], ytr, strn, miss["mask_tr"], groups, rng)
            th, info = rpb.fit_smooth(Xa, ya, sa, groups, C, robust=False, rho=.05,
                                      max_iter=350, **PAR)
            m = site_metrics(yte, rpb.predict(th, miss["zero_te"], C), stst)
            rows.append(dict(dataset=ds, seed=seed, method="Modality-dropout training",
                             mean_f1=m[0], worst_f1=m[1], mean_ba=m[2], worst_ba=m[3],
                             train_n=len(ya)))
            print(ds, seed, round(m[1], 4), flush=True)
    out = ROOT / "rerun" / "out" / "modality_dropout.csv"
    out.parent.mkdir(parents=True, exist_ok=True)
    with open(out, "w", newline="", encoding="utf8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
    for ds in DATA:
        a = [r["worst_f1"] for r in rows if r["dataset"] == ds]
        print(ds, "modality-dropout worst mean", round(float(np.mean(a)), 4))
    print("wrote", out)


if __name__ == "__main__":
    main()
