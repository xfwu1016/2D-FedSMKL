"""Re-select rho on ten validation masks (validation data only).

Protocol unchanged: train on the inner-training partition, evaluate on the
inner-validation partition, 1400-round budget, 35% absence. Selection rule
unchanged: maximize mean validation worst-site macro-F1; tie-break mean-site
F1; then the smaller candidate.
"""
import argparse
import csv
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
PKG = ROOT
sys.path.insert(0, str(Path(__file__).resolve().parent / "shim"))
sys.path.insert(0, str(PKG / "code"))

import numpy as np
import run_public_benchmarks as rpb
from sklearn.metrics import f1_score, balanced_accuracy_score

DATA = {
    "MHEALTH": PKG / "results_revision" / "validation_inner_mhealth.npz",
    "UCI-HAR": PKG / "results_revision" / "validation_inner_har.npz",
}
PAR = dict(tau=4., lam0=.012, lam1=.0035, eps=1e-4)
SEEDS = [20261131 + i for i in range(10)]
RHOS = [0.03, 0.05, 0.08, 0.12, 0.20]


def site_metrics(y, p, site):
    S = int(site.max() + 1)
    f = [f1_score(y[site == s], p[site == s]) for s in range(S)]
    b = [balanced_accuracy_score(y[site == s], p[site == s]) for s in range(S)]
    return float(np.mean(f)), float(np.min(f)), float(np.mean(b)), float(np.min(b))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--rounds", type=int, default=1400)
    ap.add_argument("--datasets", nargs="+", default=["MHEALTH", "UCI-HAR"])
    ap.add_argument("--outdir", type=Path, default=Path(__file__).resolve().parent / "out")
    args = ap.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    rows = []
    for ds in args.datasets:
        Xtr, Xte, ytr, yte, strn, stst, groups = rpb.load_processed(DATA[ds])
        C = int(max(ytr.max(), yte.max()) + 1)
        for seed in SEEDS:
            miss = rpb.make_missingness(Xtr, Xte, strn, stst, groups, .35, seed)
            for rho in RHOS:
                th, info = rpb.fit_smooth(miss["ipw_tr"], ytr, strn, groups, C,
                                          robust=True, rho=rho, max_iter=args.rounds, **PAR)
                m = site_metrics(yte, rpb.predict(th, miss["ipw_te"], C), stst)
                rows.append(dict(dataset=ds, seed=seed, rho=rho, rounds=args.rounds,
                                 mean_f1=m[0], worst_f1=m[1], mean_ba=m[2], worst_ba=m[3],
                                 iterations=info["iterations"]))
                print(ds, seed, rho, round(m[1], 4), flush=True)
    p = args.outdir / f"rho_validation10_{args.rounds}.csv"
    with open(p, "w", newline="", encoding="utf8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
    print("\nselection (10 masks):")
    for ds in args.datasets:
        cand = []
        for rho in RHOS:
            a = [r for r in rows if r["dataset"] == ds and r["rho"] == rho]
            cand.append((float(np.mean([r["worst_f1"] for r in a])),
                         float(np.mean([r["mean_f1"] for r in a])), rho,
                         float(np.std([r["worst_f1"] for r in a], ddof=1))))
        cand.sort(key=lambda t: (-t[0], -t[1], t[2]))
        print(ds, "selected", cand[0][2], "mean worst", round(cand[0][0], 4))
        for c in sorted(cand, key=lambda t: t[2]):
            print("   rho", c[2], "worst", round(c[0], 4), "mean", round(c[1], 4), "sd", round(c[3], 4))
    print("wrote", p)


if __name__ == "__main__":
    main()
