#!/usr/bin/env python3
"""Multiclass row/column message-interface audit; no physical-network claims.

Fixed before fitting: cache, missingness seed/rate, objective, zero initialization,
350 accepted rounds, initial L=1, doubling backtracking, absolute reference gap
1e-3. No test labels are used for optimization or parameter selection.

Topology: a separate global coordinator, A row coordinators, A*B feature workers.
Float64 application payloads are counted for every explicit message below, even
when A=B=1; all processes are emulated sequentially on one CPU thread. Each
feature worker owns only a COPY of its row/column block. Row coordinators own
labels/site ids. Static setup (features, labels, ids, site counts), packet headers,
encryption, and test/audit computation are excluded. Broadcast is charged once
per recipient (no multicast). Scores and derivatives have C components/sample.
The model is shared across row replicas; modality norms are reduced from the B
workers of the first row only, with zero entries for unowned modality pieces.
The coordinator never receives feature blocks or calls central matrix products.
"""
from __future__ import annotations
import argparse, csv, hashlib, json, math, time
from pathlib import Path
import numpy as np
from scipy.optimize import minimize
from threadpoolctl import threadpool_limits
from run_public_benchmarks import load_processed, make_missingness, obj_grad, mc_loss_grad_scores

PARAMS = dict(tau=4., lam0=.012, lam1=.0035, eps=1e-4, rho=.05, robust=True, eta_b=.05)
SEED=20261101
TARGET=1e-3

class FeatureWorker:
    def __init__(self, block, cols, groups):
        self.block=np.ascontiguousarray(block).copy()
        self.cols=cols.copy()
        self.local_groups=[np.flatnonzero(np.isin(cols,g)) for g in groups]
    def scores(self, W): return self.block @ W
    def loss_gradient(self, score_derivatives): return self.block.T @ score_derivatives
    def squared_norms(self,W):
        return np.array([np.sum(W[g]*W[g]) for g in self.local_groups])
    def penalty_gradient(self,W,coefficients):
        out=PARAMS['lam0']*W
        for g,c in zip(self.local_groups,coefficients):out[g]+=c*W[g]
        return out

class MessageGrid:
    def __init__(self,X,y,site,groups,C,A,B):
        self.n,self.d=X.shape;self.C=C;self.A=A;self.B=B
        self.cols=np.array_split(np.arange(self.d),B)
        rows=np.array_split(np.arange(self.n),A)
        self.workers=[[FeatureWorker(X[np.ix_(r,c)],c,groups) for c in self.cols] for r in rows]
        self.labels=[y[r].copy() for r in rows];self.sites=[site[r].copy() for r in rows]
        self.S=int(site.max()+1);self.ns=np.bincount(site,minlength=self.S).astype(float)
        self.pi=self.ns/self.ns.sum();self.M=len(groups);self.ledger={};self.calls={'gradient':0,'score_only':0}
    def send(self,channel,array,charge):
        if charge:self.ledger[channel]=self.ledger.get(channel,0)+array.nbytes
        return array
    def evaluate(self,theta,gradient=True,charge=True):
        if charge:self.calls['gradient' if gradient else 'score_only']+=1
        W=theta[:self.d*self.C].reshape(self.d,self.C);b=theta[self.d*self.C:]
        localW=[];scores=[];derivatives=[];risk_sums=np.zeros(self.S)
        for a,row in enumerate(self.workers):
            ws=[self.send('parameter_blocks',np.ascontiguousarray(W[c]),charge) for c in self.cols]
            localW.append(ws)
            bb=self.send('intercept_broadcast',b,charge)
            sc=sum(self.send('partial_scores',w.scores(ww),charge) for w,ww in zip(row,ws))+bb
            scores.append(sc)
            losses,gs=mc_loss_grad_scores(sc,self.labels[a],PARAMS['tau'])
            derivatives.append(gs)
            sums=np.bincount(self.sites[a],weights=losses,minlength=self.S)
            risk_sums+=self.send('site_loss_summaries',sums,charge)
        R=risk_sums/self.ns
        z=R/PARAMS['rho']+np.log(self.pi);mx=z.max();ex=np.exp(z-mx);q=ex/ex.sum()
        risk=PARAMS['rho']*(mx+np.log(ex.sum()))
        ss=sum(self.send('modality_squared_norm_summaries',w.squared_norms(ww),charge)
               for w,ww in zip(self.workers[0],localW[0]))
        norms=np.sqrt(ss+PARAMS['eps']**2);GG=norms.sum()
        reg=.5*PARAMS['lam0']*(ss.sum()+PARAMS['eta_b']*(b@b))+.5*PARAMS['lam1']*GG*GG
        if not gradient:return float(risk+reg),None
        gw=np.zeros_like(W);gb=np.zeros_like(b)
        for a,row in enumerate(self.workers):
            qq=self.send('site_weight_broadcast',q,charge)
            gd=derivatives[a]*(qq[self.sites[a]]/self.ns[self.sites[a]])[:,None]
            for w,c in zip(row,self.cols):
                received=self.send('weighted_score_derivatives',gd,charge)
                gw[c]+=self.send('feature_gradient_blocks',w.loss_gradient(received),charge)
            gb+=self.send('intercept_gradient_summaries',gd.sum(0),charge)
        coeff=PARAMS['lam1']*GG/norms
        for w,ww,c in zip(self.workers[0],localW[0],self.cols):
            cc=self.send('modality_coefficient_broadcast',coeff,charge)
            gw[c]+=self.send('penalty_gradient_blocks',w.penalty_gradient(ww,cc),charge)
        gb+=PARAMS['lam0']*PARAMS['eta_b']*b
        return float(risk+reg),np.r_[gw.ravel(),gb]
    def score_audit(self,theta):
        W=theta[:self.d*self.C].reshape(self.d,self.C);b=theta[self.d*self.C:]
        return np.concatenate([sum(w.scores(W[c]) for w,c in zip(row,self.cols))+b for row in self.workers])

def optimize(evaluate,p,method,rounds,ledger=None):
    theta=np.zeros(p);u=theta.copy();t=1.;L=1.;trace=[];trials=0;start=time.perf_counter()
    for it in range(rounds):
        before=sum(ledger.values()) if ledger is not None else 0
        fu,gu=evaluate(u,True);accepted=False;this_trials=0
        for _ in range(40):
            candidate=u-gu/L;fc,_=evaluate(candidate,False);trials+=1;this_trials+=1
            diff=candidate-u;bound=fu+gu@diff+.5*L*(diff@diff)
            if fc<=bound+1e-10:accepted=True;break
            L*=2
        if not accepted:raise RuntimeError('No accepted quadratic majorant')
        tn=.5*(1+math.sqrt(1+4*t*t)) if method=='FISTA' else 1.
        u=candidate+((t-1)/tn)*(candidate-theta) if method=='FISTA' else candidate.copy()
        theta=candidate;t=tn
        total=sum(ledger.values()) if ledger is not None else 0
        trace.append(dict(round=it+1,objective=fc,L=L,score_only_trials=this_trials,
                          cumulative_score_only_trials=trials,payload_bytes=total-before,cumulative_payload_bytes=total))
    return theta,trace,time.perf_counter()-start

def write_csv(path,rows):
    with path.open('w',newline='',encoding='utf8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--datasets',nargs='+',default=['mhealth','har'])
    ap.add_argument('--rounds',type=int,default=350)
    ap.add_argument('--legacy-cache',action='store_true',help='Development only: use the historical cache, not the v20 primary cache.')
    args=ap.parse_args()
    root=Path(__file__).resolve().parents[1];out=root/'results_revision';out.mkdir(exist_ok=True)
    summaries=[];alltraces=[];audits=[];details={}
    for dataset in args.datasets:
        cache=(root/'results_public'/f'{dataset}_processed.npz') if args.legacy_cache else (out/f'primary_v20_{dataset}_processed.npz')
        X,Xte,y,yte,site,site_te,groups=load_processed(cache)
        missing=make_missingness(X,Xte,site,site_te,groups,.35,SEED)
        X=missing['ipw_tr'];Xte=missing['ipw_te'];C=int(y.max()+1);d=X.shape[1];p=(d+1)*C
        def central(theta,gradient=True):
            f,g,_,_=obj_grad(theta,X,y,site,groups,C,**PARAMS)
            return f,g if gradient else None
        # Independent high-accuracy optimizer; best evaluated objective is a numerical reference, not J*.
        ref_values=[];ref_best=[float('inf'),None]
        def ref_fun(theta):
            f,g=central(theta);ref_values.append(float(f))
            if f<ref_best[0]:ref_best[:]=[f,theta.copy()]
            return f,g
        start=time.perf_counter()
        reference=minimize(ref_fun,np.zeros(p),jac=True,method='L-BFGS-B',
                           options=dict(maxiter=4000,maxls=50,ftol=1e-15,gtol=1e-10,maxcor=30))
        ref_time=time.perf_counter()-start;fref,thref=ref_best;_,gref=central(thref)
        mu=PARAMS['lam0']*min(1,PARAMS['eta_b'])
        central_fista,central_trace,central_time=optimize(central,p,'FISTA',args.rounds)
        central_gd,_,central_gd_time=optimize(central,p,'GD',args.rounds)
        sc= X@central_fista[:d*C].reshape(d,C)+central_fista[d*C:]
        testsc=Xte@central_fista[:d*C].reshape(d,C)+central_fista[d*C:]
        details[dataset]=dict(cache=str(cache.relative_to(root)),cache_sha256=hashlib.sha256(cache.read_bytes()).hexdigest(),
            n_train=len(y),d=d,C=C,n_sites=int(site.max()+1),
            reference_objective=fref,reference_gradient_norm=float(np.linalg.norm(gref)),
            reference_certificate_upper_gap=float(gref@gref/(2*mu)),reference_success=bool(reference.success),
            reference_status=str(reference.message),reference_iterations=int(reference.nit),
            reference_evaluations=len(ref_values),reference_seconds=ref_time,central_fista_seconds=central_time,
            central_gd_seconds=central_gd_time,
            reference_definition='Best observed L-BFGS-B objective; not an exact optimum J*.',layouts={})
        np.savez_compressed(out/f'hybrid_{dataset}_parameters.npz',reference=thref,central_fista=central_fista,central_gd=central_gd)
        write_csv(out/f'hybrid_{dataset}_reference_trace.csv',[dict(evaluation=i+1,objective=v,best_observed=min(ref_values[:i+1])) for i,v in enumerate(ref_values)])
        print(f'{dataset}: reference {ref_time:.2f}s, gradient {np.linalg.norm(gref):.3g}; central {args.rounds} rounds {central_time:.2f}s',flush=True)
        rng=np.random.default_rng(SEED);probe=rng.normal(0,.03,p)
        direction=rng.normal(size=p);direction/=np.linalg.norm(direction)
        for A,B in [(1,1),(2,2),(4,4)]:
            for method in ['FISTA','GD']:
                grid=MessageGrid(X,y,site,groups,C,A,B)
                for label,theta in [('zero',np.zeros(p)),('random',probe),('reference',thref)]:
                    fc,gc=central(theta);fm,gm=grid.evaluate(theta,charge=False)
                    fp,_=grid.evaluate(theta+1e-6*direction,False,False)
                    fn,_=grid.evaluate(theta-1e-6*direction,False,False)
                    directional_error=abs((fp-fn)/2e-6-gm@direction)
                    audits.append(dict(dataset=dataset,A=A,B=B,method=method,point=label,
                        objective_abs_error=abs(fm-fc),gradient_max_abs_error=float(np.max(np.abs(gm-gc))),
                        gradient_l2_error=float(np.linalg.norm(gm-gc)),directional_finite_difference_abs_error=float(directional_error)))
                    assert abs(fm-fc)<1e-10 and np.max(np.abs(gm-gc))<1e-10
                    assert directional_error<1e-7
                theta,trace,elapsed=optimize(grid.evaluate,p,method,args.rounds,grid.ledger)
                matched=central_fista if method=='FISTA' else central_gd
                matched_scores=X@matched[:d*C].reshape(d,C)+matched[d*C:]
                matched_testscores=Xte@matched[:d*C].reshape(d,C)+matched[d*C:]
                f,g=grid.evaluate(theta,charge=False);fcentral,gcentral=central(theta)
                testgrid=MessageGrid(Xte,yte,site_te,groups,C,A,B)
                gridscores=grid.score_audit(theta);gridtestscores=testgrid.score_audit(theta)
                owncentral=X@theta[:d*C].reshape(d,C)+theta[d*C:]
                assert np.max(np.abs(gridscores-owncentral))<1e-10
                hit=next((r for r in trace if r['objective']-fref<=TARGET),None)
                summary=dict(dataset=dataset,A=A,B=B,method=method,rounds=args.rounds,
                    final_objective=f,reference_objective=fref,reference_gap=f-fref,
                    terminal_gradient_norm=float(np.linalg.norm(g)),certificate_upper_gap=float(g@g/(2*mu)),
                    target_gap=TARGET,first_target_round=hit['round'] if hit else '',
                    first_target_bytes=hit['cumulative_payload_bytes'] if hit else '',
                    score_only_trials=grid.calls['score_only'],payload_bytes=sum(grid.ledger.values()),
                    seconds_sequential_emulation=elapsed,objective_abs_error=abs(f-fcentral),
                    gradient_max_abs_error=float(np.max(np.abs(g-gcentral))),
                    parameter_max_abs_vs_same_method_central=float(np.max(np.abs(theta-matched))),
                    score_max_abs_vs_same_method_central=float(np.max(np.abs(gridscores-matched_scores))),
                    test_prediction_agreement_vs_same_method_central=float(np.mean(gridtestscores.argmax(1)==matched_testscores.argmax(1))),
                    parameter_max_abs_vs_central_fista=float(np.max(np.abs(theta-central_fista))),
                    score_max_abs_vs_central_fista=float(np.max(np.abs(gridscores-sc))),
                    test_prediction_agreement_vs_central_fista=float(np.mean(gridtestscores.argmax(1)==testsc.argmax(1))))
                summaries.append(summary)
                assert summary['parameter_max_abs_vs_same_method_central']<1e-8
                assert summary['test_prediction_agreement_vs_same_method_central']==1
                details[dataset]['layouts'][f'{A}x{B}_{method}']=dict(ledger_bytes=grid.ledger,calls=grid.calls,
                    column_indices=[c.tolist() for c in grid.cols],
                    modality_pieces_per_column=[[len(g) for g in w.local_groups] for w in grid.workers[0]])
                for r in trace:alltraces.append(dict(dataset=dataset,A=A,B=B,method=method,reference_gap=r['objective']-fref,**r))
                print(f'{dataset} {A}x{B} {method}: {elapsed:.2f}s gap={f-fref:.6g} target={summary["first_target_round"]}',flush=True)
        write_csv(out/'hybrid_summary.csv',summaries);write_csv(out/'hybrid_trace.csv',alltraces);write_csv(out/'hybrid_equivalence.csv',audits)
        provenance=dict(seed=SEED,missing_rate=.35,rounds=args.rounds,target_gap=TARGET,params=PARAMS,
            legacy_cache=bool(args.legacy_cache),
            float_bytes=8,threads=1,script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            source_objective_sha256=hashlib.sha256((root/'code'/'run_public_benchmarks.py').read_bytes()).hexdigest(),
            topology=__doc__,datasets=details)
        (out/'hybrid_protocol.json').write_text(json.dumps(provenance,indent=2),encoding='utf8')
    lines=[r'\begin{table}[t]',r'\centering',r'\caption{Multiclass hybrid message-interface audit on fixed public-data caches with 35\% imposed absence (seed 20261101). All methods use 350 accepted rounds and the same objective. Gap is relative to an independently optimized best observed central objective, not a known optimum. MiB counts float64 application payloads in the explicit separate-coordinator topology; it is not measured network traffic. A dash indicates that the $10^{-3}$ reference-gap target was not reached.}',r'\label{tab:revision_hybrid}',r'\small',r'\begin{tabular}{llrrrr}',r'\toprule',r'Data & Layout/method & Gap & $\|\nabla F\|$ & Target round & MiB \\',r'\midrule']
    for s in summaries:
        name='MHEALTH' if s['dataset']=='mhealth' else 'HAR'
        lines.append(f"{name} & {s['A']}x{s['B']} {s['method']} & {s['reference_gap']:.2e} & {s['terminal_gradient_norm']:.2e} & {s['first_target_round'] or '--'} & {s['payload_bytes']/2**20:.1f} \\")
    lines += [r'\bottomrule',r'\end{tabular}',r'\end{table}']
    # Ensure each data row has the two-backslash TeX row terminator.
    lines=[line+'\\' if line.endswith('\\') and not line.endswith('\\\\') else line for line in lines]
    (root/'generated').mkdir(exist_ok=True)
    (root/'generated'/'table_revision_hybrid.tex').write_text('\n'.join(lines)+'\n',encoding='utf8')

if __name__=='__main__':
    with threadpool_limits(limits=1):main()
