#!/usr/bin/env python3
"""Read-only schema audit for future governed clinical feature tables."""

from __future__ import annotations

import argparse
import csv
import json
from collections import Counter
from pathlib import Path


SITES = {"Shenzhen", "Guangzhou", "Kunming"}


def read_rows(path: Path):
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def key(row):
    return row.get("patient_id", ""), row.get("visit_id", "")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", required=True)
    parser.add_argument("--report", default="real_data_audit.json")
    args = parser.parse_args()
    data_dir = Path(args.data_dir)
    index_path = data_dir / "patient_index.csv"
    if not index_path.exists():
        raise SystemExit(f"Missing required file: {index_path}")
    index = read_rows(index_path)
    required = {"patient_id", "visit_id", "site", "endpoint_binary",
                "endpoint_date", "age_years", "sex"}
    missing_columns = sorted(required - set(index[0] if index else []))
    keys = [key(r) for r in index]
    duplicate_keys = [list(k) for k, count in Counter(keys).items() if count > 1]
    invalid_sites = sorted({r.get("site", "") for r in index} - SITES)
    invalid_endpoints = sorted({r.get("endpoint_binary", "") for r in index} - {"0", "1"})

    index_keys = set(keys)
    modalities = {}
    for name in ["demographic_exam", "gait_features", "ecg_features", "sleep_features"]:
        path = data_dir / f"{name}.csv"
        if not path.exists():
            modalities[name] = {"present": False}
            continue
        rows = read_rows(path)
        row_keys = [key(r) for r in rows]
        available = sum(r.get("available", "1") == "1" for r in rows)
        modalities[name] = {
            "present": True,
            "rows": len(rows),
            "available": available,
            "duplicate_keys": sum(c > 1 for c in Counter(row_keys).values()),
            "keys_not_in_index": sum(k not in index_keys for k in row_keys),
        }

    site_endpoint_counts = {}
    for (site, endpoint), count in Counter(
            (r.get("site"), r.get("endpoint_binary")) for r in index).items():
        site_endpoint_counts.setdefault(site, {})[endpoint] = count

    report = {
        "patient_index_rows": len(index),
        "missing_required_columns": missing_columns,
        "duplicate_index_keys": duplicate_keys[:100],
        "invalid_sites": invalid_sites,
        "invalid_endpoint_values": invalid_endpoints,
        "site_endpoint_counts": site_endpoint_counts,
        "modalities": modalities,
    }
    report_path = Path(args.report)
    report_path.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))
    if missing_columns or duplicate_keys or invalid_sites or invalid_endpoints:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
