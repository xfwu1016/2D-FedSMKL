#!/usr/bin/env python3
"""Regenerate public-data missingness stress and sensitivity diagnostics.

Run after ``run_public_benchmarks.py`` has created the processed audit caches.
The fixed seeds/iterations below match the manuscript's archived diagnostics.
"""
from pathlib import Path
import argparse
import numpy as np
from run_public_benchmarks import make_missingness, fit_smooth, predict, metrics, write_csv
from sklearn.model_selection import train_test_split


def load_cache(path):
    z=np.load(path)
    gs=z['group_starts']
    groups=[np.arange(int(gs[i]),int(gs[i+1])) for i in range(len(gs)-1)]
    return z['Xtr'],z['Xte'],z['ytr'],z['yte'],z['site_tr'],z['site_te'],groups


def fit_eval(Xtr,Xte,ytr,yte,strn,stst,groups,miss,kind,**kwargs):
    C=int(max(ytr.max(),yte.max())+1)
    if kind=='zero': Xa,Xb,robust=miss['zero_tr'],miss['zero_te'],False
    elif kind=='ipw': Xa,Xb,robust=miss['ipw_tr'],miss['ipw_te'],False
    else: Xa,Xb,robust=miss['ipw_tr'],miss['ipw_te'],True
    th,info=fit_smooth(Xa,ytr,strn,groups,C,robust=robust,**kwargs)
    return metrics(yte,predict(th,Xb,C),stst),info


def missingness_stress(outdir):
    rows=[]
    for dataset,cache in [('MHEALTH','mhealth_processed.npz'),('UCI-HAR','har_processed.npz')]:
        data=load_cache(outdir/cache); Xtr,Xte,ytr,yte,strn,stst,groups=data
        for rate in [.10,.35,.65]:
            for seed in [20260840,20260841,20260842]:
                miss=make_missingness(Xtr,Xte,strn,stst,groups,rate,seed)
                for label,kind in [('Zero-fill SMKL','zero'),('IPW mean SMKL','ipw'),('2D-FedSMKL','robust')]:
                    m,_=fit_eval(Xtr,Xte,ytr,yte,strn,stst,groups,miss,kind,
                        rho=.05,tau=4,lam0=.012,lam1=.0035,eps=1e-4,max_iter=350)
                    rows.append(dict(dataset=dataset,missing_rate=rate,seed=seed,method=label,**m))
    write_csv(outdir/'missingness_stress.csv',rows)


def hyperparameter_sensitivity(outdir):
    Xtr,Xte,ytr,yte,strn,stst,groups=load_cache(outdir/'mhealth_processed.npz')
    miss=make_missingness(Xtr,Xte,strn,stst,groups,.35,20260850)
    rows=[]
    specs=[('rho',[.03,.05,.08,.12,.20]),('tau',[2.,4.,8.]),('lambda1',[0.,.0015,.0035,.007])]
    for par,vals in specs:
        for val in vals:
            kw=dict(rho=.05,tau=4.,lam0=.012,lam1=.0035,eps=1e-4,max_iter=350)
            kw['lam1' if par=='lambda1' else par]=val
            m,info=fit_eval(Xtr,Xte,ytr,yte,strn,stst,groups,miss,'robust',**kw)
            rows.append(dict(dataset='MHEALTH',parameter=par,value=val,**m,iterations=info['iterations']))
    write_csv(outdir/'hyperparameter_sensitivity.csv',rows)



def source_validation(outdir):
    """Source-only 80/20 stratified validation used to freeze rho.

    The split is stratified by the joint site/class label. A single 35% MAR
    mask is generated on the source split. Selection maximizes worst-site
    macro-F1; ties are broken by mean-site macro-F1. No official/public test
    label is used.
    """
    rows=[]
    for dataset,cache in [('MHEALTH','mhealth_processed.npz'),('UCI-HAR','har_processed.npz')]:
        X,_,y,_,site,_,groups=load_cache(outdir/cache)
        C=int(y.max()+1); idx=np.arange(len(y)); strata=site*(C+1)+y
        tr,va=train_test_split(idx,test_size=.20,random_state=20260809,stratify=strata)
        miss=make_missingness(X[tr],X[va],site[tr],site[va],groups,.35,20260810)
        for rho in [.03,.05,.08,.12,.20]:
            th,info=fit_smooth(miss['ipw_tr'],y[tr],site[tr],groups,C,robust=True,
                rho=rho,tau=4,lam0=.012,lam1=.0035,eps=1e-4,max_iter=350)
            m=metrics(y[va],predict(th,miss['ipw_te'],C),site[va])
            rows.append(dict(dataset=dataset,rho=rho,lambda1=.0035,**m,iterations=info['iterations']))
    write_csv(outdir/'source_validation_grid.csv',rows)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--outdir',type=Path,default=Path('results_public'))
    ap.add_argument('--only',choices=['stress','sensitivity','validation','all'],default='all')
    args=ap.parse_args()
    if args.only in {'stress','all'}: missingness_stress(args.outdir)
    if args.only in {'sensitivity','all'}: hyperparameter_sensitivity(args.outdir)
    if args.only in {'validation','all'}: source_validation(args.outdir)
    print('public diagnostics completed:',args.only)

if __name__=='__main__': main()
