#!/usr/bin/env python3
"""Public-data validation for 2D-FedSMKL.

Datasets
--------
MHEALTH (UCI id 319): raw mHealth_subject*.log files.
UCI HAR (UCI id 240): official train/test 561-feature matrices.

The datasets are complete. We therefore impose reproducible blockwise MAR
sensor/modality absence as a controlled stress test on real sensor data. Raw
public data are not redistributed by this script; users download them from UCI.
"""
from __future__ import annotations
import argparse, csv, json, math, time
from pathlib import Path
from dataclasses import dataclass
import numpy as np
from sklearn.decomposition import PCA
from sklearn.metrics import balanced_accuracy_score, f1_score, accuracy_score
from sklearn.svm import LinearSVC


def expit(x):
    x=np.asarray(x,float); out=np.empty_like(x)
    p=x>=0; out[p]=1/(1+np.exp(-x[p])); e=np.exp(x[~p]); out[~p]=e/(1+e); return out


def fit_logistic_irls(X,y,ridge=1e-2,max_iter=50):
    b=np.zeros(X.shape[1]); I=np.eye(X.shape[1]); I[0,0]=0
    for _ in range(max_iter):
        eta=X@b; p=expit(eta); w=np.clip(p*(1-p),1e-5,None); z=eta+(y-p)/w
        H=X.T@(w[:,None]*X)+ridge*I; rhs=X.T@(w*z)
        nb=np.linalg.solve(H,rhs)
        if np.linalg.norm(nb-b) < 1e-8*(1+np.linalg.norm(b)): b=nb; break
        b=nb
    return b


def standardize_groups(Xtr,Xte,groups):
    Xtr=Xtr.copy(); Xte=Xte.copy()
    for g in groups:
        mu=Xtr[:,g].mean(0); sd=Xtr[:,g].std(0); sd=np.where(sd<1e-8,1,sd)
        Xtr[:,g]=(Xtr[:,g]-mu)/sd; Xte[:,g]=(Xte[:,g]-mu)/sd
    return Xtr,Xte


def load_processed(path: Path):
    """Load the deterministic feature cache distributed with the package."""
    with np.load(path) as z:
        starts=z['group_starts'].astype(int)
        groups=[np.arange(starts[i],starts[i+1]) for i in range(len(starts)-1)]
        return (z['Xtr'].copy(),z['Xte'].copy(),z['ytr'].copy(),z['yte'].copy(),
                z['site_tr'].copy(),z['site_te'].copy(),groups)


def mhealth_features(raw_dir: Path, window=100):
    """2-s non-overlapping, activity-homogeneous windows; 5 stats/channel."""
    feats=[]; ys=[]; subjects=[]; starts=[]
    channel_groups=[np.arange(0,3),np.arange(3,5),np.arange(5,14),np.arange(14,23)]
    for subj in range(1,11):
        candidates=[raw_dir/f"mHealth_subject{subj}.log", raw_dir/f"MHEALTHDATASET/mHealth_subject{subj}.log"]
        path=next((p for p in candidates if p.exists()),None)
        if path is None: raise FileNotFoundError(candidates[0])
        a=np.loadtxt(path); lab=a[:,23].astype(int)
        # contiguous non-null activity runs
        i=0
        while i<len(a):
            y=lab[i]; j=i+1
            while j<len(a) and lab[j]==y: j+=1
            if y>0:
                for st in range(i,j-window+1,window):
                    block=a[st:st+window,:23]
                    parts=[]
                    for cg in channel_groups:
                        z=block[:,cg]
                        parts.append(np.concatenate([z.mean(0),z.std(0),z.min(0),z.max(0),np.sqrt((z*z).mean(0))]))
                    feats.append(np.concatenate(parts)); ys.append(y-1); subjects.append(subj); starts.append(st)
            i=j
    X=np.asarray(feats,float); y=np.asarray(ys,int); sub=np.asarray(subjects,int); st=np.asarray(starts,int)
    # within-subject/activity chronological 70/30 split; windows are non-overlapping
    train=np.zeros(len(y),bool)
    for s in np.unique(sub):
        for c in np.unique(y):
            idx=np.where((sub==s)&(y==c))[0]
            idx=idx[np.argsort(st[idx])]
            cut=max(1,int(math.floor(.70*len(idx))))
            if len(idx)>1: cut=min(cut,len(idx)-1)
            train[idx[:cut]]=True
    # groups in feature order: 15,10,45,45
    sizes=[15,10,45,45]; groups=[]; o=0
    for d in sizes: groups.append(np.arange(o,o+d)); o+=d
    return X[train],X[~train],y[train],y[~train],sub[train]-1,sub[~train]-1,groups


def har_features(root: Path, pca_dim=25):
    def f(name):
        p=root/name
        if p.exists(): return p
        # official tree fallback
        p2=root/'UCI HAR Dataset'/name
        if p2.exists(): return p2
        raise FileNotFoundError(p)
    Xtr=np.loadtxt(f('har_X_train.txt') if (root/'har_X_train.txt').exists() else f('train/X_train.txt'))
    Xte=np.loadtxt(f('har_X_test.txt') if (root/'har_X_test.txt').exists() else f('test/X_test.txt'))
    ytr=np.loadtxt(f('har_y_train.txt') if (root/'har_y_train.txt').exists() else f('train/y_train.txt'),dtype=int)-1
    yte=np.loadtxt(f('har_y_test.txt') if (root/'har_y_test.txt').exists() else f('test/y_test.txt'),dtype=int)-1
    strn=np.loadtxt(f('har_subject_train.txt') if (root/'har_subject_train.txt').exists() else f('train/subject_train.txt'),dtype=int)
    stst=np.loadtxt(f('har_subject_test.txt') if (root/'har_subject_test.txt').exists() else f('test/subject_test.txt'),dtype=int)
    fp=f('har_features.txt') if (root/'har_features.txt').exists() else f('features.txt')
    names=[line.strip().split(maxsplit=1)[1] for line in open(fp,encoding='utf8')]
    gyro=np.array(['Gyro' in n for n in names]); acc=~gyro
    outtr=[]; outte=[]; groups=[]; o=0
    for mask in [acc,gyro]:
        A=Xtr[:,mask]; B=Xte[:,mask]
        mu=A.mean(0); sd=A.std(0); sd=np.where(sd<1e-8,1,sd); A=(A-mu)/sd; B=(B-mu)/sd
        k=min(pca_dim,A.shape[1],A.shape[0]-1)
        pca=PCA(n_components=k,svd_solver='randomized',random_state=20260809)
        A=pca.fit_transform(A); B=pca.transform(B)
        outtr.append(A); outte.append(B); groups.append(np.arange(o,o+k)); o+=k
    Xtr=np.concatenate(outtr,1); Xte=np.concatenate(outte,1)
    # Five synthetic silos, each containing disjoint train and test subjects.
    # The official subject-disjoint split is preserved.
    tr_sets=[[1,3,5,6],[7,8,11,14],[15,16,17,19],[21,22,23,25],[26,27,28,29,30]]
    te_sets=[[2,4],[9,10],[12,13],[18,20],[24]]
    site_tr=np.empty(len(strn),int); site_te=np.empty(len(stst),int)
    for s,(a,b) in enumerate(zip(tr_sets,te_sets)):
        site_tr[np.isin(strn,a)]=s; site_te[np.isin(stst,b)]=s
    assert set(np.unique(site_tr))==set(range(5)) and set(np.unique(site_te))==set(range(5))
    return Xtr,Xte,ytr,yte,site_tr,site_te,groups


def calibrate_intercept(base, site, target_obs, coef, offsets):
    def meanp(a): return expit(a+base@coef+offsets[site]).mean()
    lo,hi=-10.,10.
    for _ in range(60):
        mid=(lo+hi)/2
        if meanp(mid)<target_obs: lo=mid
        else: hi=mid
    return (lo+hi)/2


def make_missingness(Xtr,Xte,site_tr,site_te,groups,missing_rate,seed,pmin=.10):
    rng=np.random.default_rng(seed); M=len(groups); baseline=groups[0]
    k=min(3,len(baseline)); Ztr=Xtr[:,baseline[:k]]; Zte=Xte[:,baseline[:k]]
    # Ztr is standardized for MHEALTH and PCA-scaled for HAR; rescale predictor covariates.
    mu=Ztr.mean(0); sd=Ztr.std(0); sd=np.where(sd<1e-8,1,sd); Ztr=(Ztr-mu)/sd; Zte=(Zte-mu)/sd
    coef=np.array([.35,-.25,.15])[:k]
    S=int(max(site_tr.max(),site_te.max())+1); base_offsets=np.linspace(-.35,.35,S)
    mask_tr=np.ones((len(Xtr),M)); mask_te=np.ones((len(Xte),M)); ptrue_tr=np.ones_like(mask_tr); ptrue_te=np.ones_like(mask_te)
    phat_tr=np.ones_like(mask_tr); phat_te=np.ones_like(mask_te)
    one_tr=np.eye(S)[site_tr]; one_te=np.eye(S)[site_te]
    Dtr=np.c_[np.ones(len(Xtr)),Ztr,one_tr[:,1:]]; Dte=np.c_[np.ones(len(Xte)),Zte,one_te[:,1:]]
    for m in range(1,M):
        offsets=base_offsets*(1+.15*m)
        a=calibrate_intercept(Ztr,site_tr,1-missing_rate,coef,offsets)
        pt=expit(a+Ztr@coef+offsets[site_tr]); pe=expit(a+Zte@coef+offsets[site_te])
        rt=(rng.random(len(Xtr))<pt).astype(float); re=(rng.random(len(Xte))<pe).astype(float)
        beta=fit_logistic_irls(Dtr,rt)
        qt=np.clip(expit(Dtr@beta),pmin,.98); qe=np.clip(expit(Dte@beta),pmin,.98)
        mask_tr[:,m]=rt; mask_te[:,m]=re; ptrue_tr[:,m]=pt; ptrue_te[:,m]=pe; phat_tr[:,m]=qt; phat_te[:,m]=qe
    Xzero_tr=Xtr.copy(); Xzero_te=Xte.copy(); Xipw_tr=Xtr.copy(); Xipw_te=Xte.copy()
    for m,g in enumerate(groups):
        Xzero_tr[:,g]*=mask_tr[:,m,None]; Xzero_te[:,g]*=mask_te[:,m,None]
        Xipw_tr[:,g]*=(mask_tr[:,m]/phat_tr[:,m])[:,None]; Xipw_te[:,g]*=(mask_te[:,m]/phat_te[:,m])[:,None]
    return dict(zero_tr=Xzero_tr,zero_te=Xzero_te,ipw_tr=Xipw_tr,ipw_te=Xipw_te,mask_tr=mask_tr,mask_te=mask_te,phat_tr=phat_tr,phat_te=phat_te)


def mc_loss_grad_scores(scores,y,tau=4.0):
    n,C=scores.shape
    sy=scores[np.arange(n),y]
    v=tau*(1.0+scores-sy[:,None]); v[np.arange(n),y]=-np.inf
    mx=np.maximum(0,np.max(v,axis=1)); ev=np.exp(v-mx[:,None]); ev[np.arange(n),y]=0
    base=np.exp(-mx); den=base+ev.sum(1)
    loss=(mx+np.log(den))/tau
    P=ev/den[:,None]; G=P.copy(); G[np.arange(n),y]=-P.sum(1)
    return loss,G


def obj_grad(theta,X,y,site,groups,C,tau,lam0,lam1,eps,rho,robust,eta_b=.05):
    d=X.shape[1]; W=theta[:d*C].reshape(d,C); b=theta[d*C:]
    scores=X@W+b; losses,Gs=mc_loss_grad_scores(scores,y,tau)
    S=site.max()+1; R=np.array([losses[site==s].mean() for s in range(S)])
    ns=np.array([(site==s).sum() for s in range(S)],float); pi=ns/ns.sum()
    if robust:
        z=R/rho+np.log(pi); z-=z.max(); q=np.exp(z); q/=q.sum()
        # stable original logsumexp
        zz=R/rho+np.log(pi); mm=zz.max(); risk=rho*(mm+np.log(np.exp(zz-mm).sum()))
    else:
        q=pi; risk=float((pi*R).sum())
    wg=np.zeros(len(y))
    for s in range(S): wg[site==s]=q[s]/ns[s]
    gradW=X.T@(Gs*wg[:,None]); gradb=(Gs*wg[:,None]).sum(0)
    reg=.5*lam0*(np.sum(W*W)+eta_b*np.sum(b*b)); gradW+=lam0*W; gradb+=lam0*eta_b*b
    if lam1>0:
        norms=np.array([math.sqrt(float(np.sum(W[g]*W[g]))+eps*eps) for g in groups]); GG=norms.sum(); reg+=.5*lam1*GG*GG
        for g,nm in zip(groups,norms): gradW[g]+=lam1*GG*W[g]/nm
    return risk+reg,np.r_[gradW.ravel(),gradb],R,q


def fit_smooth(X,y,site,groups,C,robust=False,rho=.08,tau=4,lam0=.01,lam1=.003,eps=1e-4,max_iter=350,tol=2e-6):
    d=X.shape[1]; th=np.zeros(d*C+C); u=th.copy(); t=1.; L=1.; start=time.perf_counter(); hist=[]
    line_search_trials=0
    for it in range(max_iter):
        fu,gu,R,q=obj_grad(u,X,y,site,groups,C,tau,lam0,lam1,eps,rho,robust)
        accepted=False
        for _ in range(30):
            line_search_trials += 1
            cand=u-gu/L
            fc,_,_,_=obj_grad(cand,X,y,site,groups,C,tau,lam0,lam1,eps,rho,robust)
            diff=cand-u; bound=fu+gu@diff+.5*L*(diff@diff)
            if fc<=bound+1e-10: accepted=True; break
            L*=2
        if not accepted:
            raise RuntimeError("Backtracking failed to find a valid quadratic majorant")
        tn=.5*(1+math.sqrt(1+4*t*t)); un=cand+((t-1)/tn)*(cand-th)
        rel=np.linalg.norm(cand-th)/(1+np.linalg.norm(th)); th,u,t=cand,un,tn
        # Retain the accepted Lipschitz estimate; L is therefore nondecreasing.
        if it%10==0: hist.append((it,float(fc),float(rel)))
        if rel<tol and it>15: break
    elapsed=time.perf_counter()-start
    f,_,R,q=obj_grad(th,X,y,site,groups,C,tau,lam0,lam1,eps,rho,robust)
    return th,dict(iterations=it+1,time_sec=elapsed,objective=float(f),site_risk=R.tolist(),site_weight=q.tolist(),history=hist,line_search_trials=line_search_trials)


def predict(theta,X,C):
    d=X.shape[1]; W=theta[:d*C].reshape(d,C); b=theta[d*C:]; return np.argmax(X@W+b,1)


def local_grad(theta,X,y,C,tau,lam0,anchor=None,mu=0):
    d=X.shape[1]; W=theta[:d*C].reshape(d,C); b=theta[d*C:]; loss,G=mc_loss_grad_scores(X@W+b,y,tau)
    gw=X.T@G/len(y)+lam0*W; gb=G.mean(0)+.05*lam0*b; g=np.r_[gw.ravel(),gb]
    if anchor is not None and mu>0: g+=mu*(theta-anchor)
    return g


def fit_fedavg(X,y,site,C,prox=0.0,rounds=50,local_steps=5,lr=.025,lam0=.01):
    d=X.shape[1]; th=np.zeros(d*C+C); S=site.max()+1; start=time.perf_counter()
    ns=np.array([(site==s).sum() for s in range(S)],float); pi=ns/ns.sum()
    for r in range(rounds):
        locals=[]
        for s in range(S):
            ix=site==s; z=th.copy()
            for _ in range(local_steps): z-=lr*local_grad(z,X[ix],y[ix],C,4,lam0,th,prox)
            locals.append(z)
        th=sum(pi[s]*locals[s] for s in range(S))
    return th,dict(iterations=rounds,time_sec=time.perf_counter()-start)


def metrics(y,p,site):
    S=site.max()+1; f=[]; b=[]; a=[]
    for s in range(S):
        ix=site==s; f.append(f1_score(y[ix],p[ix],average='macro',zero_division=0)); b.append(balanced_accuracy_score(y[ix],p[ix])); a.append(accuracy_score(y[ix],p[ix]))
    return dict(mean_macro_f1=float(np.mean(f)),worst_macro_f1=float(np.min(f)),mean_bal_acc=float(np.mean(b)),worst_bal_acc=float(np.min(b)),pooled_accuracy=float(accuracy_score(y,p)))


def run_dataset(name,data,outdir,seeds,missing=.35,preprocessed=False):
    Xtr,Xte,ytr,yte,strn,stst,groups=data
    if not preprocessed:
        Xtr,Xte=standardize_groups(Xtr,Xte,groups)
    # Fixed local feature maps: for wider raw MHEALTH blocks, fit PCA on training data only.
    if not preprocessed and Xtr.shape[1] > 80:
        atr=[]; ate=[]; ng=[]; off=0
        for gi,g in enumerate(groups):
            k=min(15,len(g),Xtr.shape[0]-1)
            if len(g)>k:
                pc=PCA(n_components=k,svd_solver='randomized',random_state=20260809+gi)
                A=pc.fit_transform(Xtr[:,g]); B=pc.transform(Xte[:,g])
            else:
                A=Xtr[:,g]; B=Xte[:,g]; k=len(g)
            atr.append(A); ate.append(B); ng.append(np.arange(off,off+k)); off+=k
        Xtr=np.concatenate(atr,1); Xte=np.concatenate(ate,1); groups=ng
    C=int(max(ytr.max(),yte.max())+1)
    rows=[]; traces=[]
    # Source-only constants are frozen across missingness replications.
    selected_rho=.05
    pars=dict(tau=4.,lam0=.012,lam1=.0035,eps=1e-4,rho=selected_rho,max_iter=350)
    # Source-only validation settings frozen before public-test evaluation.
    if name == 'MHEALTH':
        svm_c, fed_lr, fedprox_mu, fed_rounds = 1.0, 0.025, 0.1, 200
    else:
        svm_c, fed_lr, fedprox_mu, fed_rounds = 10.0, 0.05, 0.1, 350
    thf,infof=fit_smooth(Xtr,ytr,strn,groups,C,robust=False,tau=4,lam0=.012,lam1=.0035,eps=1e-4,rho=.08,max_iter=350)
    predf=predict(thf,Xte,C)
    for rep,seed in enumerate(seeds):
        miss=make_missingness(Xtr,Xte,strn,stst,groups,missing,seed)
        methods=[]
        # pooled Linear SVM under zero filling
        t0=time.perf_counter(); svm=LinearSVC(C=svm_c,dual='auto',max_iter=6000); svm.fit(miss['zero_tr'],ytr); pp=svm.predict(miss['zero_te'])
        methods.append(('Pooled linear SVM',None,dict(iterations=np.nan,time_sec=time.perf_counter()-t0),pp))
        # complete case
        cc=(miss['mask_tr'][:,1:].min(1)>0) if len(groups)>1 else np.ones(len(ytr),bool)
        if cc.sum()>C*4:
            ccpars={k:v for k,v in pars.items() if k not in {'rho','lam1'}}; th,info=fit_smooth(Xtr[cc],ytr[cc],strn[cc],groups,C,robust=False,lam1=0,**ccpars)
            methods.append(('Complete-case CS',th,info,predict(th,miss['zero_te'],C)))
        # FedAvg/FedProx on zero-filled features
        th,info=fit_fedavg(miss['zero_tr'],ytr,strn,C,prox=0.0,rounds=fed_rounds,local_steps=5,lr=fed_lr,lam0=.012); methods.append(('FedAvg-CS',th,info,predict(th,miss['zero_te'],C)))
        th,info=fit_fedavg(miss['zero_tr'],ytr,strn,C,prox=fedprox_mu,rounds=fed_rounds,local_steps=5,lr=fed_lr,lam0=.012); methods.append(('FedProx-CS',th,info,predict(th,miss['zero_te'],C)))
        # centralized/distributed-equivalent smooth models
        th,info=fit_smooth(miss['zero_tr'],ytr,strn,groups,C,robust=False,**{k:v for k,v in pars.items() if k!='rho'}); methods.append(('Zero-fill SMKL',th,info,predict(th,miss['zero_te'],C)))
        th,info=fit_smooth(miss['ipw_tr'],ytr,strn,groups,C,robust=False,**{k:v for k,v in pars.items() if k!='rho'}); methods.append(('IPW mean SMKL',th,info,predict(th,miss['ipw_te'],C)))
        th,info=fit_smooth(miss['ipw_tr'],ytr,strn,groups,C,robust=True,**pars); methods.append(('2D-FedSMKL',th,info,predict(th,miss['ipw_te'],C)))
        # no-MKL ablation
        thn,inf=fit_smooth(miss['ipw_tr'],ytr,strn,groups,C,robust=True,tau=4,lam0=.012,lam1=0,eps=1e-4,rho=selected_rho,max_iter=350); methods.append(('2D-FedSMKL no MKL',thn,inf,predict(thn,miss['ipw_te'],C)))
        # Full-data oracle is deterministic and cached across missingness replications.
        methods.append(('Oracle full SMKL',thf,infof,predf))
        for method,th,info,pred in methods:
            m=metrics(yte,pred,stst); row=dict(dataset=name,replicate=rep,seed=seed,missing_rate=missing,method=method,complete_train_n=int(cc.sum()),train_n=len(ytr),test_n=len(yte),iterations=info.get('iterations',np.nan),line_search_trials=info.get('line_search_trials',np.nan),time_sec=info.get('time_sec',np.nan),**m)
            if th is not None and method in {'2D-FedSMKL','IPW mean SMKL','Zero-fill SMKL'}:
                d=Xtr.shape[1]; W=th[:d*C].reshape(d,C); norms=[float(np.linalg.norm(W[g])) for g in groups]; ss=sum(norms); row['modality_weights']=';'.join(f'{x/ss:.4f}' for x in norms) if ss else ''
            rows.append(row)
            if method=='2D-FedSMKL': traces.append(dict(dataset=name,replicate=rep,site_weight=info.get('site_weight'),site_risk=info.get('site_risk'),iterations=info.get('iterations')))
        print(name,'rep',rep,'done',[(r['method'],round(r['worst_macro_f1'],3)) for r in rows if r['dataset']==name and r['replicate']==rep][-9:])
    return rows,traces,(Xtr,Xte,ytr,yte,strn,stst,groups)


def sensitivity(name,data,outdir,seed=20260890):
    Xtr,Xte,ytr,yte,strn,stst,groups=data; C=int(max(ytr.max(),yte.max())+1); rows=[]
    for missing in [.10,.35,.65]:
        miss=make_missingness(Xtr,Xte,strn,stst,groups,missing,seed)
        for rho in [.04,.08,.16]:
            th,info=fit_smooth(miss['ipw_tr'],ytr,strn,groups,C,robust=True,rho=rho,tau=4,lam0=.012,lam1=.0035,eps=1e-4,max_iter=350)
            mm=metrics(yte,predict(th,miss['ipw_te'],C),stst); rows.append(dict(dataset=name,missing_rate=missing,rho=rho,**mm,iterations=info['iterations']))
    return rows


def write_csv(path,rows):
    if not rows: return
    keys=[]
    for r in rows:
        for k in r:
            if k not in keys: keys.append(k)
    with open(path,'w',newline='',encoding='utf8') as f:
        w=csv.DictWriter(f,fieldnames=keys); w.writeheader(); w.writerows(rows)


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--mhealth-dir',type=Path)
    ap.add_argument('--har-dir',type=Path)
    ap.add_argument('--processed-dir',type=Path,
                    help='directory containing the two packaged *_processed.npz caches')
    ap.add_argument('--outdir',type=Path,required=True)
    ap.add_argument('--replicates',type=int,default=10)
    ap.add_argument('--skip-sensitivity',action='store_true')
    args=ap.parse_args(); args.outdir.mkdir(parents=True,exist_ok=True)
    if args.processed_dir is not None:
        mh=load_processed(args.processed_dir/'mhealth_processed.npz')
        har=load_processed(args.processed_dir/'har_processed.npz')
        preprocessed=True
    else:
        if args.mhealth_dir is None or args.har_dir is None:
            ap.error('provide --processed-dir or both --mhealth-dir and --har-dir')
        mh=mhealth_features(args.mhealth_dir); har=har_features(args.har_dir)
        preprocessed=False
    seeds=[20260820+i for i in range(args.replicates)]
    allrows=[]; traces=[]
    r,t,mhstd=run_dataset('MHEALTH',mh,args.outdir,seeds,preprocessed=preprocessed); allrows+=r; traces+=t
    r,t,harstd=run_dataset('UCI-HAR',har,args.outdir,seeds,preprocessed=preprocessed); allrows+=r; traces+=t
    # Save deterministic processed feature matrices for numerical audit and
    # for the supplementary stress/sensitivity script. Original UCI raw data
    # are not redistributed.
    for fname,data in [('mhealth_processed.npz',mhstd),('har_processed.npz',harstd)]:
        Xtr,Xte,ytr,yte,strn,stst,groups=data
        starts=[int(g[0]) for g in groups]+[int(groups[-1][-1]+1)]
        np.savez_compressed(args.outdir/fname,Xtr=Xtr,Xte=Xte,ytr=ytr,yte=yte,site_tr=strn,site_te=stst,group_starts=np.asarray(starts,int))
    write_csv(args.outdir/'public_benchmark_raw.csv',allrows)
    sens=[] if args.skip_sensitivity else sensitivity('MHEALTH',mhstd,args.outdir); write_csv(args.outdir/'public_sensitivity.csv',sens)
    # aggregate
    summary=[]
    for ds in sorted(set(r['dataset'] for r in allrows)):
        for method in dict.fromkeys(r['method'] for r in allrows if r['dataset']==ds):
            a=[r for r in allrows if r['dataset']==ds and r['method']==method]
            row={'dataset':ds,'method':method,'n_rep':len(a)}
            for k in ['mean_macro_f1','worst_macro_f1','mean_bal_acc','worst_bal_acc','pooled_accuracy','time_sec','iterations']:
                v=np.array([float(x[k]) for x in a if x.get(k) not in ['',None] and np.isfinite(float(x[k]))])
                row[k+'_mean']=float(v.mean()) if len(v) else np.nan; row[k+'_sd']=float(v.std(ddof=1)) if len(v)>1 else 0.0
            summary.append(row)
    write_csv(args.outdir/'public_benchmark_summary.csv',summary)
    (args.outdir/'public_site_weights.json').write_text(json.dumps(traces,indent=2),encoding='utf8')
    meta={'mhealth_train':len(mhstd[2]),'mhealth_test':len(mhstd[3]),'har_train':len(harstd[2]),'har_test':len(harstd[3]),'replicates':args.replicates,'seeds':seeds,'timestamp_note':'deterministic controlled missingness','software':{'numpy':np.__version__,'scipy':__import__('scipy').__version__,'scikit_learn':__import__('sklearn').__version__,'matplotlib':__import__('matplotlib').__version__,'pandas':__import__('pandas').__version__}}
    (args.outdir/'public_benchmark_metadata.json').write_text(json.dumps(meta,indent=2),encoding='utf8')
    print(json.dumps(meta,indent=2))

if __name__=='__main__': main()
