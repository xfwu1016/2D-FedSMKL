"""Plot paired factorial component contrasts for Figure 5.

Values and unadjusted paired 95% t intervals are read directly from
generated/table_revision_factorial_paired.tex. No model is refitted.
"""
from pathlib import Path
import re
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
TABLE = ROOT / "generated" / "table_revision_factorial_paired.tex"
TEXT = TABLE.read_text(encoding="utf-8")

# Parse the exact reported contrast rows.
pattern = re.compile(
    r"(MHEALTH|UCI-HAR)\s*&\s*(35|65)\\%\s*&\s*"
    r"(Robust given IPW|Robust given zero|IPW given mean|IPW given robust)"
    r"\s*&\s*([+-]?\d+\.\d+)\s*&\s*"
    r"\[([+-]?\d+\.\d+),\s*([+-]?\d+\.\d+)\]"
)
parsed = {}
for dataset, rate, contrast, estimate, lower, upper in pattern.findall(TEXT):
    parsed[(dataset.replace("UCI-HAR", "UCI HAR"), rate, contrast)] = (
        float(estimate), float(lower), float(upper)
)

datasets = ["MHEALTH", "UCI HAR"]
rates = ["35", "65"]
contrasts = [
    ("Robust given IPW", "Robust − Mean | IPW"),
    ("Robust given zero", "Robust − Mean | Zero-fill"),
    ("IPW given mean", "IPW − Zero-fill | Mean"),
    ("IPW given robust", "IPW − Zero-fill | Robust"),
]
plt.rcParams.update({
    "font.family": "serif",
    "font.size": 9,
    "axes.titlesize": 10,
    "axes.labelsize": 9,
    "xtick.labelsize": 8,
    "ytick.labelsize": 8,
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
})
fig, axes = plt.subplots(2, 2, figsize=(18.0/2.54, 11.5/2.54), sharex=True)
for ax, dataset, rate in zip(
    axes.flat,
    ["MHEALTH", "MHEALTH", "UCI HAR", "UCI HAR"],
    ["35", "65", "35", "65"],
):
    y = list(range(len(contrasts)))[::-1]
    for yi, (key, label) in zip(y, contrasts):
        est, lo, hi = parsed[(dataset, rate, key)]
        ax.errorbar(
            est, yi, xerr=[[est-lo], [hi-est]], fmt="o",
            capsize=3, elinewidth=1.1, markersize=4.5
        )
    ax.axvline(0, linestyle="--", linewidth=0.9)
    ax.set_yticks(y, [label for _, label in contrasts])
    if ax is axes[0, 1] or ax is axes[1, 1]:
        ax.set_yticklabels([])
    ax.set_title(f"{dataset} — {rate}% absence", pad=6)
    ax.grid(axis="x", linestyle=":", linewidth=0.6)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.tick_params(axis="y", length=0, pad=4)
    ax.set_xlim(-0.027, 0.038)
fig.supxlabel("Paired difference in worst-site macro-F1", y=0.045)
fig.subplots_adjust(left=0.32, right=0.98, bottom=0.15, top=0.90, wspace=0.16, hspace=0.34)
fig.savefig(ROOT / "generated" / "public_missingness_stress_v22.pdf", bbox_inches="tight")
fig.savefig(ROOT / "generated" / "public_missingness_stress_v22.png", dpi=300, bbox_inches="tight")
