#!/usr/bin/env python3
"""Two-stage source-only validation for public benchmark baselines.

Stage 1 selects the learning rate/local-step/proximal settings at 50 rounds.
Stage 2 holds those settings fixed and selects communication rounds from
{50,100,200,350}. Public-test labels are never accessed.
"""
from pathlib import Path
import argparse, csv, sys
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.svm import LinearSVC
sys.path.insert(0, str(Path(__file__).resolve().parent))
from run_public_benchmarks import make_missingness, fit_fedavg, predict, metrics


def load_cache(path):
    z=np.load(path); gs=z['group_starts']
    groups=[np.arange(int(gs[i]),int(gs[i+1])) for i in range(len(gs)-1)]
    return z['Xtr'],z['ytr'],z['site_tr'],groups


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--outdir',type=Path,default=Path('results_public')); args=ap.parse_args()
    rows=[]
    for ds,cache in [('MHEALTH','mhealth_processed.npz'),('UCI-HAR','har_processed.npz')]:
        X,y,site,groups=load_cache(args.outdir/cache); C=int(y.max()+1)
        idx=np.arange(len(y)); strata=site*(C+1)+y
        tr,va=train_test_split(idx,test_size=.20,random_state=20260809,stratify=strata)
        miss=make_missingness(X[tr],X[va],site[tr],site[va],groups,.35,20260810)
        for c in [.1,1.,10.]:
            svm=LinearSVC(C=c,dual='auto',max_iter=6000).fit(miss['zero_tr'],y[tr])
            rows.append(dict(dataset=ds,method='LinearSVC',stage='model',C_svm=c,lr='',local_steps='',rounds='',mu='',**metrics(y[va],svm.predict(miss['zero_te']),site[va])))
        # Stage 1: optimization hyperparameters at a common 50-round budget.
        cand_avg=[]
        for lr in [.01,.025,.05]:
            for steps in [1,5]:
                th,_=fit_fedavg(miss['zero_tr'],y[tr],site[tr],C,prox=0,rounds=50,local_steps=steps,lr=lr,lam0=.012)
                mm=metrics(y[va],predict(th,miss['zero_te'],C),site[va]); cand_avg.append((mm['worst_macro_f1'],mm['mean_macro_f1'],lr,steps))
        _,_,avg_lr,avg_steps=max(cand_avg)
        cand_prox=[]
        for lr in [.01,.025,.05]:
            for mu in [.1,.5,1.]:
                th,_=fit_fedavg(miss['zero_tr'],y[tr],site[tr],C,prox=mu,rounds=50,local_steps=5,lr=lr,lam0=.012)
                mm=metrics(y[va],predict(th,miss['zero_te'],C),site[va]); cand_prox.append((mm['worst_macro_f1'],mm['mean_macro_f1'],lr,mu))
        _,_,prox_lr,prox_mu=max(cand_prox)
        # Stage 2: communication-round selection with Stage-1 settings fixed.
        for method,lr,steps,mu in [('FedAvg',avg_lr,avg_steps,0.0),('FedProx',prox_lr,5,prox_mu)]:
            for rounds in [50,100,200,350]:
                th,_=fit_fedavg(miss['zero_tr'],y[tr],site[tr],C,prox=mu,rounds=rounds,local_steps=steps,lr=lr,lam0=.012)
                rows.append(dict(dataset=ds,method=method,stage='rounds',C_svm='',lr=lr,local_steps=steps,rounds=rounds,mu=mu,**metrics(y[va],predict(th,miss['zero_te'],C),site[va])))
    out=args.outdir/'baseline_source_validation.csv'
    with open(out,'w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=rows[0].keys()); w.writeheader(); w.writerows(rows)
    print(out)

if __name__=='__main__': main()
