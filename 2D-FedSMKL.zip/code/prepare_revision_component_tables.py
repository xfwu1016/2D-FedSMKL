"""Build supplement tables from the frozen component study, without refitting."""
from pathlib import Path
import csv,json,statistics as st
from collections import defaultdict
P=Path(__file__).resolve().parents[1]
def read(n):return list(csv.DictReader((P/'results_revision'/n).open(encoding='utf-8')))
def table(name,caption,label,columns,header,body):
    lines=[r'\begin{table}[H]',r'\centering\scriptsize',r'\caption{'+caption+'}',r'\label{'+label+'}',r'\begin{tabular}{'+columns+'}',r'\toprule',header+r'\\\midrule']+body+[r'\bottomrule\end{tabular}',r'\end{table}']
    (P/'generated'/name).write_text('\n'.join(lines)+'\n',encoding='utf-8')
pair=read('component_paired.csv')
labels={'robust_given_IPW':'Robust given IPW','robust_given_zero':'Robust given zero','IPW_given_mean':'IPW given mean','IPW_given_robust':'IPW given robust','robust_IPW_interaction':'Interaction','MKL_given_robust_IPW':'MKL given robust IPW'}
body=[]
for ds in ['MHEALTH','UCI-HAR']:
    for rate in [.35,.65]:
        for key,label in labels.items():
            r=next(r for r in pair if r['dataset']==ds and float(r['missing_rate'])==rate and r['contrast']==key)
            body.append(f"{ds} & {rate*100:.0f}\\% & {label} & {float(r['mean']):+.4f} & [{float(r['ci_low']):+.4f}, {float(r['ci_high']):+.4f}]"+r'\\')
table('table_revision_factorial_paired.tex','Prespecified secondary component study with common $\\rho=0.05$ and a 350-round cap. Entries are paired differences in worst-site macro-F1 over 20 matched masks with unadjusted 95\\% $t$ intervals. Robust given IPW is robust minus mean risk under IPW, and analogously for the other simple effects. Interaction is (robust IPW minus mean IPW) minus (robust zero minus mean zero); MKL is full minus no-MKL under robust IPW. These settings are not selected by the nested primary validation.','tab:revision_factorial_paired','ll l rr',r'Dataset & Absence & Contrast & Difference & 95\% interval',body)
w=read('component_weight_summary.csv');body=[]
for ds in ['MHEALTH','UCI-HAR']:
    for method in ['Robust IPW','Robust IPW no-MKL']:
        rr=[r for r in w if r['dataset']==ds and float(r['missing_rate'])==.65 and r['method']==method];lookup={int(r['modality']):r for r in rr};cells=[]
        for m in range(4):
            r=lookup.get(m);cells.append(f"{float(r['weight_mean']):.3f} ({float(r['weight_sd']):.3f})" if r else '--')
        body.append(ds+' & '+('Full MKL' if method=='Robust IPW' else 'No-MKL')+' & '+' & '.join(cells)+r'\\')
table('table_revision_weight_stability.tex','Descriptive coefficient-norm shares at 65\\% absence in the secondary study: mean (SD) over 20 masks. Shares use smoothed modality Frobenius norms normalized to sum to one in both fits; no-MKL shares are post-fit summaries rather than optimized MKL weights. These are not causal importance measures.','tab:revision_weight_stability','llrrrr',r'Dataset & Penalty & Block 1 & Block 2 & Block 3 & Block 4',body)
raw=read('component_raw.csv');agg=defaultdict(list)
for r in raw:agg[(r['dataset'],float(r['missing_rate']))].append(r)
audit=[];body=[]
for (ds,rate),rr in sorted(agg.items()):
    gn=[float(r['grad_norm']) for r in rr];cert=[float(r['gap_certificate']) for r in rr];cap=sum(int(r['iterations'])==350 for r in rr)
    audit.append(dict(dataset=ds,missing_rate=rate,fits=len(rr),cap_count=cap,grad_min=min(gn),grad_median=st.median(gn),grad_max=max(gn),certificate_min=min(cert),certificate_median=st.median(cert),certificate_max=max(cert)))
    body.append(f"{ds} & {rate*100:.0f}\\% & {len(rr)} & {cap}/{len(rr)} & {st.median(gn):.3g} / {max(gn):.3g} & {st.median(cert):.3g} / {max(cert):.3g}"+r'\\')
table('table_revision_terminal_diagnostics.tex','Terminal diagnostics for all 620 prespecified secondary fits, including sensitivity variants. Gradient norm and empirical objective-gap certificate are shown as median / maximum. For this strongly convex objective, $J(\\theta)-J^*\\leq\\|\\nabla J(\\theta)\\|^2/(2\\mu)$ with $\\mu=\\lambda_0\\eta_b=0.0006$. The certificate concerns numerical optimization, not generalization; cap attainment is not itself convergence.','tab:revision_terminal','llrrrr',r'Dataset & Absence & Fits & At cap & Gradient norm & Gap certificate',body)
(P/'results_revision/component_terminal_audit.json').write_text(json.dumps(audit,indent=2)+'\n',encoding='utf-8')
print(json.dumps(audit,indent=2))
