"""Fold-fitted representation validation and fresh public benchmark evaluation.

The inner split and candidate grids are fixed before held-out test evaluation.
Raw archives must be downloaded from UCI; they are not redistributed here.
"""
from pathlib import Path
import argparse,csv,hashlib,io,json,math,platform,time,zipfile
from concurrent.futures import ThreadPoolExecutor
import numpy as np
from scipy.stats import t as student_t
from sklearn.decomposition import PCA
from sklearn.svm import LinearSVC
from threadpoolctl import threadpool_limits
import sklearn,scipy
from run_public_benchmarks import (fit_smooth,fit_fedavg,make_missingness,predict,metrics,obj_grad,write_csv)

SEEDS=[20261131,20261132,20261133]
PARS=dict(tau=4.,lam0=.012,lam1=.0035,eps=1e-4,max_iter=1400)
PREDICTIONS={}
TRSETS=[[1,3,5,6],[7,8,11,14],[15,16,17,19],[21,22,23,25],[26,27,28,29,30]]
TESETS=[[2,4],[9,10],[12,13],[18,20],[24]]

def raw_har(file):
    with zipfile.ZipFile(file) as z:
        inner=next((n for n in z.namelist() if n.endswith('.zip')),None)
        if inner:z=zipfile.ZipFile(io.BytesIO(z.read(inner)))
        def load(s,dtype=float):
            name=next(n for n in z.namelist() if n.endswith('/'+s));return np.loadtxt(io.BytesIO(z.read(name)),dtype=dtype)
        X=load('train/X_train.txt');T=load('test/X_test.txt')
        y=load('train/y_train.txt',int)-1;v=load('test/y_test.txt',int)-1
        sub=load('train/subject_train.txt',int);st=load('test/subject_test.txt',int)
        fn=next(n for n in z.namelist() if n.endswith('/features.txt'))
        names=[s.split(maxsplit=1)[1] for s in z.read(fn).decode().splitlines()]
    gyro=np.array(['Gyro' in s for s in names]);groups=[np.flatnonzero(~gyro),np.flatnonzero(gyro)]
    site=np.empty(len(y),int);tsite=np.empty(len(v),int)
    for s,(a,b) in enumerate(zip(TRSETS,TESETS)):site[np.isin(sub,a)]=s;tsite[np.isin(st,b)]=s
    # One prespecified training participant per artificial silo is held out internally.
    inner_val=np.isin(sub,[a[-1] for a in TRSETS])
    return X,T,y,v,site,tsite,groups,~inner_val,inner_val,sub

def raw_mhealth(file):
    feats=[];ys=[];subjects=[];starts=[]
    with zipfile.ZipFile(file) as z:
        for s in range(1,11):
            name=next(n for n in z.namelist() if n.endswith(f'mHealth_subject{s}.log'))
            a=np.loadtxt(io.BytesIO(z.read(name)));lab=a[:,23].astype(int);i=0
            while i<len(a):
                c=lab[i];j=i+1
                while j<len(a) and lab[j]==c:j+=1
                if c>0:
                    for st in range(i,j-99,100):
                        block=a[st:st+100,:23];parts=[]
                        for cg in [np.arange(3),np.arange(3,5),np.arange(5,14),np.arange(14,23)]:
                            q=block[:,cg];parts.append(np.concatenate([q.mean(0),q.std(0),q.min(0),q.max(0),np.sqrt((q*q).mean(0))]))
                        feats.append(np.concatenate(parts));ys.append(c-1);subjects.append(s-1);starts.append(st)
                i=j
    X=np.asarray(feats);y=np.asarray(ys);site=np.asarray(subjects);starts=np.asarray(starts)
    tr=np.zeros(len(y),bool)
    for s in range(10):
        for c in np.unique(y):
            ix=np.flatnonzero((site==s)&(y==c));ix=ix[np.argsort(starts[ix])];cut=max(1,int(.70*len(ix)))
            if len(ix)>1:cut=min(cut,len(ix)-1)
            tr[ix[:cut]]=True
    A=X[tr];yt=y[tr];ss=site[tr];tt=starts[tr];inner=np.zeros(len(A),bool)
    for s in range(10):
        for c in np.unique(y):
            ix=np.flatnonzero((ss==s)&(yt==c));ix=ix[np.argsort(tt[ix])];cut=max(1,min(len(ix)-1,int(.8*len(ix))));inner[ix[:cut]]=True
    groups=[np.arange(0,15),np.arange(15,25),np.arange(25,70),np.arange(70,115)]
    return A,X[~tr],yt,y[~tr],ss,site[~tr],groups,inner,~inner,tt

def transform(X,T,groups,ds):
    aa=[];bb=[];ng=[];o=0
    for k,g in enumerate(groups):
        A=X[:,g];B=T[:,g];mu=A.mean(0);sd=A.std(0);sd=np.where(sd<1e-8,1,sd)
        A=(A-mu)/sd;B=(B-mu)/sd;d=min(25 if ds=='UCI-HAR' else 15,len(g),len(A)-1)
        if ds=='UCI-HAR' or len(g)>d:
            pc=PCA(n_components=d,svd_solver='randomized',random_state=20260809 if ds=='UCI-HAR' else 20260809+k)
            A=pc.fit_transform(A);B=pc.transform(B)
        aa.append(A);bb.append(B);ng.append(np.arange(o,o+d));o+=d
    return np.concatenate(aa,1),np.concatenate(bb,1),ng

def save_cache(file,X,T,y,v,s,t,g,**extras):
    np.savez_compressed(file,Xtr=X,Xte=T,ytr=y,yte=v,site_tr=s,site_te=t,group_starts=np.array([x[0] for x in g]+[g[-1][-1]+1]),**extras)

def cache_data(z):
    a=np.load(z);b=a['group_starts'];return a['Xtr'],a['Xte'],a['ytr'],a['yte'],a['site_tr'],a['site_te'],[np.arange(b[i],b[i+1]) for i in range(len(b)-1)]

def prepare(args):
    for ds,key,loader,file in [('MHEALTH','mhealth',raw_mhealth,args.mhealth_zip),('UCI-HAR','har',raw_har,args.har_zip)]:
        target=args.outdir/f'primary_v20_{key}_processed.npz';inner=args.outdir/f'validation_inner_{key}.npz'
        if target.exists() and inner.exists():continue
        print('preparing',ds,flush=True)
        X,T,y,v,s,t,g,tr,va,identifier=loader(file)
        A,B,ng=transform(X,T,g,ds);save_cache(target,A,B,y,v,s,t,ng)
        A,B,ng=transform(X[tr],X[va],g,ds);save_cache(inner,A,B,y[tr],y[va],s[tr],s[va],ng,inner_train_indices=np.flatnonzero(tr),inner_validation_indices=np.flatnonzero(va),source_identifier=identifier)
        print('CACHES_READY',ds,str(target),flush=True)

def select(ds,data,out):
    X,T,y,v,s,t,g=data;C=int(y.max()+1);rows=[]
    masks=[make_missingness(X,T,s,t,g,.35,seed) for seed in SEEDS]
    def evaluate(method,param,rho=.05,c=1,lr=.025,mu=0,rounds=50):
        vals=[]
        for seed,miss in zip(SEEDS,masks):
            if method=='rho':th,info=fit_smooth(miss['ipw_tr'],y,s,g,C,robust=True,rho=rho,**PARS);pp=predict(th,miss['ipw_te'],C)
            elif method=='SVM':pp=LinearSVC(C=c,dual='auto',max_iter=6000).fit(miss['zero_tr'],y).predict(miss['zero_te'])
            else:th,info=fit_fedavg(miss['zero_tr'],y,s,C,prox=mu,rounds=rounds,local_steps=5,lr=lr,lam0=.012);pp=predict(th,miss['zero_te'],C)
            m=metrics(v,pp,t);rows.append(dict(dataset=ds,method=method,candidate=param,seed=seed,rho=rho,C_svm=c,lr=lr,mu=mu,rounds=rounds,**m));vals.append(m)
        return np.mean([q['worst_macro_f1'] for q in vals]),np.mean([q['mean_macro_f1'] for q in vals])
    rho=max(((*evaluate('rho',str(r),rho=r),-r,r) for r in [.03,.05,.08,.12,.20]))[-1]
    c=max(((*evaluate('SVM',str(c),c=c),-c,c) for c in [.1,1,10]))[-1]
    selected={'rho':rho,'svm_c':c}
    for method,mu in [('FedAvg',0.),('FedProx',.1)]:
        lr=max(((*evaluate(method,'lr='+str(lr),lr=lr,mu=mu),-lr,lr) for lr in [.01,.025,.05]))[-1]
        rounds=max(((*evaluate(method,'rounds='+str(r),lr=lr,mu=mu,rounds=r),-r,r) for r in [50,100,200,350]))[-1]
        selected[method]={'lr':lr,'rounds':rounds,'local_steps':5,'mu':mu}
    write_csv(out/f'validation_grid_{ds}.csv',rows)
    return selected

def primary(ds,data,pars,out):
    X,T,y,v,s,t,g=data;C=int(y.max()+1);rows=[];per=[]
    oracle,oi=fit_smooth(X,y,s,g,C,robust=False,rho=.05,**PARS)
    for seed in range(20260820,20260830):
        miss=make_missingness(X,T,s,t,g,.35,seed);cc=miss['mask_tr'][:,1:].min(1)>0
        specs=[('Zero-fill SMKL',miss['zero_tr'],miss['zero_te'],False,.0035),('IPW mean SMKL',miss['ipw_tr'],miss['ipw_te'],False,.0035),('2D-FedSMKL',miss['ipw_tr'],miss['ipw_te'],True,.0035),('2D-FedSMKL no MKL',miss['ipw_tr'],miss['ipw_te'],True,0.)]
        for label,A,B,robust,lam1 in specs:
            kw=dict(PARS);kw['lam1']=lam1;th,info=fit_smooth(A,y,s,g,C,robust=robust,rho=pars['rho'],**kw)
            pp=predict(th,B,C);grad=obj_grad(th,A,y,s,g,C,4,.012,lam1,1e-4,pars['rho'],robust)[1]
            info['gradient_norm']=float(np.linalg.norm(grad));record(ds,seed,label,v,pp,t,info,rows,per)
        kw=dict(PARS);kw['lam1']=0.;th,info=fit_smooth(X[cc],y[cc],s[cc],g,C,robust=False,rho=pars['rho'],**kw)
        record(ds,seed,'Complete-case CS',v,predict(th,miss['zero_te'],C),t,info,rows,per)
        for method in ['FedAvg','FedProx']:
            a=pars[method];th,info=fit_fedavg(miss['zero_tr'],y,s,C,prox=a['mu'],rounds=a['rounds'],local_steps=5,lr=a['lr'],lam0=.012)
            record(ds,seed,method+'-CS',v,predict(th,miss['zero_te'],C),t,info,rows,per)
        start=time.perf_counter();model=LinearSVC(C=pars['svm_c'],dual='auto',max_iter=6000).fit(miss['zero_tr'],y)
        record(ds,seed,'Pooled linear SVM',v,model.predict(miss['zero_te']),t,{'time_sec':time.perf_counter()-start,'iterations':int(model.n_iter_)},rows,per)
        record(ds,seed,'Oracle full SMKL',v,predict(oracle,T,C),t,oi,rows,per)
        write_csv(out/f'primary_v20_raw_{ds}.csv',rows);write_csv(out/f'primary_v20_per_site_{ds}.csv',per)
        keys=[k for k in list(PREDICTIONS) if k[0]==ds]
        np.savez_compressed(out/f'primary_v20_predictions_{ds}.npz',predictions=np.stack([PREDICTIONS[k] for k in keys]),seeds=np.array([k[1] for k in keys]),methods=np.array([k[2] for k in keys]),y_true=v,site=t)
        print('PRIMARY',ds,seed,flush=True)
    return rows

def record(ds,seed,label,y,pp,site,info,rows,per):
    PREDICTIONS[(ds,seed,label)]=np.asarray(pp,dtype=np.int16)
    row=dict(dataset=ds,seed=seed,replicate=seed-20260820,missing_rate=.35,method=label,**metrics(y,pp,site),**{k:info.get(k,float('nan')) for k in ['iterations','time_sec','objective','gradient_norm','line_search_trials']});rows.append(row)
    for s in np.unique(site):
        ix=site==s;mm=metrics(y[ix],pp[ix],np.zeros(ix.sum(),int));per.append(dict(dataset=ds,seed=seed,method=label,site=int(s),macro_f1=mm['mean_macro_f1'],balanced_accuracy=mm['mean_bal_acc'],n=int(ix.sum())))

def summarize(rows,out):
    summary=[];paired=[]
    for ds in ['MHEALTH','UCI-HAR']:
        methods=list(dict.fromkeys(r['method'] for r in rows if r['dataset']==ds))
        for m in methods:
            a=[r for r in rows if r['dataset']==ds and r['method']==m];q={'dataset':ds,'method':m,'n':len(a)}
            for k in ['mean_macro_f1','worst_macro_f1','mean_bal_acc','worst_bal_acc','iterations','time_sec','gradient_norm']:
                x=np.array([r[k] for r in a]);q[k+'_mean']=float(np.mean(x));q[k+'_sd']=float(np.std(x,ddof=1))
            summary.append(q)
        pr={r['seed']:r['worst_macro_f1'] for r in rows if r['dataset']==ds and r['method']=='2D-FedSMKL'}
        for m in methods:
            if m in ['2D-FedSMKL','Oracle full SMKL']:continue
            a={r['seed']:r['worst_macro_f1'] for r in rows if r['dataset']==ds and r['method']==m};d=np.array([pr[s]-a[s] for s in pr]);h=student_t.ppf(.975,len(d)-1)*d.std(ddof=1)/np.sqrt(len(d))
            paired.append(dict(dataset=ds,comparator=m,n=len(d),mean=float(d.mean()),lower=float(d.mean()-h),upper=float(d.mean()+h)))
    write_csv(out/'primary_v20_summary.csv',summary);write_csv(out/'primary_v20_paired.csv',paired)
    generated=Path(__file__).resolve().parents[1]/'generated'
    order=['Pooled linear SVM','Complete-case CS','FedAvg-CS','FedProx-CS','Zero-fill SMKL','IPW mean SMKL','2D-FedSMKL','Oracle full SMKL']
    lines=[r'\begin{table*}[t]',r'\centering',r'\caption{Public-data results with fold-fitted preprocessing for source validation and final source-only representations, under 35\% controlled MAR block absence. Entries are mean (sample SD) over ten matched masks. Zero-fill SMKL, and the zero-filled inference of complete-case CS, place an absent block at its observed training mean, which is mean imputation on standardized blocks. The oracle uses unmasked data and is fitted once, so its SD is zero across masks.}\label{tab:public_main}',r'\scriptsize',r'\setlength{\tabcolsep}{4pt}',r'\begin{tabular}{lcccc}',r'\toprule',r'Method & Mean macro-F1 & Worst-site macro-F1 & Mean BA & Worst-site BA \\',r'\midrule']
    for ds in ['MHEALTH','UCI-HAR']:
        lines.append(r'\multicolumn{5}{l}{\textbf{'+ds+r'}} \\')
        for method in order:
            q=next(x for x in summary if x['dataset']==ds and x['method']==method)
            cells=[f"{q[k+'_mean']:.3f} ({q[k+'_sd']:.3f})" for k in ['mean_macro_f1','worst_macro_f1','mean_bal_acc','worst_bal_acc']]
            label=r'\textbf{2D-FedSMKL}' if method=='2D-FedSMKL' else method
            lines.append(label+' & '+' & '.join(cells)+r' \\')
        lines.append(r'\midrule' if ds=='MHEALTH' else r'\bottomrule')
    lines += [r'\end{tabular}',r'\end{table*}']
    (generated/'table_revision_primary.tex').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    lines=[r'\begin{table}[H]',r'\centering',r'\caption{Paired differences in worst-site macro-F1 after fold-fitted source validation: 2D-FedSMKL minus comparator. Intervals are 95\% paired $t$ intervals over ten matched masks, conditional on the fixed benchmark samples.}\label{tab:public_paired}',r'\scriptsize',r'\begin{tabular}{llrr}',r'\toprule',r'Dataset & Comparator & Difference & 95\% interval \\',r'\midrule']
    for q in paired:
        lines.append(f"{q['dataset']} & {q['comparator']} & {q['mean']:+.3f} & [{q['lower']:+.3f}, {q['upper']:+.3f}]"+r' \\')
    lines += [r'\bottomrule',r'\end{tabular}',r'\end{table}']
    (generated/'table_revision_paired.tex').write_text('\n'.join(lines)+'\n',encoding='utf-8')

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--mhealth-zip',type=Path,required=True);ap.add_argument('--har-zip',type=Path,required=True);ap.add_argument('--outdir',type=Path,default=Path('results_revision'));ap.add_argument('--prepare-only',action='store_true');ap.add_argument('--cap-only',action='store_true');ap.add_argument('--audit-only',action='store_true');args=ap.parse_args();args.outdir.mkdir(exist_ok=True,parents=True)
    with threadpool_limits(1):
        if args.audit_only:
            audit_predictions(args.outdir);return
        if args.cap_only:
            cap_diagnostic(args.outdir);return
        prepare(args)
        if args.prepare_only:return
        allrows=[];settings={}
        with ThreadPoolExecutor(max_workers=2) as pool:
            futures=[pool.submit(final_study,ds,key,args.outdir) for ds,key in [('MHEALTH','mhealth'),('UCI-HAR','har')]]
            for future in futures:
                ds,pars,rows=future.result();settings[ds]=pars;allrows+=rows
        summarize(allrows,args.outdir)
        meta={'date':'2026-11-01','python':platform.python_version(),'numpy':np.__version__,'scipy':scipy.__version__,'sklearn':sklearn.__version__,'validation_seeds':SEEDS,'fixed_parameters':PARS,'selection':'maximize mean validation worst-site macro-F1 across three masks; tie mean-site F1, then smaller numeric candidate','inner_protocol':{'MHEALTH':'within each source participant/activity, earliest 80 percent of source-training windows for inner training, remainder validation','UCI-HAR':'prespecified source subjects 6,14,19,25,30 held out, one per silo; others inner training','preprocessing':'scaling and PCA fit exclusively on inner training, then transform validation'},'representation_change':'HAR now uses raw-block standardization then 25-component PCA per block, with no second PCA-coordinate standardization/whitening. v19 used an additional coordinate standardization. All v20 main and supplemental new experiments share the new caches; do not mix with v19 tables. MHEALTH retains the same preprocessing procedure.','selected':settings,'raw_sha256':{str(x.name):hashlib.sha256(x.read_bytes()).hexdigest() for x in [args.mhealth_zip,args.har_zip]},'scope':'Representations are complete-source training maps before imposed MAR. Inner preprocessing is fit only to the inner training subset. Test labels never enter hyperparameter selection. New runtime differs from historical Linux runs.'}
        meta['platform']=platform.platform();meta['processor']=platform.processor();meta['blas_threads']=1
        meta['optimization_revision']='The initial uniform 350-round pilot was retained under review/v20/pilot350. Training-objective and gradient diagnostics prompted a uniform 1400-round cap for every smooth primary model and for the five-rho inner validation grid. Test F1 was not used to choose the cap. SVM and FedAvg/Prox selections remained frozen.'
        (args.outdir/'validation_metadata.json').write_text(json.dumps(meta,indent=2))
def final_study(ds,key,out):
    selected_file=out/f'validation_selected_{key}.json'
    if selected_file.exists():pars=json.loads(selected_file.read_text())
    else:pars=select(ds,cache_data(out/f'validation_inner_{key}.npz'),out)
    if pars.get('primary_smooth_max_iter')!=1400:
        X,T,y,v,s,t,g=cache_data(out/f'validation_inner_{key}.npz');C=int(y.max()+1);masks=[make_missingness(X,T,s,t,g,.35,seed) for seed in SEEDS];rows=[];candidates=[]
        for rho in [.03,.05,.08,.12,.20]:
            vals=[]
            for seed,miss in zip(SEEDS,masks):
                th,info=fit_smooth(miss['ipw_tr'],y,s,g,C,robust=True,rho=rho,**PARS);m=metrics(v,predict(th,miss['ipw_te'],C),t);vals.append(m);rows.append(dict(dataset=ds,rho=rho,seed=seed,max_iter=1400,iterations=info['iterations'],objective=info['objective'],**m))
            candidates.append((np.mean([q['worst_macro_f1'] for q in vals]),np.mean([q['mean_macro_f1'] for q in vals]),-rho,rho))
        pars['rho']=max(candidates)[-1];pars['primary_smooth_max_iter']=1400;selected_file.write_text(json.dumps(pars,indent=2));write_csv(out/f'validation_grid_rho1400_{key}.csv',rows)
    print('SELECTED_FINAL',ds,pars,flush=True)
    return ds,pars,primary(ds,cache_data(out/f'primary_v20_{key}_processed.npz'),pars,out)

def cap_diagnostic(out):
    rows=[];rhos={}
    for ds,k in [('MHEALTH','mhealth'),('UCI-HAR','har')]:
        X,T,y,v,s,t,g=cache_data(out/f'primary_v20_{k}_processed.npz')
        pilot=out.parent/'review/v20/pilot350'/f'validation_selected_{k}.json'
        # Preserve the diagnostic's pilot temperatures even in a clean output directory.
        rho=json.loads(pilot.read_text())['rho'] if pilot.exists() else {'MHEALTH':.12,'UCI-HAR':.05}[ds]
        rhos[ds]=rho;C=int(y.max()+1)
        for seed in [20260820,20260821,20260822]:
            miss=make_missingness(X,T,s,t,g,.35,seed)
            for label,kind,robust in [('2D-FedSMKL','ipw',True),('IPW mean SMKL','ipw',False),('Zero-fill SMKL','zero',False)]:
                for cap in [350,1400]:
                    kw=dict(PARS);kw['max_iter']=cap;A=miss[kind+'_tr'];B=miss[kind+'_te'];th,info=fit_smooth(A,y,s,g,C,robust=robust,rho=rho,**kw)
                    grad=obj_grad(th,A,y,s,g,C,4,.012,.0035,1e-4,rho,robust)[1]
                    rows.append(dict(dataset=ds,seed=seed,method=label,rho=rho,cap=cap,iterations=info['iterations'],objective=info['objective'],gradient_norm=float(np.linalg.norm(grad)),**metrics(v,predict(th,B,C),t)))
                    write_csv(out/'cap_v20.csv',rows)
            print('CAP',ds,seed,flush=True)
    (out/'cap_v20_protocol.json').write_text(json.dumps({'seeds':[20260820,20260821,20260822],'choice':'Three fixed seeds selected by runtime-only rule before inspecting diagnostic test metrics. Pilot 1400-fit seconds MH3.82/HAR7.76 estimated >2 minutes for all10 seeds.','budgets':[350,1400],'rho_by_dataset':rhos,'scope':'numerical sensitivity, not test-driven model selection'},indent=2))

def audit_predictions(out):
    count=0;maxerr=0.
    for ds in ['MHEALTH','UCI-HAR']:
        z=np.load(out/f'primary_v20_predictions_{ds}.npz');assert len(z['seeds'])==90
        raw=list(csv.DictReader((out/f'primary_v20_raw_{ds}.csv').open(encoding='utf-8')));assert len(raw)==90
        y=z['y_true'];site=z['site']
        for pred,seed,method in zip(z['predictions'],z['seeds'],z['methods']):
            C=int(max(y.max(),pred.max())+1);f=[];b=[]
            for s in np.unique(site):
                ix=site==s;cm=np.bincount(C*y[ix]+pred[ix],minlength=C*C).reshape(C,C);tp=np.diag(cm);true=cm.sum(1);guess=cm.sum(0);den=true+guess
                f.append(np.mean(2*tp[den>0]/den[den>0]));b.append(np.mean(tp[true>0]/true[true>0]))
            values=dict(mean_macro_f1=np.mean(f),worst_macro_f1=np.min(f),mean_bal_acc=np.mean(b),worst_bal_acc=np.min(b),pooled_accuracy=np.mean(y==pred))
            row=next(r for r in raw if int(r['seed'])==seed and r['method']==method)
            for k,v in values.items():
                error=abs(v-float(row[k]));maxerr=max(maxerr,error);assert error<1e-12,(ds,seed,method,k,error);count+=1
    (out/'validation_metric_check.json').write_text(json.dumps({'comparisons':count,'maximum_absolute_error':maxerr,'method':'independent NumPy confusion-matrix reconstruction from saved per-sample predictions, without calling training metrics() or sklearn metrics','failures':0},indent=2))
    cap=list(csv.DictReader((out/'cap_v20.csv').open()));summary=[]
    lines=[r'\begin{table}[H]',r'\centering',r'\caption{Numerical budget sensitivity on three prespecified matched masks. Changes are 1400-budget minus 350-budget values; gradients are terminal Euclidean norms. Diagnostic test metrics were not used to select the primary budget. This pilot diagnostic uses $\rho=0.12$ for MHEALTH and $0.05$ for HAR; the final primary HAR $\rho$ was subsequently reselected as $0.20$. 2D-Fed denotes 2D-FedSMKL.}\label{tab:revision_cap}',r'\scriptsize',r'\begin{tabular}{llrrrrr}',r'\toprule',r'Dataset & Method & $\Delta J$ & $\|g_{350}\|$ & $\|g_{1400}\|$ & $\Delta$ F1 & Max $|\Delta$ F1$|$ \\',r'\midrule']
    for ds in ['MHEALTH','UCI-HAR']:
        for method,label in [('2D-FedSMKL','2D-Fed'),('IPW mean SMKL','IPW mean'),('Zero-fill SMKL','Zero-fill')]:
            a=sorted([r for r in cap if r['dataset']==ds and r['method']==method and r['cap']=='350'],key=lambda r:r['seed']);b=sorted([r for r in cap if r['dataset']==ds and r['method']==method and r['cap']=='1400'],key=lambda r:r['seed'])
            d=np.array([float(v['worst_macro_f1'])-float(u['worst_macro_f1']) for u,v in zip(a,b)]);j=np.mean([float(v['objective'])-float(u['objective']) for u,v in zip(a,b)]);g0=np.mean([float(r['gradient_norm']) for r in a]);g1=np.mean([float(r['gradient_norm']) for r in b]);summary.append(dict(dataset=ds,method=method,mean_objective_change=j,mean_gradient_350=g0,mean_gradient_1400=g1,mean_worst_f1_change=float(d.mean()),max_abs_worst_f1_change=float(abs(d).max())))
            lines.append(f'{ds} & {label} & {j:.2e} & {g0:.2e} & {g1:.2e} & {d.mean():+.4f} & {abs(d).max():.4f}'+r' \\')
    lines += [r'\bottomrule',r'\end{tabular}',r'\end{table}'];write_csv(out/'cap_v20_summary.csv',summary)
    (Path(__file__).resolve().parents[1]/'generated/table_revision_cap.tex').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    print('PREDICTION_AUDIT',count,maxerr)
if __name__=='__main__':main()
