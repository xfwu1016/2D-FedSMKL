"""Prospectively fixed, mask-conditional component and propensity experiments.

Uses the archived learned feature maps, not a nested raw-data pipeline. No
selection uses public-test outcomes. Historical results are never overwritten.
"""
from pathlib import Path
import argparse,csv,json,time,sys,platform,traceback,hashlib
from collections import defaultdict
import numpy as np
import scipy,sklearn
from scipy.stats import t as student_t
from threadpoolctl import threadpool_limits,threadpool_info
from sklearn.metrics import f1_score,balanced_accuracy_score
from run_public_benchmarks import (load_processed,make_missingness,fit_smooth,
    obj_grad,predict,metrics,expit,fit_logistic_irls,calibrate_intercept)

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'results_revision'
PARS=dict(tau=4.,lam0=.012,lam1=.0035,eps=1e-4,rho=.05,max_iter=350)
SEEDS=list(range(20261101,20261121))

def save(name,rows):
    if not rows:return
    keys=list(dict.fromkeys(k for r in rows for k in r))
    with (OUT/name).open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows(rows)

def read(name):
    p=OUT/name
    return list(csv.DictReader(p.open(encoding='utf-8'))) if p.exists() else []

def propensity(Xtr,Xte,st,sv,groups,miss,rate,clip=.1,siteonly=False):
    k=min(3,len(groups[0]));Z=Xtr[:,groups[0][:k]];V=Xte[:,groups[0][:k]]
    mu=Z.mean(0);sd=Z.std(0);sd=np.where(sd<1e-8,1,sd);Z=(Z-mu)/sd;V=(V-mu)/sd
    S=int(max(st.max(),sv.max())+1)
    T=np.c_[np.ones(len(Z)),np.eye(S)[st][:,1:]]
    U=np.c_[np.ones(len(V)),np.eye(S)[sv][:,1:]]
    if not siteonly:T=np.c_[np.ones(len(Z)),Z,np.eye(S)[st][:,1:]];U=np.c_[np.ones(len(V)),V,np.eye(S)[sv][:,1:]]
    a=Xtr.copy();b=Xte.copy();diags=[]
    for m,g in enumerate(groups):
        if m==0:continue
        beta=fit_logistic_irls(T,miss['mask_tr'][:,m])
        rawtr=expit(T@beta);rawte=expit(U@beta)
        ptr=np.clip(rawtr,clip,.98);pte=np.clip(rawte,clip,.98)
        a[:,g]*=(miss['mask_tr'][:,m]/ptr)[:,None]
        b[:,g]*=(miss['mask_te'][:,m]/pte)[:,None]
        # Known generating probability, distinct from the estimated clipping floor.
        coef=np.array([.35,-.25,.15])[:k];offsets=np.linspace(-.35,.35,S)*(1+.15*m)
        intercept=calibrate_intercept(Z,st,1-rate,coef,offsets)
        true_tr=expit(intercept+Z@coef+offsets[st]);true_te=expit(intercept+V@coef+offsets[sv])
        for split,raw,p,r,truth in [('train',rawtr,ptr,miss['mask_tr'][:,m],true_tr),('test',rawte,pte,miss['mask_te'][:,m],true_te)]:
            weights=r/p;obs=int(r.sum());ess=float(weights.sum()**2/(weights@weights)) if obs else 0.
            diags.append(dict(split=split,modality=m,clip_floor=clip,model='site-only' if siteonly else 'baseline+site',
                true_p_min=float(truth.min()),true_p_p01=float(np.quantile(truth,.01)),estimated_p_min=float(p.min()),
                estimated_p_p01=float(np.quantile(p,.01)),estimated_p_median=float(np.median(p)),
                lower_clip_fraction=float(np.mean(raw<clip)),upper_clip_fraction=float(np.mean(raw>.98)),
                observed_n=obs,ess=ess,ess_over_observed=ess/obs if obs else 0.,
                propensity_rmse=float(np.sqrt(np.mean((p-truth)**2)))))
    return a,b,diags

def summary(raw):
    agg=defaultdict(list)
    for r in raw:agg[(r['dataset'],float(r['missing_rate']),r['method'])].append(r)
    rows=[]
    for (ds,rate,method),rr in sorted(agg.items()):
        s=dict(dataset=ds,missing_rate=rate,method=method,n=len(rr))
        for k in ['worst_macro_f1','mean_macro_f1','worst_bal_acc','objective','grad_norm','gap_certificate','iterations','time_sec']:
            v=np.array([float(r[k]) for r in rr]);s[k+'_mean']=float(v.mean());s[k+'_sd']=float(v.std(ddof=1)) if len(v)>1 else 0.
        rows.append(s)
    save('component_summary.csv',rows)
    index={(r['dataset'],float(r['missing_rate']),int(r['seed']),r['method']):r for r in raw}
    contrasts=[('Robust IPW','Mean IPW','robust_given_IPW'),('Robust zero','Mean zero','robust_given_zero'),
        ('Mean IPW','Mean zero','IPW_given_mean'),('Robust IPW','Robust zero','IPW_given_robust'),
        ('Robust IPW','Robust IPW no-MKL','MKL_given_robust_IPW'),
        ('Robust IPW clip05','Robust IPW','clip05_minus_baseline'),('Robust IPW clip20','Robust IPW','clip20_minus_baseline'),
        ('Robust IPW site-only','Robust IPW','siteonly_minus_baseline')]
    pairs=[]
    for ds in ['MHEALTH','UCI-HAR']:
        for rate in [.1,.35,.65]:
            for one,two,label in contrasts:
                vals=[]
                for seed in SEEDS:
                    ka=(ds,rate,seed,one);kb=(ds,rate,seed,two)
                    if ka in index and kb in index:vals.append(float(index[ka]['worst_macro_f1'])-float(index[kb]['worst_macro_f1']))
                if len(vals)>1:
                    v=np.array(vals);half=float(student_t.ppf(.975,len(v)-1)*v.std(ddof=1)/np.sqrt(len(v)))
                    pairs.append(dict(dataset=ds,missing_rate=rate,contrast=label,n=len(v),mean=float(v.mean()),ci_low=float(v.mean()-half),ci_high=float(v.mean()+half)))
            vals=[]
            for seed in SEEDS:
                keys=[(ds,rate,seed,m) for m in ['Robust IPW','Mean IPW','Robust zero','Mean zero']]
                if all(k in index for k in keys):
                    z=[float(index[k]['worst_macro_f1']) for k in keys];vals.append(z[0]-z[1]-z[2]+z[3])
            if len(vals)>1:
                v=np.array(vals);half=float(student_t.ppf(.975,len(v)-1)*v.std(ddof=1)/np.sqrt(len(v)))
                pairs.append(dict(dataset=ds,missing_rate=rate,contrast='robust_IPW_interaction',n=len(v),mean=float(v.mean()),ci_low=float(v.mean()-half),ci_high=float(v.mean()+half)))
    save('component_paired.csv',pairs)
    # Compact table: same rows, four dataset-by-missingness columns.
    lookup={(r['dataset'],r['missing_rate'],r['method']):r for r in rows}
    lines=[r'\begin{table}[H]',r'\centering\small',r'\caption{Fixed-representation component comparison. Entries are mean (SD) worst-site macro-F1 over 20 matched masks; settings are frozen before evaluation.}',r'\label{tab:revision_components}',r'\begin{tabular}{lcccc}',r'\toprule',r' & \multicolumn{2}{c}{MHEALTH} & \multicolumn{2}{c}{UCI HAR}\\',r'Method & 35\% & 65\% & 35\% & 65\%\\\midrule']
    for method in ['Mean zero','Robust zero','Mean IPW','Robust IPW','Robust IPW no-MKL']:
        cells=[]
        for ds,rate in [('MHEALTH',.35),('MHEALTH',.65),('UCI-HAR',.35),('UCI-HAR',.65)]:
            x=lookup.get((ds,rate,method));cells.append(f"{x['worst_macro_f1_mean']:.3f} ({x['worst_macro_f1_sd']:.3f})" if x else '--')
        lines.append(method+' & '+' & '.join(cells)+r'\\')
    lines.extend([r'\bottomrule\end{tabular}',r'\end{table}'])
    (ROOT/'generated/table_revision_components.tex').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    return rows,pairs

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--benchmark',action='store_true');ap.add_argument('--legacy-cache',action='store_true',help='Only for timing against historical caches; not the formal revision run.');args=ap.parse_args()
    OUT.mkdir(exist_ok=True)
    if args.legacy_cache and not args.benchmark:raise ValueError('--legacy-cache is restricted to timing benchmarks')
    inputs=[('MHEALTH',ROOT/'results_public/mhealth_processed.npz'),('UCI-HAR',ROOT/'results_public/har_processed.npz')] if args.legacy_cache else [('MHEALTH',OUT/'primary_v20_mhealth_processed.npz'),('UCI-HAR',OUT/'primary_v20_har_processed.npz')]
    input_hashes={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for _,p in inputs}
    raw=read('component_raw.csv');sites=read('component_sites.csv');weights=read('component_weights.csv');diags=read('component_propensity_diagnostics.csv')
    previous=OUT/'component_run_config.json'
    if raw and previous.exists():
        assert json.loads(previous.read_text())['input_sha256']==input_hashes,'Refusing to mix different representations in resumed output'
    done={(r['dataset'],float(r['missing_rate']),int(r['seed']),r['method']) for r in raw}
    config=dict(started_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),fixed_representation=True,
        seeds=SEEDS,rates=[.1,.35,.65],parameters=PARS,mask_replicates=20,sensitivity_seeds=SEEDS[:10],
        sensitivity_rate=.65,threads=1,python=sys.version,numpy=np.__version__,scipy=scipy.__version__,sklearn=sklearn.__version__,
        platform=platform.platform(),input_sha256=input_hashes,legacy_timing_only=args.legacy_cache,note='Mask-conditional paired t intervals; no multiple-comparison correction, population/subject/site replication, or nested raw-data validation is claimed.')
    (OUT/'component_run_config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8')
    with threadpool_limits(limits=1):
        config['threadpools']=threadpool_info()
        for ds,cache in inputs:
            X,V,y,z,st,sv,groups=load_processed(cache);C=int(y.max()+1)
            for rate in [.1,.35,.65]:
                for seed in SEEDS:
                    miss=make_missingness(X,V,st,sv,groups,rate,seed)
                    specs=[('Mean zero',False,False,.0035),('Robust zero',True,False,.0035),('Mean IPW',False,True,.0035),('Robust IPW',True,True,.0035)]
                    if rate in [.35,.65]:specs.append(('Robust IPW no-MKL',True,True,0.))
                    if rate==.65 and seed in SEEDS[:10]:specs.extend([('Robust IPW clip05',True,True,.0035),('Robust IPW clip20',True,True,.0035),('Robust IPW site-only',True,True,.0035)])
                    if args.benchmark:specs=[('Robust IPW',True,True,.0035)]
                    for label,robust,ipw,lam1 in specs:
                        key=(ds,rate,seed,label)
                        if key in done:continue
                        clip=.05 if label.endswith('clip05') else .20 if label.endswith('clip20') else .10
                        if ipw:
                            A,B,dd=propensity(X,V,st,sv,groups,miss,rate,clip,label.endswith('site-only'))
                            if clip==.10 and not label.endswith('site-only'):
                                assert np.max(np.abs(A-miss['ipw_tr']))<1e-10
                        else:A,B,dd=miss['zero_tr'],miss['zero_te'],[]
                        pars=dict(PARS);pars['lam1']=lam1
                        start=time.perf_counter();th,info=fit_smooth(A,y,st,groups,C,robust=robust,**pars)
                        elapsed=time.perf_counter()-start;pred=predict(th,B,C)
                        obj,grad,_,_=obj_grad(th,A,y,st,groups,C,4,.012,lam1,1e-4,.05,robust)
                        gn=float(np.linalg.norm(grad));m=metrics(z,pred,sv)
                        row=dict(dataset=ds,missing_rate=rate,seed=seed,method=label,**m,objective=float(obj),grad_norm=gn,
                            gap_certificate=gn*gn/(2*.012*.05),iterations=info['iterations'],time_sec=elapsed,line_search_trials=info['line_search_trials'])
                        if args.benchmark:print(json.dumps(row),flush=True);return
                        raw.append(row);done.add(key)
                        for s in np.unique(sv):
                            ix=sv==s;sites.append(dict(dataset=ds,missing_rate=rate,seed=seed,method=label,site=int(s),n=int(ix.sum()),macro_f1=float(f1_score(z[ix],pred[ix],average='macro',zero_division=0)),balanced_accuracy=float(balanced_accuracy_score(z[ix],pred[ix]))))
                        W=th[:A.shape[1]*C].reshape(A.shape[1],C);norms=np.array([np.sqrt(np.sum(W[g]**2)+1e-8) for g in groups]);beta=norms/norms.sum()
                        for k,beta_m in enumerate(beta):weights.append(dict(dataset=ds,missing_rate=rate,seed=seed,method=label,modality=k,weight=float(beta_m)))
                        for d in dd:diags.append(dict(dataset=ds,missing_rate=rate,seed=seed,method=label,**d))
                    save('component_raw.csv',raw);save('component_sites.csv',sites);save('component_weights.csv',weights);save('component_propensity_diagnostics.csv',diags)
                    print(f'{ds} rate={rate} seed={seed} completed fits={len(raw)}',flush=True)
        ss,pp=summary(raw)
        wgroups=defaultdict(list)
        for r in weights:wgroups[(r['dataset'],float(r['missing_rate']),r['method'],int(r['modality']))].append(float(r['weight']))
        wsummary=[]
        for (ds,rate,method,mod),vals in sorted(wgroups.items()):
            v=np.array(vals);wsummary.append(dict(dataset=ds,missing_rate=rate,method=method,modality=mod,n=len(v),weight_mean=float(v.mean()),weight_sd=float(v.std(ddof=1)),weight_p05=float(np.quantile(v,.05)),weight_p95=float(np.quantile(v,.95))))
        save('component_weight_summary.csv',wsummary)
        dgroups=defaultdict(list)
        for r in diags:dgroups[(r['dataset'],float(r['missing_rate']),r['method'],r['split'],int(r['modality']))].append(r)
        dsumm=[]
        for (ds,rate,method,split,mod),rr in sorted(dgroups.items()):
            row=dict(dataset=ds,missing_rate=rate,method=method,split=split,modality=mod,n=len(rr))
            for k in ['true_p_min','true_p_p01','estimated_p_min','estimated_p_p01','estimated_p_median','lower_clip_fraction','upper_clip_fraction','ess_over_observed','propensity_rmse']:
                v=np.array([float(r[k]) for r in rr]);row[k+'_mean']=float(v.mean());row[k+'_sd']=float(v.std(ddof=1))
            dsumm.append(row)
        save('component_propensity_summary.csv',dsumm)
        comparisons=[]
        for ds in ['MHEALTH','UCI-HAR']:
            baseline={int(r['seed']):float(r['worst_macro_f1']) for r in raw if r['dataset']==ds and float(r['missing_rate'])==.65 and r['method']=='Robust IPW' and int(r['seed']) in SEEDS[:10]}
            for method in ['Robust IPW','Robust IPW clip05','Robust IPW clip20','Robust IPW site-only']:
                rr=[r for r in raw if r['dataset']==ds and float(r['missing_rate'])==.65 and r['method']==method and int(r['seed']) in SEEDS[:10]]
                v=np.array([float(r['worst_macro_f1']) for r in rr]);diff=np.array([float(r['worst_macro_f1'])-baseline[int(r['seed'])] for r in rr])
                h=float(student_t.ppf(.975,len(v)-1)*diff.std(ddof=1)/np.sqrt(len(v)))
                dd=[r for r in diags if r['dataset']==ds and float(r['missing_rate'])==.65 and r['method']==method and r['split']=='train' and int(r['seed']) in SEEDS[:10]]
                comparisons.append(dict(dataset=ds,method=method,n=len(v),worst_f1_mean=float(v.mean()),worst_f1_sd=float(v.std(ddof=1)),difference_mean=float(diff.mean()),difference_ci_low=float(diff.mean()-h),difference_ci_high=float(diff.mean()+h),lower_clip_fraction=float(np.mean([float(r['lower_clip_fraction']) for r in dd])),ess_over_observed=float(np.mean([float(r['ess_over_observed']) for r in dd])),propensity_rmse=float(np.mean([float(r['propensity_rmse']) for r in dd]))))
        save('component_propensity_comparison.csv',comparisons)
        lines=[r'\begin{table}[H]',r'\centering\scriptsize',r'\caption{Propensity sensitivity at 65\% absence using 10 matched masks. ESS ratio is the average modality-specific effective sample size divided by observed training records. Differences compare each setting with baseline-plus-site propensity and clipping floor 0.10.}',r'\label{tab:revision_propensity}',r'\begin{tabular}{llrrrr}',r'\toprule',r'Dataset & Setting & Worst F1 & Difference & Lower clipped & ESS ratio\\\midrule']
        labels={'Robust IPW':'Full, 0.10','Robust IPW clip05':'Full, 0.05','Robust IPW clip20':'Full, 0.20','Robust IPW site-only':'Site-only, 0.10'}
        for r in comparisons:lines.append(f"{r['dataset']} & {labels[r['method']]} & {r['worst_f1_mean']:.3f} & {r['difference_mean']:+.3f} & {100*r['lower_clip_fraction']:.1f}\\% & {r['ess_over_observed']:.3f}"+r'\\')
        lines.extend([r'\bottomrule\end{tabular}',r'\end{table}'])
        (ROOT/'generated/table_revision_propensity.tex').write_text('\n'.join(lines)+'\n',encoding='utf-8')
        config['completed_utc']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime());config['fits']=len(raw)
        (OUT/'component_run_config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8')
        print('Completed',len(raw),'fits;',len(ss),'summary groups;',len(pp),'paired contrasts',flush=True)

if __name__=='__main__':
    try:main()
    except Exception:
        OUT.mkdir(exist_ok=True);(OUT/'component_failure.txt').write_text(traceback.format_exc(),encoding='utf-8');raise
