#!/usr/bin/env python3
"""Iteration-cap sensitivity for one deterministic public-data mask."""
from pathlib import Path
import argparse, csv, sys
import numpy as np
sys.path.insert(0, str(Path(__file__).resolve().parent))
from run_public_benchmarks import make_missingness, fit_smooth, predict, metrics


def load_cache(path):
    z=np.load(path); gs=z['group_starts']; groups=[np.arange(int(gs[i]),int(gs[i+1])) for i in range(len(gs)-1)]
    return z['Xtr'],z['Xte'],z['ytr'],z['yte'],z['site_tr'],z['site_te'],groups


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--outdir',type=Path,default=Path('results_public')); args=ap.parse_args()
    rows=[]; seed=20260820
    for ds,cache in [('MHEALTH','mhealth_processed.npz'),('UCI-HAR','har_processed.npz')]:
        Xtr,Xte,ytr,yte,strn,stst,groups=load_cache(args.outdir/cache); C=int(max(ytr.max(),yte.max())+1)
        miss=make_missingness(Xtr,Xte,strn,stst,groups,.35,seed)
        for cap in [350,700,1400]:
            th,info=fit_smooth(miss['ipw_tr'],ytr,strn,groups,C,robust=True,rho=.05,tau=4,lam0=.012,lam1=.0035,eps=1e-4,max_iter=cap)
            m=metrics(yte,predict(th,miss['ipw_te'],C),stst)
            rows.append(dict(dataset=ds,seed=seed,cap=cap,iterations=info['iterations'],objective=info['objective'],worst_macro_f1=m['worst_macro_f1'],mean_macro_f1=m['mean_macro_f1']))
    out=args.outdir/'convergence_cap_audit.csv'
    with open(out,'w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=rows[0].keys()); w.writeheader(); w.writerows(rows)
    print(out)

if __name__=='__main__': main()
