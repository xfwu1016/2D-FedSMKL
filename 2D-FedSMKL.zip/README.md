# 2D-FedSMKL — reproduction package

Code and derived records for the paper:

> **Hybrid Federated Learning for Multimodal Fusion under Missing Modalities and Site Heterogeneity**
> Xiaofei Wu, Rongmei Liang, Jian Qing Shi

The repository contains the training and evaluation code, the derived feature caches used in the paper, the archived simulation records, and the scripts that regenerate the reported tables and figures. Raw UCI archives are not redistributed; download instructions are in `PUBLIC_DATASETS.md`.

## Contents

| Path | What it contains |
|---|---|
| `code/` | Training, validation, component, message-audit and plotting scripts |
| `code/revision_extra/` | Additional component experiments (NumPy-only; bundled scikit-learn shim) |
| `results/` | Archived simulation records and run metadata |
| `results_revision/` | Derived caches, primary predictions, diagnostics and component outputs used in the paper |
| `generated/` | LaTeX tables and vector figures regenerated from these outputs |
| `PUBLIC_DATASETS.md` | Dataset provenance, splits and preprocessing |
| `REPRODUCIBILITY.md` | Detailed commands, environment and interpretation limits |

## Quick start

Python 3.12 is the recorded runtime. From the repository root:

```bash
python -m venv .venv
# Linux/macOS
source .venv/bin/activate
# Windows
# .venv\Scripts\activate
pip install -r requirements.txt
```

The fastest end-to-end check is the NumPy-only validation cell:

```bash
python code/revision_extra/validate_repro.py
```

It refits one primary MHEALTH cell and should print the published worst-site macro-F1 values:

- Zero-fill SMKL: `0.8444261834581864`
- IPW mean SMKL: `0.8040079681527050`
- 2D-FedSMKL: `0.8624424250425395`

## Data

The raw MHEALTH and UCI HAR archives are not included. Download them from the UCI Machine Learning Repository using the DOIs in `PUBLIC_DATASETS.md`, then pass the archives to the preprocessing script:

```bash
python code/run_revision_validation.py --help
python code/run_revision_validation.py --mhealth-zip PATH_TO_MHEALTH_ZIP --har-zip PATH_TO_HAR_ZIP --prepare-only
python code/run_revision_validation.py --mhealth-zip PATH_TO_MHEALTH_ZIP --har-zip PATH_TO_HAR_ZIP
python code/run_revision_validation.py --mhealth-zip PATH_TO_MHEALTH_ZIP --har-zip PATH_TO_HAR_ZIP --audit-only
```

The default output directory is `results_revision`. The packaged caches let the component scripts run without re-downloading the raw archives.

## Reproduce the reported components

```bash
python code/run_revision_components.py
python code/prepare_revision_component_tables.py
```

Additional component experiments, including the conditional-imputation comparison, the ten-mask rho validation and the reversed and size-balanced simulation designs:

```bash
python code/revision_extra/exp_impute_primary.py
python code/revision_extra/exp_reselect10.py
python code/revision_extra/exp_rho_and_impute.py --experiment impute
python code/revision_extra/exp_sim_variants.py
python code/revision_extra/exp_ep.py
python code/revision_extra/exp_correction_validation.py
python code/revision_extra/exp_modality_dropout.py
python code/revision_extra/exp_late_fusion.py
python code/revision_extra/exp_selected_350.py
python code/revision_extra/make_tables.py
```

## Reproduce Figure 5

```bash
python code/plot_factorial_contrasts.py
```

This reads `generated/table_revision_factorial_paired.tex` and refits nothing.

## Scope and caveats

- The public-data experiments begin with complete-source representations and then impose controlled MAR masks. They do not establish representation learning from naturally incomplete modalities or robustness to MNAR missingness.
- Repeated-mask intervals condition on the fixed benchmark samples, split and representations. They do not quantify new-subject or new-site uncertainty and are not multiplicity-adjusted.
- The message-interface study is a single-process emulation and reports application payload, not physical-network speedup or privacy guarantees.
- The archived simulation was run on Linux; the public-data and message experiments were run on Windows. Exact versions and input hashes are recorded with each run.

See `REPRODUCIBILITY.md` for the full command set and interpretation limits.

## Citation

If you use this code, please cite the manuscript. A `CITATION.cff` file is included so GitHub can render the citation.

## Contact

Xiaofei Wu (`xfwu1016@ynu.edu.cn`) and Jian Qing Shi (`jianqingshi@bnbu.edu.cn`).
