# Public datasets and preprocessing

Raw archives are obtained separately and are not redistributed. The dataset DOI identifiers below record provenance; they are not additions to the manuscript bibliography.

## MHEALTH

UCI Machine Learning Repository, DOI `10.24432/C5TW22`. Blocks are chest acceleration, two-lead ECG, ankle inertial/magnetic signals and wrist inertial/magnetic signals. Non-overlapping two-second windows are split chronologically 70%/30% within participant and activity: 2,335 training and 1,020 test windows. Participants can appear in both sets; this is not subject-generalization evidence.

Inner validation uses the first 80% of outer source-training chronology within participant and activity for fitting standardization and PCA, and the remaining 20% for validation. The pipeline is refitted on all source training after selection. The final representation has 55 dimensions. Controlled masks are imposed afterward.

## Human Activity Recognition Using Smartphones

UCI Machine Learning Repository, DOI `10.24432/C54S4K`. The official subject-disjoint split is retained (7,352 training and 2,947 test). Released features are grouped into accelerometer-derived and gyroscope-derived blocks. The five silos are artificial assignments rather than observed institutions.

Inner validation holds out source subjects 6, 14, 19, 25 and 30, one per silo. Raw-block standardization and 25 principal components per block are fitted on the remaining inner training subjects. The full source-training refit yields 50 dimensions before masking.

## Sources and limits

`code/run_revision_validation.py` reconstructs raw preprocessing, clean inner selection, primary results and the prediction audit. Configurations record cache hashes. The primary analysis uses 1,400 smooth rounds and selected rho values of 0.12 for MHEALTH and 0.20 for HAR; the 620-fit secondary study and the separate message study use the prespecified common rho 0.05 and 350 rounds.

Complete source datasets supply representations before simulated masks. This does not establish end-to-end representation learning from naturally incomplete modalities. Repeated-mask intervals condition on the split and representation. Legacy scripts from earlier pipeline versions are retained in the archive for provenance.
